package com.lia.assistant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.lia.assistant.R
import com.lia.assistant.action.ActionExecutor
import com.lia.assistant.brain.ConversationMemory
import com.lia.assistant.brain.LiaResponder
import com.lia.assistant.data.Prefs
import com.lia.assistant.service.BubbleService

class MainActivity : AppCompatActivity() {

    companion object {
        const val TAB_HOME = 0
        const val TAB_VOICE = 1
        const val TAB_FORGE = 2
        const val TAB_CHAT = 3
        const val TAB_SETUP = 4
        const val TAB_SETTINGS = 5
    }

    val prefs by lazy { Prefs(this) }
    val mem = ConversationMemory()
    val responder by lazy { LiaResponder(this, prefs, mem) }

    private lateinit var container: FrameLayout
    private lateinit var tabBar: android.widget.LinearLayout
    private val tabBtns = mutableListOf<android.widget.Button>()
    private var current = -1
    private val frags = arrayOfNulls<Fragment>(6)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Pichhli baar crash hua tha? Wajah dikhao taaki user bhej sake.
        val crashFile = java.io.File(filesDir, "crash.log")
        if (crashFile.exists()) {
            val trace = try { crashFile.readText().take(9000) } catch (_: Exception) { "padh nahi paya" }
            showCrashReport(trace, crashFile)
            return
        }

        responder.executor.forgeOpener = object : ActionExecutor.ForgeOpener {
            override fun openForge(subject: String) {
                runOnUiThread { this@MainActivity.openForge(subject) }
            }
        }

        container = FrameLayout(this).apply { id = View.generateViewId() }
        // Custom tab bar — BottomNavigationView me max 5 items, hamein 6 chahiye
        tabBar = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
            setBackgroundColor(Ui.col(Ui.SURFACE))
            val p = Ui.dp(this@MainActivity, 4)
            setPadding(p, p, p, p)
        }
        val tabs = listOf(
            TAB_HOME to "🏠\nHome", TAB_VOICE to "🎙️\nVoice", TAB_FORGE to "🔥\nForge",
            TAB_CHAT to "💬\nChat", TAB_SETUP to "🔐\nSetup", TAB_SETTINGS to "⚙️\nSettings"
        )
        for ((id, label) in tabs) {
            val b = android.widget.Button(this, null, android.R.attr.buttonStyle).apply {
                text = label
                textSize = 10f
                isAllCaps = false
                setOnClickListener { go(id) }
                layoutParams = android.widget.LinearLayout.LayoutParams(0,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            tabBtns.add(b)
            tabBar.addView(b)
        }

        val lin = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        val cp = android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        container.layoutParams = cp
        lin.addView(container)
        lin.addView(tabBar, android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT))
        setContentView(lin)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }

        // bubble restore
        if (prefs.bubbleOn && Settings.canDrawOverlays(this)) BubbleService.start(this)

        go(intent.getIntExtra("tab", TAB_HOME))
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.hasExtra("tab")) go(intent.getIntExtra("tab", TAB_VOICE))
    }

    fun go(tab: Int) {
        if (tab == current && frags[tab] != null) return
        current = tab
        refreshTabs()
        var f = frags[tab]
        if (f == null) {
            f = when (tab) {
                TAB_HOME -> HomeFragment()
                TAB_VOICE -> VoiceFragment()
                TAB_FORGE -> ForgeFragment()
                TAB_CHAT -> ChatFragment()
                TAB_SETUP -> SetupFragment()
                else -> SettingsFragment()
            }
            frags[tab] = f
        }
        supportFragmentManager.beginTransaction().replace(container.id, f!!).commit()
    }

    private fun refreshTabs() {
        for (i in tabBtns.indices) {
            val b = tabBtns[i]
            val sel = (i == current)
            b.setBackgroundColor(Ui.col(if (sel) Ui.ACCENT else Ui.SURFACE))
            b.setTextColor(Ui.col(if (sel) "#221100" else Ui.TEXT2))
        }
    }

    fun openForge(subject: String) {
        go(TAB_FORGE)
        (frags[TAB_FORGE] as? ForgeFragment)?.startForge(subject)
    }

    fun sendChatText(t: String) {
        go(TAB_CHAT)
        container.postDelayed({ (frags[TAB_CHAT] as? ChatFragment)?.receiveText(t) }, 300)
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    /** Crash report dialog — wajah copy karke Jiasmin ko bhejo. */
    private fun showCrashReport(trace: String, f: java.io.File) {
        val tv = android.widget.TextView(this).apply {
            text = trace
            textSize = 11f
            setPadding(24, 16, 24, 16)
            setTextIsSelectable(true)
            setBackgroundColor(Ui.col(Ui.RAISED))
            setTextColor(Ui.col(Ui.TEXT))
        }
        val sv = android.widget.ScrollView(this).apply { addView(tv) }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("😢 LIA crash ho gayi")
            .setMessage("Neeche crash ki wajah hai. COPY dabakar ye text Jiasmin ko bhejo — turant fix kar degi:")
            .setView(sv)
            .setPositiveButton("📋 COPY") { _, _ ->
                val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("lia-crash", trace))
                toast("Copy ho gaya ✅ — ab Jiasmin ko bhejo")
            }
            .setNegativeButton("🗑️ Delete") { _, _ -> try { f.delete() } catch (_: Exception) {}; recreate() }
            .setCancelable(false)
            .show()
    }
}
