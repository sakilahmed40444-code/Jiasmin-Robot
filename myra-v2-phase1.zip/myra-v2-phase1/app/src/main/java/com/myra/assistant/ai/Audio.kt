package com.myra.assistant.ai

import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.myra.assistant.data.Prefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.sqrt

enum class State { IDLE, LISTENING, RECORDING, THINKING, SPEAKING }

class AudioEngine {
    @Volatile private var track: AudioTrack? = null
    @Volatile private var stopped = false
    @Volatile private var framesWritten = 0L
    private var curRate = 0
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    @Volatile var onAmp: ((Float) -> Unit)? = null

    fun aecAvailable() = AcousticEchoCanceler.isAvailable()

    fun startMic(useAec: Boolean): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val src = if (useAec) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.VOICE_RECOGNITION
        val r = try { AudioRecord(src, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 640 * 8)) }
        catch (e: Exception) { return null }
        if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return null }
        if (useAec) {
            if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(r.audioSessionId)?.also { it.enabled = true }
            if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(r.audioSessionId)?.also { it.enabled = true }
        }
        r.startRecording(); return r
    }
    fun stopMic(r: AudioRecord?) {
        try { r?.stop() } catch (_: Exception) {}
        try { r?.release() } catch (_: Exception) {}
        aec?.release(); ns?.release(); aec = null; ns = null
    }

    fun begin() { stopped = false; framesWritten = 0 }

    private fun ensureTrack(rate: Int): AudioTrack {
        track?.let { if (curRate == rate) return it; it.release() }
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, rate)).setTransferMode(AudioTrack.MODE_STREAM).build()
        t.play(); track = t; curRate = rate; return t
    }

    /** Blocking write of raw PCM16 mono. */
    fun write(pcm: ByteArray) {
        try {
            val t = ensureTrack(Prefs.ttsRate)
            var off = 0
            while (off < pcm.size && !stopped) {
                val n = t.write(pcm, off, minOf(4096, pcm.size - off))
                if (n <= 0) break
                off += n; framesWritten += n / 2
                var s = 0.0; var i = 0
                while (i + 1 < n && i < 4096) { val v = ((pcm[off - n + i + 1].toInt() shl 8) or (pcm[off - n + i].toInt() and 0xFF)).toShort().toDouble(); s += v * v; i += 2 }
                onAmp?.invoke((sqrt(s / maxOf(1, n / 2)) / 9000.0).toFloat().coerceIn(0f, 1f))
            }
        } catch (_: IllegalStateException) { }
    }

    suspend fun drain() {
        val t = track ?: return
        val target = framesWritten; var guard = 0
        try { while (!stopped && t.playbackHeadPosition < target && guard++ < 2000) delay(20) } catch (_: IllegalStateException) {}
        onAmp?.invoke(0f)
    }

    fun stop() {
        stopped = true
        try { track?.pause(); track?.flush(); track?.release() } catch (_: Exception) {}
        track = null; onAmp?.invoke(0f)
    }
}

/** Voice activity detection: adaptive noise floor, 3-frame start, 300 ms pre-roll, silence endpoint. */
class Vad(private val silenceMs: Int, private val onStart: () -> Unit, private val onUtterance: (ByteArray) -> Unit) {
    private val win = java.util.ArrayDeque<Double>()
    private val pre = java.util.ArrayDeque<ShortArray>()
    private val buf = ByteArrayOutputStream()
    private var speech = 0; private var rec = false; private var silent = 0; private var total = 0

    fun reset() { rec = false; speech = 0; silent = 0; total = 0; buf.reset(); pre.clear() }

    private fun write(f: ShortArray) { for (x in f) { buf.write(x.toInt() and 0xFF); buf.write((x.toInt() shr 8) and 0xFF) } }

    fun feed(f: ShortArray) {
        var s = 0.0; for (x in f) s += x.toDouble() * x
        val rms = sqrt(s / f.size)
        val floor = win.minOrNull() ?: 0.0
        val sp = rms > floor * 3 + 400
        if (!rec) {
            win.addLast(rms); if (win.size > 100) win.removeFirst()
            pre.addLast(f.copyOf()); if (pre.size > 15) pre.removeFirst()
            speech = if (sp) speech + 1 else 0
            if (speech >= 3) { rec = true; silent = 0; total = 0; buf.reset(); pre.forEach { write(it) }; pre.clear(); onStart() }
        } else {
            write(f); total++
            silent = if (sp) 0 else silent + 1
            if (silent * 20 >= silenceMs || total * 20 >= 30000) {
                val voiced = (total - silent) * 20
                val pcm = buf.toByteArray(); reset()
                if (voiced >= 300) onUtterance(pcm)
            }
        }
    }
}

fun pcmToWav(pcm: ByteArray, rate: Int = 16000): ByteArray {
    val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
    h.put("RIFF".toByteArray()); h.putInt(36 + pcm.size); h.put("WAVE".toByteArray()); h.put("fmt ".toByteArray())
    h.putInt(16); h.putShort(1); h.putShort(1); h.putInt(rate); h.putInt(rate * 2); h.putShort(2); h.putShort(16)
    h.put("data".toByteArray()); h.putInt(pcm.size)
    return h.array() + pcm
}

/** Android TextToSpeech: used when the neural TTS fails, is unset, or the text is Hindi/Bengali script. */
class FallbackTts(ctx: Context) {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private val waiters = ConcurrentHashMap<String, CompletableDeferred<Unit>>()

    init {
        tts = TextToSpeech(ctx.applicationContext) { st ->
            ready = st == TextToSpeech.SUCCESS
            if (ready) tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { id?.let { waiters.remove(it)?.complete(Unit) } }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { id?.let { waiters.remove(it)?.complete(Unit) } }
            })
        }
    }

    suspend fun speak(text: String) {
        if (!ready || text.isBlank()) return
        tts?.language = when {
            text.any { it in '\u0980'..'\u09FF' } -> Locale("bn", "IN")
            text.any { it in '\u0900'..'\u097F' } -> Locale("hi", "IN")
            else -> Locale("en", "IN")
        }
        val id = UUID.randomUUID().toString(); val d = CompletableDeferred<Unit>(); waiters[id] = d
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, id)
        try { d.await() } catch (e: CancellationException) { tts?.stop(); throw e }
    }
    fun stop() { tts?.stop(); waiters.values.forEach { it.complete(Unit) }; waiters.clear() }
}
