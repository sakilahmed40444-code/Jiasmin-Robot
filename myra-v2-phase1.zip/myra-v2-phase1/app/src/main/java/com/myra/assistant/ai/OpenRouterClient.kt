package com.myra.assistant.ai

import android.util.Base64
import com.myra.assistant.data.Prefs
import com.myra.assistant.s
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiException(val code: Int, msg: String) : Exception(msg)

/**
 * Provider-aware brain client.
 * - OpenRouter: https://openrouter.ai/api/v1 (OpenRouter key)
 * - Gemini: https://generativelanguage.googleapis.com/v1beta/openai (Gemini key, OpenAI-compatible:
 *   chat completions + streaming + function calling + input_audio all supported)
 */
class BrainClient(val baseUrl: String, val key: String, val model: String, val openRouter: Boolean) {
    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(90, TimeUnit.SECONDS).build()
    @Volatile private var call: Call? = null
    fun cancel() { call?.cancel() }

    data class ToolCall(val id: String, val name: String, val args: String)
    data class Result(val text: String, val toolCalls: List<ToolCall>, val finish: String?, val reasoning: JSONArray)

    companion object {
        const val OR_BASE = "https://openrouter.ai/api/v1"
        const val GEM_BASE = "https://generativelanguage.googleapis.com/v1beta/openai"

        /** Resolve which provider to use. Null = no key set. */
        fun resolve(): BrainClient? = when (Prefs.brainProvider) {
            "GEMINI" -> if (Prefs.geminiKeyOn && Prefs.geminiKey.isNotBlank())
                BrainClient(GEM_BASE, Prefs.geminiKey, Prefs.geminiModel.ifBlank { "gemini-3.8-flash" }, false) else null
            "OPENROUTER" -> if (Prefs.openRouterKeyOn && Prefs.apiKey.isNotBlank())
                BrainClient(OR_BASE, Prefs.apiKey, Prefs.brainModel.ifBlank { "google/gemini-3.8-flash" }, true) else null
            else -> when { // AUTO: Gemini key first, else OpenRouter
                Prefs.geminiKeyOn && Prefs.geminiKey.isNotBlank() ->
                    BrainClient(GEM_BASE, Prefs.geminiKey, Prefs.geminiModel.ifBlank { "gemini-3.8-flash" }, false)
                Prefs.openRouterKeyOn && Prefs.apiKey.isNotBlank() ->
                    BrainClient(OR_BASE, Prefs.apiKey, Prefs.brainModel.ifBlank { "google/gemini-3.8-flash" }, true)
                else -> null
            }
        }

        fun resolvedName(): String = when (Prefs.brainProvider) {
            "GEMINI" -> "Gemini"
            "OPENROUTER" -> "OpenRouter"
            else -> if (Prefs.geminiKey.isNotBlank()) "Gemini" else "OpenRouter"
        }
    }

    private fun builder(url: String): Request.Builder {
        val b = Request.Builder().url(url).header("Authorization", "Bearer $key")
        if (openRouter) b.header("HTTP-Referer", "https://myra.app").header("X-Title", "MYRA")
        return b
    }

    fun stream(messages: JSONArray, tools: JSONArray?, maxTokens: Int, thinking: String, onDelta: (String) -> Unit): Result {
        val body = JSONObject().apply {
            put("model", model)
            put("stream", true); put("temperature", 0.8); put("max_tokens", maxTokens)
            if (openRouter) {
                put("models", JSONArray(listOf(model, "google/gemini-3.7-flash").distinct()))
                put("reasoning", JSONObject().put("effort", thinking))
                if (Prefs.webSearch) put("plugins", JSONArray().put(JSONObject().put("id", "web")))
            } else {
                // Gemini OpenAI-compatible thinking level
                put("reasoning_effort", thinking)
            }
            put("messages", messages)
            if (tools != null) { put("tools", tools); put("tool_choice", "auto") }
        }
        val req = builder("$baseUrl/chat/completions")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        var attempt = 0
        while (true) {
            val c = http.newCall(req); call = c
            val resp = try { c.execute() } catch (e: IOException) {
                if (c.isCanceled() || attempt >= 3) throw e
                attempt++; Thread.sleep(1000L shl (attempt - 1)); continue
            }
            if (!resp.isSuccessful) {
                val code = resp.code; val msg = resp.body?.string()?.take(300) ?: ""; resp.close()
                if ((code == 429 || code >= 500) && attempt < 3) { attempt++; Thread.sleep(1000L shl (attempt - 1)); continue }
                throw ApiException(code, msg)
            }
            return parse(resp, onDelta)
        }
    }

    private fun parse(resp: Response, onDelta: (String) -> Unit): Result {
        val text = StringBuilder()
        val calls = sortedMapOf<Int, Array<String>>()
        val reasoning = JSONArray()
        var finish: String? = null
        resp.use { r ->
            val src = r.body!!.source()
            while (true) {
                val line = src.readUtf8Line() ?: break
                if (!line.startsWith("data:")) continue          // ignores ": keep-alive" comments
                val d = line.substring(5).trim()
                if (d == "[DONE]") break
                val j = try { JSONObject(d) } catch (e: Exception) { continue }   // skip malformed SSE
                j.optJSONObject("error")?.let { throw ApiException(it.optInt("code", 500), it.optString("message")) }
                val ch = j.optJSONArray("choices")?.optJSONObject(0) ?: continue
                val delta = ch.optJSONObject("delta")
                if (delta != null) {
                    val c = delta.s("content"); if (c.isNotEmpty()) { text.append(c); onDelta(c) }
                    delta.optJSONArray("reasoning_details")?.let { a -> for (i in 0 until a.length()) reasoning.put(a.get(i)) }
                    delta.optJSONArray("tool_calls")?.let { arr ->
                        for (i in 0 until arr.length()) {
                            val t = arr.getJSONObject(i)
                            val e = calls.getOrPut(t.optInt("index", i)) { arrayOf("", "", "") }
                            t.s("id").takeIf { it.isNotEmpty() }?.let { e[0] = it }
                            t.optJSONObject("function")?.let { f ->
                                f.s("name").takeIf { it.isNotEmpty() }?.let { e[1] = it }
                                e[2] = e[2] + f.s("arguments")
                            }
                        }
                    }
                }
                ch.s("finish_reason").takeIf { it.isNotEmpty() }?.let { finish = it }
            }
        }
        val list = calls.values.filter { it[1].isNotEmpty() }.mapIndexed { i, e ->
            ToolCall(e[0].ifEmpty { "call_$i" }, e[1], e[2].ifEmpty { "{}" })
        }
        return Result(text.toString(), list, finish, reasoning)
    }

    /** 1-token request used by the Settings "Test" buttons. Returns null if OK, else an error text. */
    fun test(): String? {
        val body = JSONObject().put("model", model).put("max_tokens", 5)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", "hi")))
        return try {
            http.newCall(builder("$baseUrl/chat/completions")
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()).execute().use {
                if (it.isSuccessful) null else "HTTP ${it.code}: ${it.body?.string()?.take(160)}"
            }
        } catch (e: Exception) { e.message ?: "network error" }
    }

    /** OpenRouter TTS-capable models. Empty for Gemini (uses GeminiTts instead). */
    fun listTtsModels(): List<String> = if (!openRouter) emptyList() else try {
        http.newCall(builder("$baseUrl/models?output_modalities=speech").get().build()).execute().use {
            val a = JSONObject(it.body!!.string()).optJSONArray("data") ?: JSONArray()
            (0 until a.length()).map { i -> a.getJSONObject(i).optString("id") }.filter { id -> id.isNotEmpty() }
        }
    } catch (e: Exception) { emptyList() }
}

class OpenRouterTts(private val http: OkHttpClient) {
    private val cache = object : android.util.LruCache<String, ByteArray>(6 * 1024 * 1024) {
        override fun sizeOf(k: String, v: ByteArray) = v.size
    }
    /** Returns raw PCM16 bytes, or null on any failure (caller falls back to Android TTS).
     *  Uses the same voice names as Gemini TTS (Kore, Aoede, ...) — one list for both keys. */
    fun synth(text: String, voice: String): ByteArray? {
        val key = "$voice|$text"
        cache.get(key)?.let { return it }
        val body = JSONObject().put("model", "google/gemini-3.1-flash-tts-preview").put("input", text)
            .put("response_format", "pcm").put("voice", voice)
        val req = Request.Builder().url("https://openrouter.ai/api/v1/audio/speech")
            .header("Authorization", "Bearer ${Prefs.apiKey}")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        return try {
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) null else r.body?.bytes()?.also { if (it.size > 200) cache.put(key, it) }?.takeIf { it.size > 200 }
            }
        } catch (e: Exception) { null }
    }
}

/** Gemini native TTS (works with the Gemini API key). Returns PCM16 24kHz mono bytes, or null. */
class GeminiTts(private val http: OkHttpClient) {
    fun synth(text: String, voice: String): ByteArray? {
        val key = Prefs.geminiKey; if (key.isBlank()) return null
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject()
                .put("parts", JSONArray().put(JSONObject().put("text", "Speak aloud, naturally: $text")))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject()
                    .put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        val ttsModel = Prefs.geminiTtsModel.ifBlank { "gemini-3.8-flash-tts" }
        val brainModel = Prefs.geminiModel.ifBlank { "gemini-3.8-flash" }
        // Try TTS model first, then brain model as fallback
        for (model in listOf(ttsModel, brainModel).distinct()) {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key"
            val req = Request.Builder().url(url)
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()
            var result: ByteArray? = null
            try {
                http.newCall(req).execute().use { r ->
                    if (r.isSuccessful) {
                        val parts = JSONObject(r.body!!.string())
                            .optJSONArray("candidates")?.optJSONObject(0)
                            ?.optJSONObject("content")?.optJSONArray("parts")
                        if (parts != null) {
                            for (i in 0 until parts.length()) {
                                val b64 = parts.optJSONObject(i)?.optJSONObject("inlineData")?.optString("data")
                                if (!b64.isNullOrEmpty()) {
                                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                                    if (bytes.size > 200) { result = bytes; break }
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {}
            if (result != null) return result
        }
        return null
    }
}
