package com.lia.assistant.call

import android.content.Context
import android.os.Build
import android.telecom.TelecomManager

/** Incoming call uthao / kato — TelecomManager. */
object TelecomHelper {

    /** Ringing call accept — ANSWER_PHONE_CALLS permission lage. */
    fun acceptCall(ctx: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 26) {
                val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                tm.acceptRingingCall()
                true
            } else false
        } catch (_: Exception) { false }
    }

    /** Ringing call reject. */
    fun rejectCall(ctx: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 28) {
                val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                tm.endCall()
                true
            } else false
        } catch (_: Exception) { false }
    }
}
