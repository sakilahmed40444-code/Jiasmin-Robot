package com.lia.assistant.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.lia.assistant.brain.Persona
import com.lia.assistant.data.MemStore
import com.lia.assistant.voice.VoiceEngine

class SettingsFragment : Fragment() {
    private fun act() = activity as MainActivity

    private lateinit var nameEt: EditText
    private lateinit var keyEt: EditText
    private lateinit var modelEt: EditText
    private lateinit var orKeyEt: EditText
    private lateinit var orModelEt: EditText
    private lateinit var serpKeyEt: EditText
    private lateinit var customEt: EditText
    private lateinit var personaTv: TextView
    private lateinit var langTv: TextView
    private lateinit var rateTv: TextView
    private lateinit var voiceTv: TextView
    private lateinit var memList: LinearLayout

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val prefs = act().prefs
        val sv = Ui.scrollCol(ctx)
        val col = Ui.colLayout(ctx)
        sv.addView(col)
        col.addView(Ui.title(ctx, "Settings"))

        // Profile
        val c1 = Ui.card(ctx); val cc1 = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        cc1.addView(Ui.tv(ctx, "👤 Profile", 16, Ui.TEXT, true))
        cc1.addView(Ui.tv(ctx, "Tumhara naam (Lia isi se bulayegi)", 12, Ui.TEXT2))
        nameEt = Ui.input(ctx, "e.g. Sabuj"); nameEt.setText(if (prefs.name == "dost") "" else prefs.name)
        cc1.addView(nameEt); c1.addView(cc1); col.addView(c1)

        // API keys
        val c2 = Ui.card(ctx); val cc2 = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        cc2.addView(Ui.tv(ctx, "🔑 API keys", 16, Ui.TEXT, true))
        cc2.addView(Ui.tv(ctx, "Gemini key", 12, Ui.TEXT2))
        keyEt = Ui.input(ctx, "AIza… paste karo", true); keyEt.setText(prefs.apiKey); cc2.addView(keyEt)
        cc2.addView(Ui.tv(ctx, "Gemini model", 12, Ui.TEXT2))
        modelEt = Ui.input(ctx, "gemini-2.0-flash"); modelEt.setText(prefs.model); cc2.addView(modelEt)
        cc2.addView(Ui.tv(ctx, "OpenRouter key (Gemini fail ho to backup brain)", 12, Ui.TEXT2))
        orKeyEt = Ui.input(ctx, "sk-or-…", true); orKeyEt.setText(prefs.openRouterKey); cc2.addView(orKeyEt)
        cc2.addView(Ui.tv(ctx, "OpenRouter model", 12, Ui.TEXT2))
        orModelEt = Ui.input(ctx, "meta-llama/llama-3.1-8b-instruct:free"); orModelEt.setText(prefs.openRouterModel); cc2.addView(orModelEt)
        cc2.addView(Ui.tv(ctx, "Serp API key (web search ke liye)", 12, Ui.TEXT2))
        serpKeyEt = Ui.input(ctx, "serp…", true); serpKeyEt.setText(prefs.serpKey); cc2.addView(serpKeyEt)
        cc2.addView(Ui.tv(ctx, "Keys sirf is phone me rehti hain.", 12, Ui.TEXT2))
        c2.addView(cc2); col.addView(c2)

        // Personality & language
        val c3 = Ui.card(ctx); val cc3 = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        cc3.addView(Ui.tv(ctx, "🎭 Personality & bhasha", 16, Ui.TEXT, true))
        personaTv = Ui.tv(ctx, "", 15, Ui.ACCENT, true)
        val prow = Ui.row(ctx)
        prow.addView(Ui.btn(ctx, "Personality chuno") { pickPersona() })
        prow.addView(personaTv)
        cc3.addView(prow)
        cc3.addView(Ui.tv(ctx, "Custom personality instruction (Custom chuno tab kaam karegi)", 12, Ui.TEXT2))
        customEt = Ui.input(ctx, "e.g. Tum ek shayar ho, har jawab me ek sher sunao")
        customEt.setText(prefs.customPersona); cc3.addView(customEt)
        langTv = Ui.tv(ctx, "", 15, Ui.ACCENT, true)
        val lrow = Ui.row(ctx)
        lrow.addView(Ui.btn(ctx, "Bhasha chuno") { pickLang() })
        lrow.addView(langTv)
        cc3.addView(lrow)
        c3.addView(cc3); col.addView(c3)

        // Voice
        val c4 = Ui.card(ctx); val cc4 = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        cc4.addView(Ui.tv(ctx, "🗣️ Voice", 16, Ui.TEXT, true))
        voiceTv = Ui.tv(ctx, "", 14, Ui.ACCENT, true)
        val vrow = Ui.row(ctx)
        vrow.addView(Ui.btn(ctx, "🔊 Voice chuno") { pickVoice() })
        vrow.addView(voiceTv)
        cc4.addView(vrow)
        rateTv = Ui.tv(ctx, "", 14, Ui.TEXT2)
        cc4.addView(rateTv)
        cc4.addView(Ui.seek(ctx, 100, ((prefs.speechRate - 0.6f) / 1.0f * 100).toInt().coerceIn(0, 100)) {
            prefs.speechRate = 0.6f + it / 100f * 1.0f
            rateTv.text = "Bole ki raftaar: ${"%.1f".format(prefs.speechRate)}x"
        })
        val trow = Ui.row(ctx)
        trow.addView(Ui.btn(ctx, "🔊 Voice test", false) { testVoice() })
        cc4.addView(trow)
        c4.addView(cc4); col.addView(c4)

        // Memories
        val c5 = Ui.card(ctx); val cc5 = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        cc5.addView(Ui.tv(ctx, "🧠 My Memories", 16, Ui.TEXT, true))
        cc5.addView(Ui.tv(ctx, "\"Yaad rakho ...\" bolo ya yahan add karo — Lia baat me yaad rakhegi.", 12, Ui.TEXT2))
        memList = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        cc5.addView(memList)
        val mrow = Ui.row(ctx)
        mrow.addView(Ui.btn(ctx, "＋ Add", false) { addMemory() })
        cc5.addView(mrow)
        c5.addView(cc5); col.addView(c5)

        val saveRow = Ui.row(ctx)
        saveRow.addView(Ui.btn(ctx, "💾 Save") {
            prefs.name = nameEt.text.toString().trim().ifBlank { "dost" }
            prefs.apiKey = keyEt.text.toString().trim()
            prefs.model = modelEt.text.toString().trim().ifBlank { "gemini-2.0-flash" }
            prefs.openRouterKey = orKeyEt.text.toString().trim()
            prefs.openRouterModel = orModelEt.text.toString().trim().ifBlank { "meta-llama/llama-3.1-8b-instruct:free" }
            prefs.serpKey = serpKeyEt.text.toString().trim()
            prefs.customPersona = customEt.text.toString().trim()
            act().toast("Settings save ho gayi ✅")
        })
        col.addView(saveRow)

        val about = Ui.card(ctx); val ac = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        ac.addView(Ui.tv(ctx, "🔥 LIA Native v1.1", 16, Ui.TEXT, true))
        ac.addView(Ui.tv(ctx, "Voice-first AI companion — Hindi, Hinglish, English.\nFloating bubble · full phone control · Website Forge · wake word · memories.\n\nPrivacy: keys, naam, memories — sab sirf tumhare phone me.", 13, Ui.TEXT2))
        about.addView(ac); col.addView(about)

        refreshLabels()
        renderMems()
        return sv
    }

    private fun refreshLabels() {
        val p = act().prefs
        personaTv.text = Persona.byKey(p.persona).icon + " " + Persona.byKey(p.persona).title
        langTv.text = when (p.langMode) { "hi" -> "🇮🇳 Hindi"; "hing" -> "🗣️ Hinglish"; "en" -> "🇬🇧 English"; else -> "🔀 Auto" }
        rateTv.text = "Bole ki raftaar: ${"%.1f".format(p.speechRate)}x"
        voiceTv.text = if (p.ttsVoiceName.isBlank()) "Default voice" else p.ttsVoiceName.take(28)
    }

    private fun pickPersona() {
        val ctx = requireContext()
        val items = Persona.values().map { "${it.icon} ${it.title} — ${it.desc}" }.toTypedArray()
        val cur = Persona.values().indexOf(Persona.byKey(act().prefs.persona))
        AlertDialog.Builder(ctx).setTitle("🎭 Personality chuno")
            .setSingleChoiceItems(items, cur) { d, w ->
                act().prefs.persona = Persona.values()[w].key
                act().mem.clear()
                refreshLabels()
                act().toast("Personality: ${Persona.values()[w].title}")
                d.dismiss()
            }.show()
    }

    private fun pickLang() {
        val ctx = requireContext()
        val items = arrayOf("🔀 Auto (khud pehchano)", "🇮🇳 Hindi", "🗣️ Hinglish", "🇬🇧 English")
        val vals = arrayOf("auto", "hi", "hing", "en")
        val cur = vals.indexOf(act().prefs.langMode).coerceAtLeast(0)
        AlertDialog.Builder(ctx).setTitle("Bhasha chuno")
            .setSingleChoiceItems(items, cur) { d, w ->
                act().prefs.langMode = vals[w]
                refreshLabels(); d.dismiss()
            }.show()
    }

    private fun pickVoice() {
        val ctx = requireContext()
        act().toast("Voices load ho rahi hain…")
        VoiceEngine.fetchVoiceNames(ctx) { names ->
            activity?.runOnUiThread {
                if (names.isEmpty()) { act().toast("Koi voice nahi mili 😔"); return@runOnUiThread }
                val items = (listOf("Default voice") + names).toTypedArray()
                val cur = if (act().prefs.ttsVoiceName.isBlank()) 0 else names.indexOf(act().prefs.ttsVoiceName) + 1
                AlertDialog.Builder(ctx).setTitle("🔊 Voice chuno")
                    .setSingleChoiceItems(items, cur.coerceAtLeast(0)) { d, w ->
                        act().prefs.ttsVoiceName = if (w == 0) "" else names[w - 1]
                        refreshLabels()
                        act().toast("Voice set ✅")
                        d.dismiss()
                    }.show()
            }
        }
    }

    private fun testVoice() {
        val ctx = requireContext()
        val p = act().prefs
        val e = VoiceEngine(ctx)
        e.setLang(if (p.langMode == "hi") "hi" else "hing", p.speechRate)
        e.setVoiceByName(p.ttsVoiceName)
        e.cb = object : VoiceEngine.Cb {
            override fun onListening() {}
            override fun onPartial(t: String) {}
            override fun onResult(t: String) {}
            override fun onError(m: String) {}
            override fun onSpeakDone() { e.destroy() }
        }
        e.speak("Namaste! Main Lia hoon. Kya meri awaaz sunai de rahi hai?")
        act().toast("Bol rahi hoon… 🔊")
    }

    private fun renderMems() {
        val ctx = requireContext()
        memList.removeAllViews()
        val mems = MemStore.list(ctx)
        if (mems.isEmpty()) {
            memList.addView(Ui.tv(ctx, "Abhi koi memory nahi — \"+ Add\" dabao.", 13, Ui.TEXT3))
            return
        }
        for (m in mems) {
            val r = Ui.row(ctx)
            val t = Ui.tv(ctx, "• $m", 14, Ui.TEXT)
            t.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            val del = Ui.btn(ctx, "❌", false) {
                MemStore.remove(ctx, m); renderMems(); act().toast("Delete ho gaya")
            }
            r.addView(t); r.addView(del)
            memList.addView(r)
        }
    }

    private fun addMemory() {
        val ctx = requireContext()
        val et = Ui.input(ctx, "e.g. Mera birthday 5 January hai")
        et.setPadding(40, 20, 40, 20)
        AlertDialog.Builder(ctx).setTitle("🧠 Yaad rakho").setView(et)
            .setPositiveButton("Save") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotBlank()) { MemStore.add(ctx, t); renderMems(); act().toast("Yaad rakh liya ✅") }
            }
            .setNegativeButton("Cancel", null).show()
    }
}
