package com.myra.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import com.myra.assistant.ai.State
import com.myra.assistant.ui.MainActivity
import com.myra.assistant.ui.OrbView
import com.myra.assistant.ui.dp

/** Floating green ball overlay — stays on home screen / other apps while MYRA runs.
 *  Tap to open MYRA. Drag to move. Dies with the app (START_NOT_STICKY). */
class FloatingBallService : Service() {

    private var wm: WindowManager? = null
    private var ball: View? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(101, buildNotif())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        showBall()
        return START_NOT_STICKY  // app killed -> ball goes away too
    }

    private fun buildNotif(): Notification {
        val ch = "myra_ball"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel(ch, "MYRA Ball", NotificationManager.IMPORTANCE_MIN))
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, ch)
            .setContentTitle("MYRA ball active")
            .setContentText("Tap the ball to talk")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open).build()
    }

    private fun showBall() {
        if (ball != null) return
        if (!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val size = dp(110)
        val orb = OrbView(this).apply { state = State.LISTENING }
        params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40; y = 300
        }
        var downX = 0; var downY = 0; var moved = false
        orb.setOnTouchListener { v, ev ->
            val p = params ?: return@setOnTouchListener false
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { downX = ev.rawX.toInt() - p.x; downY = ev.rawY.toInt() - p.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    p.x = ev.rawX.toInt() - downX; p.y = ev.rawY.toInt() - downY
                    wm?.updateViewLayout(v, p); moved = true; true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        val i = Intent(this, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                            putExtra("start_voice", true)
                        }
                        startActivity(i)
                    }
                    true
                }
                else -> false
            }
        }
        ball = orb
        try { wm?.addView(orb, params) } catch (_: Exception) { stopSelf() }
    }

    override fun onDestroy() {
        try { ball?.let { wm?.removeView(it) } } catch (_: Exception) {}
        ball = null
        super.onDestroy()
    }
}
