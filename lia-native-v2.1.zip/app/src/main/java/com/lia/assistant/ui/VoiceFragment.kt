package com.lia.assistant.ui

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.lia.assistant.brain.LanguageDetector
import com.lia.assistant.brain.LiaResponder
import com.lia.assistant.brain.OfflineBrain
import com.lia.assistant.voice.VoiceEngine

class VoiceFragment : Fragment(), VoiceEngine.Cb {

    private fun act() = activity as MainActivity
    private var engine: VoiceEngine? = null
    private var loopOn = false
    private var waitingForWake = false
    private var lastActive = 0L
    private lateinit var orb: BubbleView
    private lateinit var status: TextView
    private lateinit var logBox: LinearLayout
    private lateinit var logScroll: ScrollView
    private lateinit var talkBtn: Button
    private lateinit var muteBtn: Button
    private lateinit var wakeBtn: Button
    private var lastLang = "bn"
    private val timeoutHandler = Handler(Looper.getMainLooper())
    private val timeoutCheck = object : Runnable {
        override fun run() {
            val prefs = try { act().prefs } catch (_: Exception) { return }
            if (loopOn && !waitingForWake && prefs.wakeMode &&
                System.currentTimeMillis() - lastActive > prefs.wakeTimeoutSec * 1000L) {
                waitingForWake = true
                activity?.runOnUiThread {
                    status.text = "Timeout — '${prefs.wakeWord}' bolo 🎤"
                    orb.state = BubbleView.State.IDLE
                }
            }
            timeoutHandler.postDelayed(this, 5000)
        }
    }

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        engine = VoiceEngine(ctx)
        engine?.cb = this

        val sv = Ui.scrollCol(ctx)
        val col = Ui.colLayout(ctx)
        sv.addView(col)

        col.addView(Ui.title(ctx, "Voice session"))
        col.addView(Ui.sub(ctx, "Continuous loop — bolo, suno, phir bolo. Band karne ke liye ✕ dabao."))

        orb = BubbleView(ctx)
        val op = LinearLayout.LayoutParams(Ui.dp(ctx, 240), Ui.dp(ctx, 240))
        op.gravity = Gravity.CENTER_HORIZONTAL
        orb.layoutParams = op
        col.addView(orb)

        status = Ui.tv(ctx, "Session band hai", 17, Ui.TEXT2)
        status.gravity = Gravity.CENTER_HORIZONTAL
        status.setPadding(0, Ui.dp(ctx, 8), 0, 0)
        col.addView(status)

        val bar = Ui.row(ctx); bar.gravity = Gravity.CENTER_HORIZONTAL
        muteBtn = Ui.btn(ctx, "🔊", false) { toggleMute() }
        talkBtn = Ui.btn(ctx, "🎙️") { toggleLoop() }
        val stopB = Ui.btn(ctx, "✕", false) { stopLoop() }
        bar.addView(muteBtn); bar.addView(talkBtn); bar.addView(stopB)
        col.addView(bar)

        // ---- Wake word card ----
        col.addView(Ui.sec(ctx, "Wake word mode"))
        val card = Ui.card(ctx)
        val cc = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        cc.addView(Ui.tv(ctx, "🎤 Wake word", 16, Ui.TEXT, true))
        cc.addView(Ui.tv(ctx, "Chalu ho to LIA hamesha sunti rahegi — wake word bolo, tabhi jawab degi. (Battery zyada khayegi.)", 13, Ui.TEXT2))
        val wrow = Ui.row(ctx)
        wakeBtn = Ui.btn(ctx, "", false) {
            val p = act().prefs
            p.wakeMode = !p.wakeMode
            refreshWakeBtn()
            act().toast(if (p.wakeMode) "Wake mode ON 🎤" else "Wake mode OFF")
        }
        val editW = Ui.btn(ctx, "✏️ Words", false) { editWakeWords() }
        wrow.addView(wakeBtn); wrow.addView(editW)
        cc.addView(wrow)
        card.addView(cc)
        col.addView(card)

        col.addView(Ui.sec(ctx, "Baat-cheet"))
        logScroll = ScrollView(ctx)
        logBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        logScroll.addView(logBox)
        logScroll.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 220))
        col.addView(logScroll)
        refreshWakeBtn()
        return sv
    }

    private fun refreshWakeBtn() {
        val on = try { act().prefs.wakeMode } catch (_: Exception) { false }
        wakeBtn.text = if (on) "🎤 Wake mode: ON" else "🎤 Wake mode: OFF"
    }

    private fun editWakeWords() {
        val ctx = requireContext()
        val prefs = act().prefs
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 20) }
        col.addView(Ui.tv(ctx, "Wake word", 13, Ui.TEXT2))
        val wEt = Ui.input(ctx, "hello lia"); wEt.setText(prefs.wakeWord); col.addView(wEt)
        col.addView(Ui.tv(ctx, "Dismiss word", 13, Ui.TEXT2))
        val dEt = Ui.input(ctx, "bye bye"); dEt.setText(prefs.dismissWord); col.addView(dEt)
        col.addView(Ui.tv(ctx, "Auto timeout (sec)", 13, Ui.TEXT2))
        val tEt = Ui.input(ctx, "30"); tEt.setText(prefs.wakeTimeoutSec.toString())
        tEt.inputType = android.text.InputType.TYPE_CLASS_NUMBER; col.addView(tEt)
        AlertDialog.Builder(ctx).setTitle("🎤 Wake word settings").setView(col)
            .setPositiveButton("Save") { _, _ ->
                prefs.wakeWord = wEt.text.toString().trim().lowercase().ifBlank { "hello lia" }
                prefs.dismissWord = dEt.text.toString().trim().lowercase().ifBlank { "bye bye" }
                prefs.wakeTimeoutSec = tEt.text.toString().toIntOrNull()?.coerceIn(5, 300) ?: 30
                act().toast("Save ho gaya ✅")
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun toggleMute() {
        val e = engine ?: return
        e.muted = !e.muted
        if (e.muted) e.stopSpeak()
        muteBtn.text = if (e.muted) "🔇" else "🔊"
        act().toast(if (e.muted) "Mute 🔇" else "Unmute 🔊")
    }

    private fun toggleLoop() { if (loopOn) stopLoop() else startLoop() }

    private fun startLoop() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42)
            return
        }
        loopOn = true
        lastActive = System.currentTimeMillis()
        talkBtn.text = "⏸️"
        val prefs = act().prefs
        if (prefs.wakeMode) {
            waitingForWake = true
            vlog("a", "Wake mode ON — '${prefs.wakeWord}' bolo, tabhi main jawab dungi. 🎤")
            status.text = "'${prefs.wakeWord}' bolo… 🎤"
            orb.state = BubbleView.State.IDLE
        } else {
            waitingForWake = false
            vlog("a", "Namaste ${prefs.name.ifBlank { "dost" }}! Main sun rahi hoon — bolo. 👂")
        }
        timeoutHandler.post(timeoutCheck)
        listenNow()
    }

    fun stopLoop() {
        loopOn = false
        waitingForWake = false
        timeoutHandler.removeCallbacks(timeoutCheck)
        engine?.stopListen(); engine?.stopSpeak()
        talkBtn.text = "🎙️"
        orb.state = BubbleView.State.IDLE
        status.text = "Session band hai"
    }

    private var errStreak = 0
    private var lastListenAt = 0L
    private val mainH = Handler(Looper.getMainLooper())

    private fun listenNow(delayMs: Long = 0) {
        if (!loopOn) return
        // recognizer ko hamesha saans lene do — tez restart se ajeeb errors aate hain
        val gap = System.currentTimeMillis() - lastListenAt
        val wait = maxOf(delayMs, 900L - gap).coerceAtLeast(0L)
        mainH.postDelayed({
            if (!loopOn) return@postDelayed
            lastListenAt = System.currentTimeMillis()
            if (!waitingForWake) {
                orb.state = BubbleView.State.LISTENING
                status.text = "Sun rahi hoon… 👂"
            }
            engine?.listen(lastLang)
        }, wait)
    }

    private fun vlog(who: String, text: String) {
        val ctx = requireContext()
        val t = Ui.tv(ctx, text, 14, if (who == "u") Ui.TEXT else Ui.LAGOON)
        t.setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 8), Ui.dp(ctx, 12), Ui.dp(ctx, 8))
        t.setBackgroundColor(Ui.col(if (who == "u") Ui.RAISED else Ui.SURFACE))
        val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        p.bottomMargin = Ui.dp(ctx, 6)
        t.layoutParams = p
        logBox.addView(t)
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun applyVoice(lang: String) {
        val e = engine ?: return
        val p = act().prefs
        e.setLang(lang, p.speechRate)
        e.setVoiceByName(p.ttsVoiceName)
        // Gemini key hai to chuni hui Gemini voice (Kore...) bolegi
        e.geminiVoice = p.geminiVoice
        e.geminiKey = p.apiKey.takeIf { it.isNotBlank() }
    }

    // ---- VoiceEngine.Cb ----
    override fun onListening() {
        activity?.runOnUiThread {
            if (!waitingForWake) {
                orb.state = BubbleView.State.LISTENING
                status.text = "Sun rahi hoon… 👂"
            }
        }
    }

    override fun onPartial(text: String) {
        activity?.runOnUiThread { if (!waitingForWake) status.text = "“$text”" }
    }

    override fun onResult(text: String) {
        val prefs = try { act().prefs } catch (_: Exception) { return }
        errStreak = 0
        lastActive = System.currentTimeMillis()
        val low = text.lowercase()
        // ---- wake word check ----
        if (waitingForWake) {
            if (prefs.wakeWord.isNotBlank() && low.contains(prefs.wakeWord)) {
                waitingForWake = false
                activity?.runOnUiThread {
                    vlog("u", text)
                    val gl = if (prefs.langMode == "auto") "bn" else prefs.langMode
                    val g = OfflineBrain.reply("nomoshkar", gl, prefs.name.ifBlank { "dost" })
                    vlog("a", g)
                    orb.state = BubbleView.State.SPEAKING
                    applyVoice(gl)
                    engine?.speak(g)
                }
            } else {
                activity?.runOnUiThread { status.text = "'${prefs.wakeWord}' bolo… 🎤" }
                listenNow()
            }
            return
        }
        // ---- dismiss word check ----
        if (prefs.dismissWord.isNotBlank() && low.contains(prefs.dismissWord)) {
            activity?.runOnUiThread {
                vlog("u", text)
                val bye = "Bye ${prefs.name.ifBlank { "dost" }}! Phir '${prefs.wakeWord}' bolna. 🌙"
                vlog("a", bye)
                applyVoice(if (prefs.langMode == "auto") "bn" else prefs.langMode)
                if (prefs.wakeMode) {
                    waitingForWake = true
                    engine?.speak(bye) // onSpeakDone → listenNow (wake mode)
                    status.text = "'${prefs.wakeWord}' bolo… 🎤"
                } else {
                    engine?.speak(bye)
                    stopLoop()
                }
            }
            return
        }
        activity?.runOnUiThread {
            vlog("u", text)
            orb.state = BubbleView.State.THINKING
            status.text = "Soch rahi hoon…"
        }
        Thread {
            act().responder.respond(text, object : LiaResponder.Cb {
                override fun onReply(reply: String, lang: String) {
                    lastLang = lang
                    activity?.runOnUiThread {
                        vlog("a", reply)
                        orb.state = BubbleView.State.SPEAKING
                        status.text = "Bol rahi hoon… 🗣️"
                        val e = engine ?: return@runOnUiThread
                        applyVoice(lang)
                        val h = Handler(Looper.getMainLooper())
                        val tick = object : Runnable {
                            override fun run() {
                                if (e.isSpeaking()) { orb.amp = 0.3f + Math.random().toFloat() * 0.6f; h.postDelayed(this, 150) }
                                else orb.amp = 0f
                            }
                        }
                        h.post(tick)
                        e.speak(reply)
                    }
                }
            })
        }.start()
    }

    override fun onError(msg: String) {
        activity?.runOnUiThread {
            if (!loopOn) return@runOnUiThread
            errStreak++
            when (msg) {
                "no_match", "timeout" -> {
                    errStreak = 0
                    if (!waitingForWake) status.text = "Phir se bolo…"
                    listenNow()
                }
                "net", "net_timeout", "server" -> {
                    status.text = "Internet check karo 🌐 — phir try kar rahi hoon…"
                    orb.state = BubbleView.State.ERROR
                    listenNow(3000)
                }
                "busy" -> {
                    status.text = "Thoda ruk ke…"
                    listenNow(2000)
                }
                "no_perm" -> {
                    status.text = "Mic permission do 🎙️"
                    act().toast("Mic permission chahiye")
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42)
                }
                else -> {
                    // unknown error (jaise err_11) — tez retry se bacho, dheere try karo
                    if (errStreak >= 4) {
                        status.text = "Mic atak gaya 😔 — app band karke phir kholo, ya phone restart karo"
                        orb.state = BubbleView.State.ERROR
                        errStreak = 0
                        listenNow(8000)
                    } else {
                        status.text = "Mic me dikkat — dobara try…"
                        listenNow(2500)
                    }
                }
            }
        }
    }

    override fun onSpeakDone() {
        activity?.runOnUiThread {
            orb.amp = 0f
            if (loopOn) {
                if (waitingForWake) status.text = "'${try { act().prefs.wakeWord } catch (_: Exception) { "hello lia" }}' bolo… 🎤"
                listenNow()
            } else { orb.state = BubbleView.State.IDLE; status.text = "Session band hai" }
        }
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (rc == 42 && r.firstOrNull() == PackageManager.PERMISSION_GRANTED) startLoop()
        else act().toast("Mic permission chahiye 🎙️")
    }

    override fun onResume() {
        super.onResume()
        // Dashboard se START PRIYA aaye to loop turant shuru
        try {
            if ((activity as? MainActivity)?.autoStartVoice == true) {
                (activity as MainActivity).autoStartVoice = false
                if (!loopOn) startLoop()
            }
        } catch (_: Exception) { }
    }

    override fun onDestroyView() {
        loopOn = false
        timeoutHandler.removeCallbacks(timeoutCheck)
        engine?.destroy(); engine = null
        super.onDestroyView()
    }
}
