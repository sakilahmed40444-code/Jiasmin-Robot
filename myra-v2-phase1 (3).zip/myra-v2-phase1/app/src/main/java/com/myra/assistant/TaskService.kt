package com.myra.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.*

/** Keeps MYRA's voice tasks alive in background. Speaks progress updates until user says OFF. */
class TaskService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var tts: android.speech.tts.TextToSpeech? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(102, buildNotif("MYRA কাজ করছে..."))
        tts = android.speech.tts.TextToSpeech(this) { }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "STOP" -> { stopSelf(); return START_NOT_STICKY }
            "SAY" -> {
                val text = intent.getStringExtra("text") ?: return START_NOT_STICKY
                updateNotif(text.take(60))
                speak(text)
            }
        }
        return START_STICKY
    }

    private fun buildNotif(text: String): Notification {
        val ch = "myra_task"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel(ch, "MYRA Task", NotificationManager.IMPORTANCE_LOW))
        val stop = android.app.PendingIntent.getService(this, 0,
            Intent(this, TaskService::class.java).setAction("STOP"),
            android.app.PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, ch)
            .setContentTitle("MYRA")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(null, "STOP", stop).build())
            .build()
    }

    private fun updateNotif(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(102, buildNotif(text))
    }

    private fun speak(text: String) {
        try {
            tts?.speak(text, android.speech.tts.TextToSpeech.QUEUE_ADD, null, "task")
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        scope.cancel()
        try { tts?.shutdown() } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        fun say(ctx: Context, text: String) {
            val i = Intent(ctx, TaskService::class.java).setAction("SAY").putExtra("text", text)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, TaskService::class.java))
        }
    }
}
