package com.lia.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import com.lia.assistant.ui.BubbleView
import com.lia.assistant.ui.MainActivity

/**
 * Minimize karne par chhoti gol LIA screen par tairti rahegi.
 * Drag karo, tap karo → voice screen khul jayegi.
 */
class BubbleService : Service() {

    private var wm: WindowManager? = null
    private var bubble: BubbleView? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        startFg()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val size = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 76f, resources.displayMetrics).toInt()
        val v = BubbleView(this)
        params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40; y = 400
        }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        var downT = 0L; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = params!!.x; startY = params!!.y
                    downT = System.currentTimeMillis(); moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (dx * dx + dy * dy > 100) moved = true
                    params!!.x = startX + dx; params!!.y = startY + dy
                    wm?.updateViewLayout(v, params); true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved && System.currentTimeMillis() - downT < 400) openVoice()
                    true
                }
                else -> false
            }
        }
        try { wm?.addView(v, params); bubble = v } catch (_: Exception) { stopSelf() }
        // Home ke voice loop ka rang yahan bhi — sunte waqt hara, bolte waqt gulabi
        com.lia.assistant.ui.VoiceStateBus.listen { s ->
            try { bubble?.post { bubble?.state = s } } catch (_: Exception) { }
        }
    }

    private fun openVoice() {
        val i = Intent(this, MainActivity::class.java)
            .putExtra("tab", MainActivity.TAB_HOME)
            .putExtra("autostart", true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(i)
    }

    private fun startFg() {
        val ch = "lia_bubble"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(ch, "Priya Bubble", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, ch)
            .setContentTitle("Priya chal rahi hai 🫧")
            .setContentText("Bubble se kahin se bhi baat karo")
            .setSmallIcon(android.R.drawable.sym_def_app_icon)
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            @Suppress("DEPRECATION") startForeground(1, n)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { com.lia.assistant.ui.VoiceStateBus.clear() } catch (_: Exception) { }
        try { wm?.removeView(bubble) } catch (_: Exception) {}
        bubble = null; wm = null
        super.onDestroy()
    }

    companion object {
        fun start(ctx: Context) {
            val i = Intent(ctx, BubbleService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, BubbleService::class.java)) }
    }
}
