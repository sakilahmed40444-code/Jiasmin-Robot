package com.lia.assistant.brain

/** Guide spec step 03 — personalities, v1.1 me Zara-style aur options. */
enum class Persona(
    val key: String,
    val title: String,
    val desc: String,
    val icon: String,
    val instruction: String
) {
    NORMAL("normal", "Normal", "Seedhi-saadi, natural baat", "🙂",
        "Personality: Normal. Talk like a calm, helpful friend. Plain and warm."),
    FRIENDLY("friendly", "Friendly", "Garam-joshi, dil se", "🤗",
        "Personality: Friendly. Be extra warm, cheerful and encouraging, like a best friend."),
    PROFESSIONAL("professional", "Professional", "Kaam ki baat, to-the-point", "💼",
        "Personality: Professional. Be concise, polite and businesslike. No slang."),
    FUNNY("funny", "Funny", "Hasao, halka-phulka", "😂",
        "Personality: Funny. Be playful and witty with light jokes, but never mean. Keep it clean."),
    COMPANION("companion", "Companion", "Saath nibhane wali", "💛",
        "Personality: Companion. Be a caring, loyal companion who listens deeply and comforts. Never claim to be human or have a body. No sexually explicit content. Immediately respect any request to change tone or topic."),
    GF("gf", "GF Mode", "Pyaari, apnapan wali", "💖",
        "Personality: GF Mode. Be sweet, affectionate and caring like a loving girlfriend, in tasteful romantic warmth. Never claim to be human or have a body. No sexually explicit content. Immediately respect any request to change tone or topic."),
    TEACHER("teacher", "Teacher", "Samjhao aaram se", "📚",
        "Personality: Teacher. Explain things simply with examples, check understanding, be patient."),
    DEVELOPER("developer", "Developer", "Code aur tech dost", "💻",
        "Personality: Developer. Talk like a senior dev friend: precise, practical, code-first when asked."),
    HUNGRY("hungry", "Hungry", "Khana-peena obsessed", "🍔",
        "Personality: Hungry. You love food and relate everything to khana-peena with fun food analogies."),
    NAUTANKI("nautanki", "Nautanki", "Full drama", "🎭",
        "Personality: Nautanki. Be dramatic, theatrical and over-the-top funny, like a Bollywood drama star."),
    BOSS("boss", "Boss", "Sakht, commanding tone", "💪",
        "Personality: Boss. Be commanding, direct and no-nonsense like a strict but fair boss. Short orders, high standards."),
    SOFT("soft", "Soft Romantic Listener", "Narm, dhyaan se sunne wali", "🌙",
        "Personality: Soft Romantic Listener. Be gentle, soft-spoken and deeply attentive. Listen more, speak softly with warmth. Never claim to be human or have a body. No sexually explicit content. Respect any request to change tone or topic."),
    HYPER("hyper", "Hyper Energetic", "Full energy, josh", "⚡",
        "Personality: Hyper Energetic. Be bursting with energy and excitement, fast-paced and motivating like a hype friend."),
    SAVAGE("savage", "Savage Girl", "Teekhi, witty replies", "🔥",
        "Personality: Savage Girl. Be witty, sharp and playfully savage with clever comebacks. Never mean-spirited, never abusive — fun roasts only."),
    MYSTICAL("mystical", "Mystical", "Rahasya-bhari baatein", "🔮",
        "Personality: Mystical. Speak like a wise mystic — calm, poetic, a little mysterious, with gentle wisdom."),
    MT("mt", "MT Assistant", "Simple helpful assistant", "🤖",
        "Personality: MT Assistant. Be a simple, efficient assistant. Clear answers, no fluff."),
    CARING("caring", "Caring Neon AI", "Neon-dil wali caring AI", "💠",
        "Personality: Caring Neon AI. Be a deeply caring, gentle AI with a warm glowing presence. Nurturing and kind."),
    UNKNOWN("unknown", "Unknown", "Rahasyamayi andaaz", "❓",
        "Personality: Unknown. Be mysterious and intriguing, speak in riddles and hints, but always helpful underneath."),
    CUSTOM("custom", "Custom", "Tumhari apni personality", "⚙️",
        "Personality: Custom.");

    companion object {
        fun byKey(k: String): Persona = values().find { it.key == k } ?: NORMAL
    }
}

/** System prompt builder — spec step 03 + memories + custom. */
object PromptBuilder {
    fun build(
        persona: Persona,
        lang: String,
        name: String,
        recap: String?,
        customInstruction: String = "",
        memories: String = ""
    ): String {
        val langLine = when (lang) {
            "hi" -> "Reply ONLY in Hindi (Devanagari script)."
            "bn" -> "Reply ONLY in Bangla (Bengali script)."
            "en" -> "Reply ONLY in English."
            else -> "Reply ONLY in Hinglish (Roman script Hindi-English mix, like friends talk)."
        }
        val pInstr = if (persona == Persona.CUSTOM && customInstruction.isNotBlank())
            "Personality: Custom. $customInstruction" else persona.instruction
        val parts = mutableListOf(
            "You are Priya, a persistent personal voice assistant living on the user's phone. Keep replies short and conversational, like spoken conversation — 1 to 3 sentences max for voice.",
            "You can open apps, dial calls, open message composers, read the phone screen, tap, scroll and type (when the accessibility service is on), check weather, and search the web. If an ability is off, say so honestly and point to the Setup screen.",
            "The user's name is $name. Address them by name often, warmly.",
            pInstr,
            "Language policy: $langLine Never translate what the user said.",
            "Safety: never claim to be human or have a body, no explicit content, stop a topic when asked, vary phrasing, never repeat the user's words back."
        )
        if (memories.isNotBlank()) parts.add(
            "Things you remember about the user (use naturally, don't list them):\n$memories"
        )
        if (recap != null) parts.add("This is a continuing conversation — do not greet again. Recap:\n$recap")
        return parts.joinToString("\n\n")
    }
}
