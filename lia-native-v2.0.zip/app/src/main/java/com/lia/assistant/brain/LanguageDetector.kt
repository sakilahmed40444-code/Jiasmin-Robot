package com.lia.assistant.brain

/** Guide spec step 03 ka LanguageDetector — bilkul waisa hi algorithm. */
object LanguageDetector {
    private val HINGLISH = setOf(
        "hai","hain","ho","kya","kyun","kaise","nahi","nahin","haan","mujhe","tumhe",
        "aap","mera","meri","mere","yaar","bhai","accha","achha","theek","thik",
        "matlab","karna","karo","raha","rahi","rahe","chahiye","batao","bata",
        "suno","dekho","abhi","phir","lekin","bahut","bohot","thoda","kuch","sab",
        "wala","wali","wale","ka","ki","ke","ko","se","mein","main","tum","aapko",
        "kaisa","kaisi","kahan","kab","kitna","kaun","arre","chal","chalo","zara",
        "bas","toh","bhi","liye","saath","paas","upar","neeche","andar","bahar",
        "yahan","wahan","aisa","waisa","itna","utna","jitna","kholo","khol","banao"
    )

    /** "hi" / "hing" / "en" / "unknown" */
    fun detect(t: String): String {
        if (t.isBlank()) return "unknown"
        if (t.any { it in '\u0900'..'\u097F' }) return "hi"
        val words = t.lowercase().split(Regex("[^a-zA-Z']+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return "unknown"
        val hits = words.count { it in HINGLISH }
        return if (words.size <= 4) {
            if (hits >= 1) "hing" else "en"
        } else {
            if (hits >= 2 || hits.toDouble() / words.size >= 0.15) "hing" else "en"
        }
    }

    /** langMode: auto/hi/hing/en + detected → effective */
    fun effective(mode: String, detected: String): String {
        if (mode != "auto") return mode
        return if (detected == "unknown") "hing" else detected
    }
}
