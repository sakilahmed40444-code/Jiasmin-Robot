package com.lia.assistant.ui

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import com.lia.assistant.forge.ForgeManager
import java.io.File

class ForgeFragment : Fragment() {
    private fun act() = activity as MainActivity

    private lateinit var input: android.widget.EditText
    private lateinit var reactor: ForgeReactorView
    private lateinit var stageTv: TextView
    private lateinit var pctTv: TextView
    private lateinit var statsTv: TextView
    private lateinit var logBox: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var webView: WebView
    private lateinit var toolbar: LinearLayout
    private lateinit var sceneBox: LinearLayout
    private var mgr: ForgeManager? = null
    private var lastHtml: String? = null
    private var lastSubject = ""

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val sv = Ui.scrollCol(ctx)
        val col = Ui.colLayout(ctx)
        sv.addView(col)

        col.addView(Ui.title(ctx, "Website Forge 🔥"))
        col.addView(Ui.sub(ctx, "\"Ek cafe ki animated website banao\" — bolo ya type karo, banta dekho."))

        input = Ui.input(ctx, "e.g. ek cafe ki animated website banao")
        col.addView(input)
        val row = Ui.row(ctx)
        row.addView(Ui.btn(ctx, "🔥 Forge karo") { startForge(input.text.toString().trim()) })
        row.addView(Ui.btn(ctx, "📁 Meri websites", false) { showMySites() })
        col.addView(row)

        // scene
        sceneBox = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        reactor = ForgeReactorView(ctx)
        reactor.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 340))
        sceneBox.addView(reactor)
        stageTv = Ui.tv(ctx, "Apna idea padh rahi hoon…", 18, Ui.TEXT)
        stageTv.setTypeface(stageTv.typeface, android.graphics.Typeface.ITALIC)
        stageTv.gravity = Gravity.CENTER_HORIZONTAL
        sceneBox.addView(stageTv)
        pctTv = Ui.tv(ctx, "0%", 32, Ui.ACCENT, true)
        pctTv.gravity = Gravity.CENTER_HORIZONTAL
        sceneBox.addView(pctTv)
        progress = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        progress.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        sceneBox.addView(progress)
        statsTv = Ui.tv(ctx, "", 13, Ui.TEXT2)
        statsTv.gravity = Gravity.CENTER_HORIZONTAL
        sceneBox.addView(statsTv)
        val cancelRow = Ui.row(ctx); cancelRow.gravity = Gravity.CENTER_HORIZONTAL
        cancelRow.addView(Ui.btn(ctx, "✕ Cancel", false) { cancelForge() })
        sceneBox.addView(cancelRow)
        col.addView(sceneBox)

        col.addView(Ui.sec(ctx, "Build log"))
        logBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(logBox)

        // result viewer
        webView = WebView(ctx)
        webView.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 420))
        webView.visibility = View.GONE
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, url: String): Boolean {
                try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) } catch (_: Exception) {}
                return true
            }
        }
        col.addView(webView)

        toolbar = Ui.row(ctx)
        toolbar.gravity = Gravity.CENTER_HORIZONTAL
        toolbar.visibility = View.GONE
        toolbar.addView(Ui.btn(ctx, "📤 Share", false) { shareSite() })
        toolbar.addView(Ui.btn(ctx, "💾 Save", false) { saveSite() })
        toolbar.addView(Ui.btn(ctx, "✏️ Edit", false) { editSite() })
        toolbar.addView(Ui.btn(ctx, "🔁 Rebuild", false) { startForge(lastSubject) })
        col.addView(toolbar)
        return sv
    }

    fun startForge(subjectRaw: String) {
        val subject = subjectRaw.ifBlank { input.text.toString().trim() }
        if (subject.isBlank()) { act().toast("Pehle batao kaisi website chahiye"); return }
        val key = act().prefs.apiKey
        if (key.isBlank()) { act().toast("Forge ke liye Settings me Gemini API key dalo 🔑"); act().go(MainActivity.TAB_SETTINGS); return }
        lastSubject = subject
        input.setText(subject)
        sceneBox.visibility = View.VISIBLE
        webView.visibility = View.GONE
        toolbar.visibility = View.GONE
        logBox.removeAllViews()
        reactor.failed = false
        mgr?.cancel()
        mgr = ForgeManager(key, act().prefs.model)
        mgr?.start(subject, null, null, object : ForgeManager.Listener {
            override fun onStage(i: Int) = ui { stageTv.text = ForgeManager.STAGE_LABELS.getOrElse(i) { "" }; reactor.stage = i }
            override fun onProgress(pct: Int, kb: Double, sections: Int, tps: Double, secs: Int) = ui {
                progress.progress = pct; pctTv.text = "$pct%"
                statsTv.text = "📦 ${"%.1f".format(kb)} KB   🧱 $sections sections   ⚡ ${"%.0f".format(tps)} tok/s   ⏱ ${secs}s"
            }
            override fun onLog(line: String) = ui { flog(line) }
            override fun onDone(html: String) = ui {
                lastHtml = html
                saveSiteRecord(subject, html)
                flog("✅ Website taiyaar!")
                reactor.burst()
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    sceneBox.visibility = View.GONE
                    webView.visibility = View.VISIBLE
                    toolbar.visibility = View.VISIBLE
                    webView.loadDataWithBaseURL("https://localhost/", html, "text/html", "utf-8", null)
                    act().toast("🎉 Website taiyaar!")
                }, 900)
            }
            override fun onError(msg: String) = ui {
                flog("❌ $msg"); reactor.failed = true
                act().toast("Forge fail: $msg")
            }
        })
        act().toast("🔥 Forge shuru!")
    }

    private fun ui(f: () -> Unit) { activity?.runOnUiThread(f) }

    private fun flog(t: String) {
        val ctx = requireContext()
        val v = Ui.tv(ctx, "⚡ $t", 13, Ui.TEXT2)
        v.setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 8), Ui.dp(ctx, 10), Ui.dp(ctx, 8))
        v.setBackgroundColor(Ui.col(Ui.SURFACE))
        val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        p.bottomMargin = Ui.dp(ctx, 6)
        v.layoutParams = p
        logBox.addView(v, 0)
        while (logBox.childCount > 6) logBox.removeViewAt(logBox.childCount - 1)
    }

    private fun cancelForge() { mgr?.cancel(); flog("⛔ Cancel kar diya"); sceneBox.visibility = View.GONE }

    private fun siteFile(subject: String, html: String): File {
        val dir = File(requireContext().cacheDir, "sites").apply { mkdirs() }
        return File(dir, "lia-website.html").apply { writeText(html) }
    }

    private fun shareSite() {
        val html = lastHtml ?: return
        try {
            val f = siteFile(lastSubject, html)
            val uri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", f)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/html"; putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "Website share karo"))
        } catch (e: Exception) { act().toast("Share fail: ${e.message}") }
    }

    private fun saveSite() {
        val html = lastHtml ?: return
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.Downloads.DISPLAY_NAME, "lia-${System.currentTimeMillis()}.html")
                    put(android.provider.MediaStore.Downloads.MIME_TYPE, "text/html")
                }
                val uri = requireContext().contentResolver.insert(
                    android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                requireContext().contentResolver.openOutputStream(uri!!)?.use { it.write(html.toByteArray()) }
                act().toast("Downloads me save ho gaya 💾")
            } else {
                val f = File(android.os.Environment.getExternalStoragePublicDirectory(
                    android.os.Environment.DIRECTORY_DOWNLOADS), "lia-${System.currentTimeMillis()}.html")
                f.writeText(html); act().toast("Save ho gaya 💾")
            }
        } catch (e: Exception) { act().toast("Save fail: ${e.message}") }
    }

    private fun editSite() {
        val html = lastHtml ?: return
        val ctx = requireContext()
        val et = Ui.input(ctx, "Badlav likho… e.g. hero ko dark karo")
        android.app.AlertDialog.Builder(ctx)
            .setTitle("✏️ Edit website")
            .setView(et)
            .setPositiveButton("🔥 Apply") { _, _ ->
                val change = et.text.toString().trim()
                if (change.isBlank()) return@setPositiveButton
                sceneBox.visibility = View.VISIBLE
                webView.visibility = View.GONE
                toolbar.visibility = View.GONE
                logBox.removeAllViews()
                flog("Edit: $change")
                mgr?.cancel()
                mgr = ForgeManager(act().prefs.apiKey, act().prefs.model)
                mgr?.start(lastSubject, html, change, object : ForgeManager.Listener {
                    override fun onStage(i: Int) = ui { stageTv.text = ForgeManager.STAGE_LABELS.getOrElse(i) { "" }; reactor.stage = i }
                    override fun onProgress(pct: Int, kb: Double, sections: Int, tps: Double, secs: Int) = ui { progress.progress = pct; pctTv.text = "$pct%" }
                    override fun onLog(line: String) = ui { flog(line) }
                    override fun onDone(h: String) = ui {
                        lastHtml = h; saveSiteRecord("$lastSubject (edit)", h)
                        flog("✅ Edit ho gaya!"); reactor.burst()
                        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                            sceneBox.visibility = View.GONE
                            webView.visibility = View.VISIBLE
                            toolbar.visibility = View.VISIBLE
                            webView.loadDataWithBaseURL("https://localhost/", h, "text/html", "utf-8", null)
                        }, 900)
                    }
                    override fun onError(msg: String) = ui { flog("❌ $msg"); reactor.failed = true }
                })
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun saveSiteRecord(subject: String, html: String) {
        val sp = requireContext().getSharedPreferences("lia_sites", 0)
        val arr = org.json.JSONArray(sp.getString("sites", "[]"))
        val rec = org.json.JSONObject()
            .put("subject", subject).put("t", System.currentTimeMillis())
            .put("html", html.take(120000))
        val narr = org.json.JSONArray().put(rec)
        for (i in 0 until minOf(arr.length(), 9)) narr.put(arr.getJSONObject(i))
        sp.edit().putString("sites", narr.toString()).apply()
    }

    private fun showMySites() {
        val ctx = requireContext()
        val sp = ctx.getSharedPreferences("lia_sites", 0)
        val arr = org.json.JSONArray(sp.getString("sites", "[]"))
        if (arr.length() == 0) { act().toast("Abhi koi website nahi bani"); return }
        val items = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            o.getString("subject") + " — " + java.text.SimpleDateFormat("d MMM h:mm a", java.util.Locale("en", "IN")).format(java.util.Date(o.getLong("t")))
        }.toTypedArray()
        android.app.AlertDialog.Builder(ctx)
            .setTitle("📁 Meri websites")
            .setItems(items) { _, w ->
                val o = arr.getJSONObject(w)
                lastHtml = o.getString("html"); lastSubject = o.getString("subject")
                sceneBox.visibility = View.GONE
                webView.visibility = View.VISIBLE
                toolbar.visibility = View.VISIBLE
                webView.loadDataWithBaseURL("https://localhost/", lastHtml!!, "text/html", "utf-8", null)
            }
            .show()
    }

    override fun onDestroyView() { mgr?.cancel(); super.onDestroyView() }
}
