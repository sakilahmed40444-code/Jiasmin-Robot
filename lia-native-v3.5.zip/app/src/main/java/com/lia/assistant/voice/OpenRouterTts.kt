package com.lia.assistant.voice

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger

/**
 * OpenRouter TTS — POST /api/v1/audio/speech (OpenAI-compatible).
 * Model: google/gemini-3.1-flash-tts-preview → Kore, Aoede… (Gemini prebuilt voices).
 * Shudhu API-key voice — kono robot voice na.
 */
object OpenRouterTts {

    @Volatile private var player: MediaPlayer? = null
    @Volatile private var stopped = false
    private var appCtx: Context? = null
    private val gen = AtomicInteger(0)
    private val main = Handler(Looper.getMainLooper())

    fun init(ctx: Context) { appCtx = ctx.applicationContext }

    /**
     * onDone: bola shesh (ba bola jayni) — loop egobe.
     * onError("key"): 401/403 — key bhul/expire. onError("net"): network/server fail.
     */
    fun speak(text: String, voice: String, apiKey: String,
              onDone: () -> Unit, onError: (String) -> Unit = {}) {
        init(appCtx ?: return onDone())
        stop()
        stopped = false
        val g = gen.incrementAndGet()
        Thread {
            try {
                val res = fetchMp3(text, voice, apiKey)
                if (stopped || gen.get() != g) { postDone(g, onDone); return@Thread }
                if (res == null) {
                    main.post { onError(lastErr); }
                    postDone(g, onDone); return@Thread
                }
                playMp3(res, g, onDone)
            } catch (e: Exception) {
                Log.e("OpenRouterTts", "speak fail", e)
                main.post { onError("net") }
                postDone(g, onDone)
            }
        }.start()
    }

    fun stop() {
        stopped = true
        gen.incrementAndGet()
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
    }

    private fun postDone(g: Int, onDone: () -> Unit) {
        main.post { if (gen.get() == g) onDone() }
    }

    @Volatile private var lastErr = "net"

    private fun fetchMp3(text: String, voice: String, apiKey: String): ByteArray? {
        lastErr = "net"
        val clean = text.take(800)
        val body = org.json.JSONObject().apply {
            put("model", "google/gemini-3.1-flash-tts-preview")
            put("input", clean)
            put("voice", voice.ifBlank { "Kore" })
            put("response_format", "mp3")
            put("instructions", "Speak warmly and naturally, like a caring friend.")
        }.toString()
        val c = URL("https://openrouter.ai/api/v1/audio/speech")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer $apiKey")
        c.setRequestProperty("HTTP-Referer", "https://priya.assistant")
        c.setRequestProperty("X-Title", "Priya Assistant")
        c.connectTimeout = 25000
        c.readTimeout = 45000
        c.doOutput = true
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        if (c.responseCode == 401 || c.responseCode == 403) { lastErr = "key"; return null }
        if (c.responseCode != 200) {
            val err = try { c.errorStream?.bufferedReader()?.readText()?.take(200) } catch (_: Exception) { "" }
            Log.e("OpenRouterTts", "HTTP ${c.responseCode}: $err")
            return null
        }
        return c.inputStream.use { it.readBytes() }.takeIf { it.size > 1000 }
    }

    private fun playMp3(mp3: ByteArray, g: Int, onDone: () -> Unit) {
        val ctx = appCtx ?: run { postDone(g, onDone); return }
        main.post {
            if (stopped || gen.get() != g) { postDone(g, onDone); return@post }
            try {
                val f = File(ctx.cacheDir, "priya_tts_${System.currentTimeMillis()}.mp3")
                f.writeBytes(mp3)
                val mp = MediaPlayer()
                player = mp
                var done = false
                fun finish() {
                    if (done) return
                    done = true
                    try { f.delete() } catch (_: Exception) { }
                    if (gen.get() == g) onDone()
                }
                mp.setOnCompletionListener { finish() }
                mp.setOnErrorListener { _, _, _ -> finish(); true }
                mp.setDataSource(f.absolutePath)
                mp.prepare()
                if (stopped || gen.get() != g) { finish(); return@post }
                mp.start()
                // watchdog: 90s me khatm na ho to force done (loop atakna nahi chahiye)
                main.postDelayed({ finish() }, 90000)
            } catch (e: Exception) {
                Log.e("OpenRouterTts", "play fail", e)
                postDone(g, onDone)
            }
        }
    }
}
