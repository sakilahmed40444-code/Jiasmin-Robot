package com.lia.assistant.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.*
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.lia.assistant.brain.Weather
import kotlin.math.sin

/** Priya Assistant — Zara-style neon dashboard. */
class HomeFragment : Fragment() {
    private fun act() = activity as MainActivity
    private var orb: BubbleView? = null
    private var weatherTv: TextView? = null
    private var locTv: TextView? = null
    private var loveSwitch: Switch? = null

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val root = ScrollView(ctx).apply { setBackgroundColor(Ui.col(Ui.BG)) }
        val col = Ui.colLayout(ctx, 14)
        root.addView(col)

        // ---- Branding ----
        val brand = Ui.tv(ctx, "Priya", 34, Ui.TEXT, true).apply { gravity = Gravity.CENTER }
        val sub = Ui.tv(ctx, "💗  AI ASSISTANT  💗", 14, Ui.ACCENT, true).apply { gravity = Gravity.CENTER }
        col.addView(brand); col.addView(sub)
        col.addView(sp(10))

        // ---- System status card ----
        val statusCard = card(ctx)
        val sRow = hrow(ctx)
        sRow.addView(Ui.tv(ctx, "SYSTEM STATUS", 13, Ui.TEXT2, true))
        val dot = View(ctx).apply {
            setBackgroundColor(Ui.col(Ui.NEON_GREEN))
            layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 10), Ui.dp(ctx, 10)).apply {
                gravity = Gravity.CENTER_VERTICAL; leftMargin = Ui.dp(ctx, 8)
            }
        }
        sRow.addView(dot)
        val op = TextView(ctx).apply {
            text = "OPERATIONAL"; setTextColor(Ui.col(Ui.NEON_GREEN)); textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                gravity = Gravity.CENTER_VERTICAL
            }
            gravity = Gravity.END
        }
        sRow.addView(op)
        statusCard.addView(sRow)
        col.addView(statusCard)
        col.addView(sp(10))

        // ---- Main grid: left mini cards + AI core unit ----
        val grid = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val mini = listOf(
            Pair("🧠" to "Mem", MainActivity.TAB_SETTINGS),
            Pair("✨" to "Soul", MainActivity.TAB_SETTINGS),
            Pair("🗄️" to "Data", MainActivity.TAB_SETTINGS),
            Pair("📊" to "Stats", MainActivity.TAB_COINS)
        )
        for ((label, tab) in mini) {
            val mc = card(ctx).apply { setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 10), Ui.dp(ctx, 10), Ui.dp(ctx, 10)) }
            val t1 = Ui.tv(ctx, label.first, 18, Ui.TEXT, true).apply { gravity = Gravity.CENTER }
            val t2 = Ui.tv(ctx, label.second, 12, Ui.TEXT2, true).apply { gravity = Gravity.CENTER }
            val t3 = Ui.tv(ctx, "Connected", 10, Ui.NEON_GREEN).apply { gravity = Gravity.CENTER }
            mc.addView(t1); mc.addView(t2); mc.addView(t3)
            mc.setOnClickListener { act().go(tab) }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = Ui.dp(ctx, 8)
            mc.layoutParams = lp
            left.addView(mc)
        }
        grid.addView(left)
        grid.addView(sp(10, true))

        val core = card(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.6f)
        }
        core.addView(Ui.tv(ctx, "AI CORE UNIT", 13, Ui.TEXT2, true).apply { gravity = Gravity.CENTER })
        orb = BubbleView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 130), Ui.dp(ctx, 130)).apply {
                gravity = Gravity.CENTER; topMargin = Ui.dp(ctx, 6); bottomMargin = Ui.dp(ctx, 6)
            }
            state = BubbleView.State.IDLE
        }
        core.addView(orb)
        core.addView(Ui.tv(ctx, "❤️  ACTIVE & LEARNING  ❤️", 11, Ui.ACCENT, true).apply { gravity = Gravity.CENTER })
        val start = Ui.btn(ctx, "🎙️  START PRIYA", true) {
            act().autoStartVoice = true
            act().go(MainActivity.TAB_VOICE)
        }
        core.addView(start)
        grid.addView(core)
        col.addView(grid)
        col.addView(sp(10))

        // ---- System overview ----
        col.addView(Ui.tv(ctx, "SYSTEM OVERVIEW", 13, Ui.TEXT2, true))
        col.addView(sp(4))
        val ov = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val loveCard = card(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        loveCard.addView(Ui.tv(ctx, "💘 Love Mode", 13, Ui.TEXT, true).apply { gravity = Gravity.CENTER })
        loveSwitch = Switch(ctx).apply {
            isChecked = act().prefs.loveMode
            setOnCheckedChangeListener { _, on ->
                act().prefs.loveMode = on
                act().toast(if (on) "Love Mode ON 💘" else "Love Mode OFF")
            }
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.CENTER }
        }
        loveCard.addView(loveSwitch)
        ov.addView(loveCard); ov.addView(sp(8, true))
        ov.addView(sysCard(ctx, "⚡", "CPU POWER", "98%"))
        ov.addView(sp(8, true))
        ov.addView(sysCard(ctx, "📶", "NETWORK", "CONNECTED"))
        col.addView(ov)
        col.addView(sp(10))

        // ---- Diagnostics waveform ----
        val dg = card(ctx)
        dg.addView(Ui.tv(ctx, "AI CORE DIAGNOSTICS", 13, Ui.TEXT2, true))
        dg.addView(WaveView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 44))
        })
        col.addView(dg)
        col.addView(sp(10))

        // ---- Location + weather ----
        val lw = card(ctx)
        locTv = Ui.tv(ctx, "📍 LOCATION", 13, Ui.TEXT2, true)
        lw.addView(locTv)
        lw.addView(Ui.tv(ctx, "Location services status yahan dikhega.", 12, Ui.TEXT3))
        weatherTv = Ui.tv(ctx, "🌤️ LOCAL WEATHER  --°C", 14, Ui.TEXT, true)
        lw.addView(weatherTv)
        val tz = java.util.TimeZone.getDefault().id
        lw.addView(Ui.tv(ctx, "🕐 TIMEZONE  $tz", 12, Ui.TEXT2))
        lw.setOnClickListener { loadWeather() }
        col.addView(lw)
        col.addView(sp(10))

        // ---- Voice commands ----
        val vc = card(ctx)
        vc.addView(Ui.tv(ctx, "🎤 VOICE COMMANDS", 13, Ui.TEXT2, true))
        val p = act().prefs
        vc.addView(cmdRow(ctx, "WAKE WORD", p.wakeWord.ifBlank { "hello lia" }, true))
        vc.addView(cmdRow(ctx, "DISMISS WORD", p.dismissWord.ifBlank { "bye bye" }, true))
        vc.addView(cmdRow(ctx, "AUTO TIMEOUT", "${p.wakeTimeoutSec}s", true))
        vc.setOnClickListener { act().go(MainActivity.TAB_VOICE) }
        col.addView(vc)
        col.addView(sp(10))

        // ---- Games ----
        val gm = card(ctx)
        gm.addView(Ui.tv(ctx, "🎮 GAMES", 13, Ui.TEXT2, true))
        val grow = hrow(ctx)
        grow.addView(Ui.tv(ctx, "🎲 Play Ludo\nSingle Player vs Bot", 14, Ui.TEXT, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        grow.addView(Ui.btn(ctx, "PLAY", true) { openLudo() })
        gm.addView(grow)
        col.addView(gm)
        col.addView(sp(10))

        // ---- Forge ----
        val fg = card(ctx)
        val frow = hrow(ctx)
        frow.addView(Ui.tv(ctx, "🔥 Website Forge\nBolke website banao", 14, Ui.TEXT, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        frow.addView(Ui.btn(ctx, "OPEN", true) { act().go(MainActivity.TAB_FORGE) })
        fg.addView(frow)
        col.addView(fg)
        col.addView(sp(10))

        // ---- Chat ----
        val ch = card(ctx)
        val crow = hrow(ctx)
        crow.addView(Ui.tv(ctx, "💬 Chat\nType karke baat karo", 14, Ui.TEXT, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        crow.addView(Ui.btn(ctx, "OPEN", true) { act().go(MainActivity.TAB_CHAT) })
        ch.addView(crow)
        col.addView(ch)
        col.addView(sp(10))

        // ---- Always here ----
        val al = card(ctx)
        al.addView(Ui.tv(ctx, "I'm here for you, always ❤️", 15, Ui.ACCENT, true).apply { gravity = Gravity.CENTER })
        col.addView(al)
        col.addView(sp(24))

        loadWeather()
        return root
    }

    private fun openLudo() {
        val act = activity ?: return
        val containerId = (view?.parent as? View)?.id ?: return
        parentFragmentManager.beginTransaction()
            .replace(containerId, LudoFragment())
            .addToBackStack(null).commit()
    }

    private fun loadWeather() {
        val ctx = context ?: return
        val hasLoc = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED
        if (!hasLoc) {
            locTv?.text = "📍 LOCATION — off (Settings > Perms me on karo)"
            weatherTv?.text = "🌤️ LOCAL WEATHER  --°C"
            return
        }
        try {
            val lm = ctx.getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
            val loc: Location? = try {
                lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            } catch (_: Exception) { null }
            if (loc == null) {
                weatherTv?.text = "🌤️ LOCAL WEATHER  location mil nahi rahi…"
                return
            }
            locTv?.text = "📍 LOCATION  %.2f, %.2f".format(loc.latitude, loc.longitude)
            weatherTv?.text = "🌤️ LOCAL WEATHER  load ho raha…"
            Thread {
                val w = try { Weather.current(loc.latitude, loc.longitude) } catch (_: Exception) { null }
                Handler(Looper.getMainLooper()).post {
                    weatherTv?.text = if (w != null) "🌤️ LOCAL WEATHER  $w" else "🌤️ LOCAL WEATHER  --°C"
                }
            }.start()
        } catch (_: Exception) { }
    }

    private fun card(ctx: android.content.Context): LinearLayout {
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.col(Ui.SURFACE))
            val p = Ui.dp(ctx, 12)
            setPadding(p, p, p, p)
        }
    }

    private fun hrow(ctx: android.content.Context) = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun sp(dp: Int, horiz: Boolean = false): View {
        val v = View(requireContext())
        v.layoutParams = if (horiz)
            LinearLayout.LayoutParams(Ui.dp(requireContext(), dp), 1)
        else
            LinearLayout.LayoutParams(1, Ui.dp(requireContext(), dp))
        return v
    }

    private fun sysCard(ctx: android.content.Context, icon: String, label: String, value: String): LinearLayout {
        val c = card(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        c.addView(Ui.tv(ctx, icon, 18, Ui.TEXT, true).apply { gravity = Gravity.CENTER })
        c.addView(Ui.tv(ctx, label, 10, Ui.TEXT3, true).apply { gravity = Gravity.CENTER })
        c.addView(Ui.tv(ctx, value, 12, Ui.NEON_GREEN, true).apply { gravity = Gravity.CENTER })
        return c
    }

    private fun cmdRow(ctx: android.content.Context, label: String, value: String, active: Boolean): View {
        val r = hrow(ctx)
        r.addView(Ui.tv(ctx, label, 12, Ui.TEXT3, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        r.addView(Ui.tv(ctx, "\"$value\"", 13, Ui.TEXT, true))
        r.addView(Ui.tv(ctx, if (active) "  ACTIVE" else "", 11, Ui.NEON_GREEN, true))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(ctx, 4)
        r.layoutParams = lp
        return r
    }

    /** Simple animated waveform (decorative). */
    class WaveView(ctx: android.content.Context) : View(ctx) {
        private val paint = Paint().apply { color = Ui.col(Ui.NEON_GREEN); strokeWidth = 4f; style = Paint.Style.STROKE }
        private var ph = 0f
        private val h = Handler(Looper.getMainLooper())
        private val tick = object : Runnable {
            override fun run() { ph += 0.25f; invalidate(); h.postDelayed(this, 60) }
        }
        override fun onAttachedToWindow() { super.onAttachedToWindow(); h.post(tick) }
        override fun onDetachedFromWindow() { super.onDetachedFromWindow(); h.removeCallbacks(tick) }
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val w = width.toFloat(); val hh = height / 2f
            val path = Path()
            var first = true
            var x = 0f
            while (x <= w) {
                val y = hh + (sin(x / 22 + ph) * hh * 0.7f) * sin(x / 130 + ph * 0.6f)
                if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
                x += 6f
            }
            c.drawPath(path, paint)
        }
    }
}
