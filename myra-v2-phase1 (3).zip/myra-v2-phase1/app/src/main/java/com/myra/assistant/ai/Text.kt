package com.myra.assistant.ai

object TextSanitizer {
    private val link = Regex("\\[([^\\]]*)]\\([^)]*\\)")
    private val url = Regex("https?://\\S+")
    private val md = Regex("[*#`_~>|]+")
    private val emoji = Regex("[\\p{So}\\u200d\\uFE0F]")
    private val ws = Regex("\\s+")
    fun clean(s: String): String =
        s.replace(link, "$1").replace(url, "").replace(md, "").replace("&", " and ")
            .replace(emoji, "").replace(ws, " ").trim()
}

/** Flushes sentences early so speech starts while the model is still writing. */
class SentenceChunker(private val onChunk: (String) -> Unit) {
    private val sb = StringBuilder()
    private var first = true
    fun add(s: String) {
        for (ch in s) {
            sb.append(ch)
            val endMark = ch == '.' || ch == '?' || ch == '!' || ch == '।' || ch == '॥' || ch == '\n'
            if ((endMark && sb.length >= 12) || (first && ch == ' ' && sb.length >= 40) || (ch == ',' && sb.length > 120)) flush()
        }
    }
    fun flush() {
        val t = sb.toString().trim(); sb.clear()
        if (t.isNotEmpty()) { first = false; onChunk(t) }
    }
}

/** Splits a stream into spoken text and ``` fenced code (code is never read aloud). */
class CodeSplitter(private val onText: (String) -> Unit, private val onCode: (String, String) -> Unit) {
    private var carry = ""
    private var inCode = false
    private var langPending = false
    private var langBuf = ""
    private var lang = ""
    private val code = StringBuilder()

    fun feed(d: String) {
        carry += d
        while (true) {
            val i = carry.indexOf("```")
            if (i < 0) {
                val keep = when { carry.endsWith("``") -> 2; carry.endsWith("`") -> 1; else -> 0 }
                emit(carry.dropLast(keep)); carry = carry.takeLast(keep); return
            }
            emit(carry.substring(0, i)); carry = carry.substring(i + 3)
            if (inCode) { closeCode() } else { inCode = true; langPending = true; langBuf = ""; code.setLength(0) }
        }
    }

    private fun emit(t: String) {
        if (t.isEmpty()) return
        if (!inCode) { onText(t); return }
        if (langPending) {
            langBuf += t
            val nl = langBuf.indexOf('\n')
            if (nl >= 0) { lang = langBuf.substring(0, nl).trim(); code.append(langBuf.substring(nl + 1)); langPending = false }
        } else code.append(t)
    }

    private fun closeCode() {
        inCode = false
        if (langPending) { code.append(langBuf); lang = "" ; langPending = false }
        val c = code.toString().trimEnd()
        if (c.isNotBlank()) onCode(lang.ifBlank { "text" }, c)
        code.setLength(0); lang = ""
    }

    fun finish() {
        if (carry.isNotEmpty()) { val c = carry; carry = ""; emit(c) }
        if (inCode) closeCode()
    }
}
