package com.myra.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import com.myra.assistant.ui.MainActivity

/** Makes MYRA appear in the system's "Default digital assistant app" list. */
class MyraVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() { super.onReady() }
}

class MyraVoiceSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = MyraVoiceSession(this)
}

class MyraVoiceSession(context: Context) : VoiceInteractionSession(context) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        // Open MYRA's main screen for the voice interaction.
        val i = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        try { context.startActivity(i) } catch (_: Exception) {}
        hide()
    }
}
