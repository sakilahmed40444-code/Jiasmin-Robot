package com.lia.assistant

import android.app.Application

class LiaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
    }
    companion object {
        lateinit var instance: LiaApp
            private set
    }
}
