package com.lia.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.content.ContextCompat
import com.lia.assistant.brain.ConversationMemory
import com.lia.assistant.brain.LiaResponder
import com.lia.assistant.data.HistoryStore
import com.lia.assistant.data.Prefs
import com.lia.assistant.ui.BubbleView
import com.lia.assistant.ui.LoopTextBus
import com.lia.assistant.ui.MainActivity
import com.lia.assistant.ui.VoiceStateBus
import com.lia.assistant.voice.VoiceEngine

/**
 * 24 ghante wala voice loop — Foreground Service (microphone).
 * App band ho ya screen off, Priya sunti-bolti rahegi jab tak STOP na dabao.
 */
class VoiceLoopService : Service() {

    private var engine: VoiceEngine? = null
    private val h = Handler(Looper.getMainLooper())
    private var loopOn = false
    private var errStreak = 0
    private var lastListen = 0L
    private var useSysDialog = false
    private lateinit var prefs: Prefs
    private lateinit var responder: LiaResponder

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        responder = LiaResponder(this, prefs, ConversationMemory())
        instance = this
        isRunning = true
        startFg()
        engine = VoiceEngine(this).apply { cb = loopCb }
    }

    private fun startFg() {
        val ch = "priya_voice"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(ch, "Priya Voice", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, ch)
            .setContentTitle("Priya sun rahi hai 🎙️")
            .setContentText("STOP karne ke liye app kholo")
            .setSmallIcon(android.R.drawable.sym_def_app_icon)
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            val type = if (Build.VERSION.SDK_INT >= 30)
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
            startForeground(2, n, type)
        } else {
            startForeground(2, n)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopLoop(); stopSelf(); return START_NOT_STICKY }
            ACTION_START -> {
                val t = intent.getStringExtra(EXTRA_TEXT)
                if (!loopOn) startLoop()
                if (t != null) handleInput(t)
            }
            else -> {
                // system ne restart kiya — pehle chal raha tha to phir shuru
                if (prefs.voiceLoopOn && !loopOn) startLoop()
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { stopLoop() } catch (_: Exception) { }
        try { engine?.destroy() } catch (_: Exception) { }
        engine = null
        instance = null
        isRunning = false
        super.onDestroy()
    }

    // ================= loop =================

    private val loopCb = object : VoiceEngine.Cb {
        override fun onListening() {
            VoiceStateBus.state(BubbleView.State.LISTENING)
        }
        override fun onPartial(text: String) { }
        override fun onResult(text: String) {
            errStreak = 0
            handleInput(text)
        }
        override fun onError(msg: String) {
            if (!loopOn) return
            when (msg) {
                "no_match", "timeout" -> { errStreak = 0; loopListen() }
                "net", "net_timeout", "server" -> {
                    LoopTextBus.text("Internet check karo 🌐 — phir try…")
                    loopListen(3000)
                }
                "busy" -> loopListen(2000)
                "no_perm" -> {
                    LoopTextBus.text("Mic permission do 🎙️ (Settings → Perms)")
                    loopListen(5000)
                }
                else -> {
                    errStreak++
                    if (errStreak >= 2 && !useSysDialog) {
                        useSysDialog = true
                        errStreak = 0
                        openSysDialog()
                    } else {
                        LoopTextBus.text("আমি এখন শুনছি, বলো 🎙️")
                        loopListen(1200)
                    }
                }
            }
        }
        override fun onSpeakDone() {
            if (loopOn) loopListen(700)
        }
    }

    private fun startLoop() {
        loopOn = true
        prefs.voiceLoopOn = true
        useSysDialog = false
        errStreak = 0
        applyVoiceCfg()
        VoiceStateBus.state(BubbleView.State.LISTENING)
        LoopTextBus.text("আমি এখন শুনছি, বলো 🎙️")
        loopListen(400)
    }

    fun stopLoop() {
        loopOn = false
        prefs.voiceLoopOn = false
        h.removeCallbacksAndMessages(null)
        try { engine?.stopListen() } catch (_: Exception) { }
        try { engine?.stopSpeak() } catch (_: Exception) { }
        VoiceStateBus.state(BubbleView.State.IDLE)
        LoopTextBus.text("জিয়াসমিন ঘুমাচ্ছে 😴")
    }

    /** Bahar se loop dobara shuru karne ke liye (SysDialog cancel par). */
    fun resumeLoop() {
        if (loopOn) { useSysDialog = false; loopListen(500) }
    }

    private fun loopListen(wait: Long = 900) {
        val now = System.currentTimeMillis()
        val gap = if (lastListen == 0L) 10000L else now - lastListen
        h.postDelayed({
            if (!loopOn) return@postDelayed
            lastListen = System.currentTimeMillis()
            VoiceStateBus.state(BubbleView.State.LISTENING)
            LoopTextBus.text("আমি এখন শুনছি, বলো 🎙️")
            applyVoiceCfg()
            try { engine?.stopSpeak() } catch (_: Exception) { }
            try { engine?.listen("bn") } catch (_: Exception) { loopListen(1500) }
        }, maxOf(0, wait - gap).coerceAtMost(wait))
    }

    private fun applyVoiceCfg() {
        val e = engine ?: return
        val p = prefs
        e.geminiVoice = p.geminiVoice.ifBlank { null }
        e.geminiKey = p.apiKey.takeIf { it.isNotBlank() }
        e.setVoiceByName(p.ttsVoiceName)
    }

    private fun openSysDialog() {
        LoopTextBus.text("System mic khul raha hai — bolo 🎙️")
        try {
            val i = Intent(this, SysDialogActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Exception) {
            useSysDialog = false
            loopListen(1500)
        }
    }

    /** Voice ya text — dono ka ek hi rasta. */
    fun handleInput(text: String) {
        val t = text.trim()
        if (t.isEmpty()) { if (loopOn) loopListen(500); return }
        VoiceStateBus.state(BubbleView.State.THINKING)
        LoopTextBus.text("🗣️ $t\nভাবছি…")
        HistoryStore.add(this, "তুমি", t)
        Thread {
            try {
                responder.respond(t, object : LiaResponder.Cb {
                    override fun onReply(reply: String, lang: String) {
                        HistoryStore.add(this@VoiceLoopService, "প্রিয়া", reply)
                        LoopTextBus.text("💗 $reply")
                        VoiceStateBus.state(BubbleView.State.SPEAKING)
                        val e = engine
                        if (e == null) { if (loopOn) loopListen(500); return }
                        val p = prefs
                        e.geminiVoice = p.geminiVoice.ifBlank { null }
                        e.geminiKey = p.apiKey.takeIf { it.isNotBlank() }
                        e.setVoiceByName(p.ttsVoiceName)
                        e.setLang(lang, p.speechRate)
                        try { e.speak(reply) } catch (_: Exception) { if (loopOn) loopListen(500) }
                        // speak khatm → onSpeakDone → loopListen
                    }
                })
            } catch (_: Exception) {
                if (loopOn) loopListen(800)
            }
        }
    }

    companion object {
        const val ACTION_START = "com.lia.assistant.START_LOOP"
        const val ACTION_STOP = "com.lia.assistant.STOP_LOOP"
        const val EXTRA_TEXT = "text"
        @Volatile var isRunning = false
        @Volatile var instance: VoiceLoopService? = null

        fun start(ctx: Context, text: String? = null) {
            val i = Intent(ctx, VoiceLoopService::class.java).setAction(ACTION_START)
            if (text != null) i.putExtra(EXTRA_TEXT, text)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            try { ctx.startService(Intent(ctx, VoiceLoopService::class.java).setAction(ACTION_STOP)) }
            catch (_: Exception) { }
        }

        /** SysDialogActivity se aaya hua speech text. */
        fun submitSpeechText(text: String) {
            val s = instance
            if (s != null) s.handleInput(text) else { /* service mar gaya — kuch nahi */ }
        }
    }
}
