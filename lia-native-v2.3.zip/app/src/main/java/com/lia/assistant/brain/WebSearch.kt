package com.lia.assistant.brain

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** SerpApi se web search — taaza khabar/jankari ke liye. */
object WebSearch {
    @Throws(Exception::class)
    fun search(apiKey: String, query: String): String {
        if (apiKey.isBlank()) throw Exception("no-key")
        val url = URL(
            "https://serpapi.com/search.json?q=" + URLEncoder.encode(query, "utf-8") +
                    "&api_key=" + URLEncoder.encode(apiKey, "utf-8") + "&num=5&hl=en"
        )
        val c = url.openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 25000
            val txt = c.inputStream.bufferedReader().readText()
            val j = JSONObject(txt)
            if (j.has("error")) throw Exception(j.optString("error", "search error"))
            val arr = j.optJSONArray("organic_results") ?: throw Exception("koi result nahi mila")
            val sb = StringBuilder()
            for (i in 0 until minOf(arr.length(), 3)) {
                val o = arr.getJSONObject(i)
                sb.append("• ").append(o.optString("title", "").take(80))
                val sn = o.optString("snippet", "").take(160)
                if (sn.isNotBlank()) sb.append(" — ").append(sn)
                sb.append("\n")
            }
            val out = sb.toString().trim()
            if (out.isEmpty()) throw Exception("koi result nahi mila")
            return out
        } finally {
            c.disconnect()
        }
    }
}
