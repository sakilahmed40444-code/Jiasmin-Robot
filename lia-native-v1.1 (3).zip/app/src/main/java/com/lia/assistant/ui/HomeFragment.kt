package com.lia.assistant.ui

import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import com.lia.assistant.service.BubbleService

class HomeFragment : Fragment() {
    private fun act() = activity as MainActivity

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val sv = Ui.scrollCol(ctx)
        val col = Ui.colLayout(ctx)
        sv.addView(col)

        val name = act().prefs.name.ifBlank { "dost" }
        col.addView(Ui.title(ctx, "Namaste, $name 🌙"))
        col.addView(Ui.sub(ctx, "Main LIA hoon — tumhari voice-first AI companion. Bolo, kya banayein?"))

        val orb = BubbleView(ctx)
        val op = LinearLayout.LayoutParams(Ui.dp(ctx, 220), Ui.dp(ctx, 220))
        op.gravity = android.view.Gravity.CENTER_HORIZONTAL
        orb.layoutParams = op
        col.addView(orb)
        col.addView(Ui.space(ctx))
        val tap = Ui.tv(ctx, "🎙 tap Voice tab se baat karo", 13, Ui.TEXT3)
        tap.gravity = android.view.Gravity.CENTER_HORIZONTAL
        col.addView(tap)

        col.addView(Ui.sec(ctx, "Quick actions"))
        val row1 = Ui.row(ctx)
        row1.addView(Ui.btn(ctx, "🎙️ Voice baat") { act().go(MainActivity.TAB_VOICE) })
        row1.addView(Ui.btn(ctx, "🔥 Website Forge") { act().go(MainActivity.TAB_FORGE) })
        col.addView(row1)
        val row2 = Ui.row(ctx)
        row2.addView(Ui.btn(ctx, "💬 Chat") { act().go(MainActivity.TAB_CHAT) })
        row2.addView(Ui.btn(ctx, "🔐 Setup / Permissions") { act().go(MainActivity.TAB_SETUP) })
        col.addView(row2)

        col.addView(Ui.sec(ctx, "Floating bubble"))
        val card = Ui.card(ctx)
        val cc = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        cc.addView(Ui.tv(ctx, "🫧 Bubble", 16, Ui.TEXT, true))
        cc.addView(Ui.tv(ctx, "App minimize karne par bhi LIA chhoti gol shape me screen par rahegi. Tap → voice khulegi.", 13, Ui.TEXT2))
        cc.addView(Ui.space(ctx, 4))
        val bubbleBtn = Ui.btn(ctx, "", false) {}
        fun refreshBubble() {
            val on = act().prefs.bubbleOn
            bubbleBtn.text = if (on) "🫧 Bubble: ON (band karo)" else "🫧 Bubble: OFF (chalu karo)"
        }
        bubbleBtn.setOnClickListener {
            if (!Settings.canDrawOverlays(ctx)) {
                act().toast("Pehle Setup me 'Draw over apps' Allow karo 🫧")
                act().go(MainActivity.TAB_SETUP)
                return@setOnClickListener
            }
            val on = !act().prefs.bubbleOn
            act().prefs.bubbleOn = on
            if (on) BubbleService.start(ctx) else BubbleService.stop(ctx)
            refreshBubble()
            act().toast(if (on) "Bubble chalu 🫧" else "Bubble band")
        }
        refreshBubble()
        cc.addView(bubbleBtn)
        card.addView(cc)
        col.addView(card)

        col.addView(Ui.sec(ctx, "Try bolo"))
        val tries = listOf(
            "Ek cafe ki website banao", "YouTube kholo", "Mummy ko call karo",
            "Screen padho", "Neeche scroll karo", "Time kya hai?", "Ek joke sunao"
        )
        // chips ke liye vertical container
        val chipCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        for (t in tries) {
            val b = Ui.btn(ctx, "“$t”", false) { act().sendChatText(t) }
            chipCol.addView(b)
        }
        col.addView(chipCol)
        return sv
    }
}
