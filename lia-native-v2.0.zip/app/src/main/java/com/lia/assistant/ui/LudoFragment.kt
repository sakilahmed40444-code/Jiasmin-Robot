package com.lia.assistant.ui

import android.app.AlertDialog
import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import kotlin.math.*

/**
 * Ludo — Tum (pink) vs Bot (purple). Asli rules:
 * 6 par token bahar, kaato (unsafe par), safe = ★, exact roll par finish.
 */
class LudoFragment : Fragment() {

    private var board: LudoView? = null
    private var statusTv: TextView? = null
    private var diceBtn: Button? = null
    private val h = Handler(Looper.getMainLooper())

    // ---- game state ----
    private val pos = Array(2) { IntArray(4) { -1 } } // -1 base, 0..51 track, 52..56 lane, 57 finish
    private var turn = 0 // 0 = you, 1 = bot
    private var dice = 0
    private var sixStreak = 0
    private var phase = 0 // 0=roll wait, 1=choose token, 2=bot thinking, 3=over
    private var movable = booleanArrayOf(false, false, false, false)

    private fun act() = activity as MainActivity

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.col(Ui.BG))
        }
        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 8), Ui.dp(ctx, 8), Ui.dp(ctx, 4))
        }
        val back = Button(ctx, null, android.R.attr.buttonStyle).apply {
            text = "←"; textSize = 22f; setTextColor(Ui.col(Ui.TEXT))
            setOnClickListener { parentFragmentManager.popBackStack() }
        }
        head.addView(back)
        head.addView(Ui.tv(ctx, "🎲 Ludo — Tum vs Bot", 20, Ui.TEXT, true))
        root.addView(head)

        statusTv = Ui.tv(ctx, "Tumhari baari — dice dabao! 🎲", 14, Ui.ACCENT, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4))
        }
        root.addView(statusTv)

        board = LudoView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(board)

        diceBtn = Ui.btn(ctx, "🎲 ROLL", true) { onRoll() }.apply {
            textSize = 20f
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(Ui.dp(ctx, 16), Ui.dp(ctx, 8), Ui.dp(ctx, 16), Ui.dp(ctx, 16))
            layoutParams = lp
        }
        root.addView(diceBtn)
        return root
    }

    private fun onRoll() {
        if (phase != 0 || turn != 0) return
        dice = (1..6).random()
        animateDice {
            statusTv?.text = "Dice: $dice"
            if (dice == 6) sixStreak++ else sixStreak = 0
            if (sixStreak >= 3) {
                statusTv?.text = "Teen 6 lagatar — baari gayi! 😅"
                sixStreak = 0
                h.postDelayed({ nextTurn() }, 1200)
                return@animateDice
            }
            computeMovable(turn)
            if (movable.none { it }) {
                statusTv?.text = "Koi chaal nahi — $dice par"
                h.postDelayed({ nextTurn() }, 1100)
            } else if (movable.count { it } == 1) {
                doMove(turn, movable.indexOfFirst { it })
            } else {
                phase = 1
                statusTv?.text = "$dice aaya — apni goti chuno 👆"
                board?.invalidate()
            }
        }
    }

    private fun animateDice(done: () -> Unit) {
        diceBtn?.isEnabled = false
        val faces = listOf("⚀", "⚁", "⚂", "⚃", "⚄", "⚅")
        var n = 0
        val t = object : Runnable {
            override fun run() {
                if (n < 6) {
                    diceBtn?.text = faces.random()
                    n++; h.postDelayed(this, 70)
                } else {
                    diceBtn?.text = faces[dice - 1] + " ROLL"
                    diceBtn?.isEnabled = (turn == 0 && phase == 0)
                    done()
                }
            }
        }
        h.post(t)
    }

    private fun computeMovable(pl: Int) {
        for (i in 0..3) {
            val p = pos[pl][i]
            movable[i] = when {
                p == -1 -> dice == 6
                p >= 57 -> false
                else -> p + dice <= 57
            }
        }
    }

    private fun doMove(pl: Int, tok: Int) {
        val from = pos[pl][tok]
        var captured = false
        var finished = false
        if (from == -1) {
            pos[pl][tok] = 0
        } else {
            val to = from + dice
            pos[pl][tok] = to
            if (to == 57) finished = true
            else if (to <= 51) {
                val abs = (LudoView.startIdx(pl) + to) % 52
                if (!LudoView.isSafe(abs)) {
                    val opp = 1 - pl
                    for (j in 0..3) {
                        val op = pos[opp][j]
                        if (op in 0..51 && (LudoView.startIdx(opp) + op) % 52 == abs) {
                            pos[opp][j] = -1
                            captured = true
                        }
                    }
                }
            }
        }
        phase = 0
        board?.invalidate()
        // coins for progress
        if (pl == 0 && (captured || finished)) {
            val p = act().prefs; p.coins = p.coins + 5
        }
        if (pos[pl].all { it == 57 }) { gameOver(pl); return }
        val extra = dice == 6 || captured || finished
        statusTv?.text = when {
            captured -> "Kaata! ✂️ " + if (extra) "Phir se khelo!" else ""
            finished -> "Goti ghar! 🏠 " + if (extra) "Phir se khelo!" else ""
            else -> ""
        }
        if (extra) {
            if (pl == 0) { phase = 0; diceBtn?.isEnabled = true; statusTv?.text = "${statusTv?.text} Dobara dice dabao! 🎲" }
            else h.postDelayed({ botTurn() }, 900)
        } else {
            h.postDelayed({ nextTurn() }, 900)
        }
    }

    private fun nextTurn() {
        turn = 1 - turn
        sixStreak = 0
        phase = 0
        diceBtn?.isEnabled = (turn == 0)
        if (turn == 0) statusTv?.text = "Tumhari baari — dice dabao! 🎲"
        else { statusTv?.text = "Bot soch raha… 🤖"; h.postDelayed({ botTurn() }, 800) }
        board?.invalidate()
    }

    private fun botTurn() {
        if (phase == 3 || turn != 1) return
        dice = (1..6).random()
        animateDice {
            if (dice == 6) sixStreak++ else sixStreak = 0
            if (sixStreak >= 3) { sixStreak = 0; h.postDelayed({ nextTurn() }, 900); return@animateDice }
            computeMovable(1)
            if (movable.none { it }) { h.postDelayed({ nextTurn() }, 900); return@animateDice }
            val pick = botPick()
            h.postDelayed({ doMove(1, pick) }, 500)
        }
    }

    /** Bot: kaato > finish > bahar nikalo > safe > aage badho */
    private fun botPick(): Int {
        var best = movable.indexOfFirst { it }
        var bestScore = Int.MIN_VALUE
        for (i in 0..3) {
            if (!movable[i]) continue
            val from = pos[1][i]
            var sc = 0
            if (from == -1) { sc = 30; }
            else {
                val to = from + dice
                if (to == 57) sc = 100
                else if (to <= 51) {
                    val abs = (LudoView.startIdx(1) + to) % 52
                    if (!LudoView.isSafe(abs)) {
                        for (j in 0..3) {
                            val op = pos[0][j]
                            if (op in 0..51 && (LudoView.startIdx(0) + op) % 52 == abs) sc += 80
                        }
                        // khud unsafe par, peeche dushman?
                        for (j in 0..3) {
                            val op = pos[0][j]
                            if (op in 0..51) {
                                val gap = (abs - (LudoView.startIdx(0) + op) % 52 + 52) % 52
                                if (gap in 1..6) sc -= 25
                            }
                        }
                    } else sc += 15
                    sc += to // aage badho
                } else sc = 40 + to
            }
            sc += (0..2).random()
            if (sc > bestScore) { bestScore = sc; best = i }
        }
        return best
    }

    private fun gameOver(winner: Int) {
        phase = 3
        diceBtn?.isEnabled = false
        board?.invalidate()
        if (winner == 0) {
            val p = act().prefs; p.coins = p.coins + 100
            statusTv?.text = "🎉 TUM JEET GAYE! +100 coins 🪙"
        } else statusTv?.text = "🤖 Bot jeet gaya — phir try karo!"
        AlertDialog.Builder(requireContext())
            .setTitle(if (winner == 0) "🎉 Jeet gaye!" else "🤖 Bot jeeta")
            .setMessage(if (winner == 0) "Badhai ho! +100 coins mile. 🪙" else "Koi baat nahi, agli baar pakka!")
            .setPositiveButton("Phir khelo") { _, _ -> resetGame() }
            .setNegativeButton("Band karo") { _, _ -> parentFragmentManager.popBackStack() }
            .setCancelable(false).show()
    }

    private fun resetGame() {
        for (pl in 0..1) for (i in 0..3) pos[pl][i] = -1
        turn = 0; sixStreak = 0; phase = 0
        diceBtn?.isEnabled = true
        statusTv?.text = "Tumhari baari — dice dabao! 🎲"
        board?.invalidate()
    }

    fun onTokenTap(tok: Int) {
        if (phase == 1 && turn == 0 && movable.getOrNull(tok) == true) doMove(0, tok)
    }

    // ================= BOARD VIEW =================
    inner class LudoView(ctx: Context) : View(ctx) {
        private val paint = Paint().apply { isAntiAlias = true }
        private val txtPaint = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; color = Color.WHITE; textSize = 30f; typeface = Typeface.BOLD }
        private var pts = listOf<PointF>()       // 52 track cells
        private var lanePts = listOf<List<PointF>>() // per player 5 lane cells
        private var youStart = 0
        private var botStart = 26
        private var cellR = 20f

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            super.onSizeChanged(w, h, ow, oh)
            computeGeometry(w, h)
        }

        private fun computeGeometry(w: Int, h: Int) {
            val s = min(w, h).toFloat()
            val m = s * 0.08f
            val L = m; val T = m; val R = s - m; val B = s - m
            val rad = s * 0.18f
            // rounded-rect loop, clockwise from top-left corner
            val wSeg = (R - L) - 2 * rad
            val hSeg = (B - T) - 2 * rad
            val arc = (PI.toFloat() * rad / 2f)
            val perim = 2 * wSeg + 2 * hSeg + 4 * arc
            val list = mutableListOf<PointF>()
            var d = 0f
            val step = perim / 52f
            // segments: top straight → TR corner → right straight → BR corner → bottom straight → BL corner → left straight → TL corner
            data class Seg(val len: Float, val fn: (Float) -> PointF)
            val segs = listOf(
                Seg(wSeg) { t -> PointF(L + rad + t, T) },
                Seg(arc) { t -> val a = -PI.toFloat()/2 + t / rad; PointF(R - rad + cos(a)*rad, T + rad + sin(a)*rad) },
                Seg(hSeg) { t -> PointF(R, T + rad + t) },
                Seg(arc) { t -> val a = t / rad; PointF(R - rad + cos(a)*rad, B - rad + sin(a)*rad) },
                Seg(wSeg) { t -> PointF(R - rad - t, B) },
                Seg(arc) { t -> val a = PI.toFloat()/2 + t / rad; PointF(L + rad + cos(a)*rad, B - rad + sin(a)*rad) },
                Seg(hSeg) { t -> PointF(L, B - rad - t) },
                Seg(arc) { t -> val a = PI.toFloat() + t / rad; PointF(L + rad + cos(a)*rad, T + rad + sin(a)*rad) }
            )
            var si = 0; var sd = 0f
            repeat(52) {
                while (si < segs.size && d >= sd + segs[si].len) { sd += segs[si].len; si++ }
                val sgm = segs[min(si, segs.size - 1)]
                list.add(sgm.fn((d - sd).coerceIn(0f, sgm.len)))
                d += step
            }
            pts = list
            cellR = step * 0.42f
            // starts: nearest to bottom-center / top-center
            val bc = PointF(s/2, B); val tc = PointF(s/2, T)
            youStart = pts.indices.minByOrNull { dist(pts[it], bc) } ?: 0
            botStart = pts.indices.minByOrNull { dist(pts[it], tc) } ?: 26
            setStarts(youStart, botStart)
            // lanes: from cell before start → center (5 cells)
            val cx = s/2; val cy = s/2
            lanePts = listOf(0, 1).map { pl ->
                val st = if (pl == 0) youStart else botStart
                val from = pts[(st + 51) % 52]
                (1..5).map { k ->
                    val f = k / 6.5f
                    PointF(from.x + (cx - from.x) * f, from.y + (cy - from.y) * f)
                }
            }
        }

        private fun dist(a: PointF, b: PointF) = hypot(a.x-b.x, a.y-b.y)

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            if (pts.isEmpty()) return
            val s = min(width, height).toFloat()
            // bg
            paint.style = Paint.Style.FILL; paint.color = Ui.col(Ui.BG)
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            // bases (top = bot, bottom = you)
            drawBase(c, 0, 1, s) // bot top
            drawBase(c, 1, 0, s) // you bottom
            // track cells
            for (i in pts.indices) {
                val p = pts[i]
                val safe = isSafe(i)
                paint.style = Paint.Style.FILL
                paint.color = when {
                    i == youStart -> Ui.col("#FF2E88")
                    i == botStart -> Ui.col("#9D4DFF")
                    safe -> Ui.col("#1E5C3F")
                    else -> Ui.col(Ui.SURFACE)
                }
                c.drawCircle(p.x, p.y, cellR, paint)
                paint.style = Paint.Style.STROKE; paint.color = Ui.col("#3A2A6E"); paint.strokeWidth = 2f
                c.drawCircle(p.x, p.y, cellR, paint)
                if (safe && i != youStart && i != botStart) {
                    txtPaint.textSize = cellR; txtPaint.color = Ui.col(Ui.NEON_GREEN)
                    c.drawText("★", p.x, p.y + cellR*0.35f, txtPaint)
                }
            }
            // lanes
            val laneCols = listOf("#FF2E88", "#9D4DFF")
            for (pl in 0..1) for (k in lanePts[pl].indices) {
                val p = lanePts[pl][k]
                paint.style = Paint.Style.FILL; paint.color = Ui.col(laneCols[pl]); paint.alpha = 120
                c.drawCircle(p.x, p.y, cellR*0.9f, paint); paint.alpha = 255
            }
            // center home
            paint.style = Paint.Style.FILL; paint.color = Ui.col(Ui.RAISED)
            c.drawCircle(s/2, s/2, cellR*1.6f, paint)
            txtPaint.textSize = cellR*1.4f; txtPaint.color = Ui.col(Ui.ACCENT)
            c.drawText("🏠", s/2, s/2 + cellR*0.5f, txtPaint)
            // tokens
            for (pl in 0..1) for (t in 0..3) drawToken(c, pl, t, s)
            // movable highlight
            if (phase == 1 && turn == 0) {
                paint.style = Paint.Style.STROKE; paint.color = Color.YELLOW; paint.strokeWidth = 5f
                for (t in 0..3) if (movable[t]) {
                    val p = tokenPos(0, t, s)
                    c.drawCircle(p.x, p.y, cellR*1.05f, paint)
                }
            }
        }

        private fun drawBase(c: Canvas, pl: Int, top: Int, s: Float) {
            val y0 = if (top == 1) 0f else s - s*0.16f
            paint.style = Paint.Style.FILL
            paint.color = Ui.col(if (pl == 0) "#3A1030" else "#241040")
            c.drawRoundRect(0f, y0, s, y0 + s*0.16f, 24f, 24f, paint)
            txtPaint.textSize = 28f; txtPaint.color = Ui.col(if (pl == 0) "#FF2E88" else "#9D4DFF")
            c.drawText(if (pl == 0) "TUM" else "BOT", s/2, y0 + s*0.055f, txtPaint)
            for (t in 0..3) {
                if (pos[pl][t] != -1) continue
                val x = s*(0.2f + 0.2f*t); val y = y0 + s*0.105f
                paint.style = Paint.Style.FILL; paint.color = Ui.col(if (pl == 0) "#FF2E88" else "#9D4DFF")
                c.drawCircle(x, y, cellR*0.8f, paint)
                paint.style = Paint.Style.STROKE; paint.color = Color.WHITE; paint.strokeWidth = 2f
                c.drawCircle(x, y, cellR*0.8f, paint)
            }
        }

        private fun tokenPos(pl: Int, t: Int, s: Float): PointF {
            val p = pos[pl][t]
            val st = if (pl == 0) youStart else botStart
            return when {
                p == -1 -> { val top = if (pl == 1) 1 else 0; val y0 = if (top == 1) 0f else s - s*0.16f
                    PointF(s*(0.2f + 0.2f*t), y0 + s*0.105f) }
                p <= 51 -> pts[(st + p) % 52]
                p <= 56 -> lanePts[pl][p - 52]
                else -> PointF(s/2 + (t-1.5f)*cellR*0.7f, s/2)
            }
        }

        private fun drawToken(c: Canvas, pl: Int, t: Int, s: Float) {
            val p = tokenPos(pl, t, s)
            // stack offset: same cell tokens
            var n = 0
            for (pl2 in 0..1) for (t2 in 0..3) {
                if (pl2 == pl && t2 == t) continue
                val q = tokenPos(pl2, t2, s)
                if (abs(q.x - p.x) < 2 && abs(q.y - p.y) < 2 && (pl2 < pl || (pl2 == pl && t2 < t))) n++
            }
            val ox = (n % 2) * cellR * 0.5f - cellR*0.25f
            val oy = (n / 2) * cellR * 0.5f - cellR*0.25f
            paint.style = Paint.Style.FILL
            paint.color = Ui.col(if (pl == 0) "#FF2E88" else "#9D4DFF")
            c.drawCircle(p.x + ox, p.y + oy, cellR*0.75f, paint)
            paint.style = Paint.Style.STROKE; paint.color = Color.WHITE; paint.strokeWidth = 3f
            c.drawCircle(p.x + ox, p.y + oy, cellR*0.75f, paint)
            txtPaint.textSize = cellR*0.8f; txtPaint.color = Color.WHITE
            c.drawText("${t+1}", p.x + ox, p.y + oy + cellR*0.28f, txtPaint)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action == MotionEvent.ACTION_DOWN) {
                val s = min(width, height).toFloat()
                for (t in 0..3) {
                    val p = tokenPos(0, t, s)
                    if (hypot(e.x - p.x, e.y - p.y) < cellR*1.4f) {
                        onTokenTap(t); return true
                    }
                }
            }
            return true
        }
    }

    companion object {
        private var sYou = 0
        private var sBot = 26
        fun startIdx(pl: Int) = if (pl == 0) sYou else sBot
        fun setStarts(you: Int, bot: Int) { sYou = you; sBot = bot }
        fun isSafe(absIdx: Int): Boolean {
            val offs = setOf(0, 8, 13, 21, 26, 34, 39, 47)
            return offs.any { (sYou + it) % 52 == absIdx }
        }
    }
}
