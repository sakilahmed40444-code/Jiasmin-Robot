export class AudioStreamer {
  private context: AudioContext | null = null;
  private stream: MediaStream | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private processor: ScriptProcessorNode | null = null;
  private analyser: AnalyserNode | null = null;
  private onPcm?: (pcm: Uint8Array) => void;
  private onLevel?: (level: number) => void;
  private targetRate = 16000;

  constructor(
    onPcm: (pcm: Uint8Array) => void,
    onLevel?: (level: number) => void
  ) {
    this.onPcm = onPcm;
    this.onLevel = onLevel;
  }

  async start() {
    if (this.stream) return;
    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        channelCount: 1,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true
      },
      video: false
    });

    this.context = new AudioContext();
    await this.context.resume();

    this.source = this.context.createMediaStreamSource(this.stream);
    this.analyser = this.context.createAnalyser();
    this.analyser.fftSize = 512;

    this.processor = this.context.createScriptProcessor(2048, 1, 1);
    this.processor.onaudioprocess = (event) => {
      const input = event.inputBuffer.getChannelData(0);
      const level = this.rms(input);
      this.onLevel?.(Math.min(1, level * 5));

      const pcm = this.resampleAndEncode(input, this.context!.sampleRate, this.targetRate);
      if (pcm.length) this.onPcm?.(pcm);
    };

    this.source.connect(this.analyser);
    this.source.connect(this.processor);
    this.processor.connect(this.context.destination);
  }

  stop() {
    this.processor?.disconnect();
    this.source?.disconnect();
    this.analyser?.disconnect();
    this.stream?.getTracks().forEach((track) => track.stop());
    this.context?.close();

    this.processor = null;
    this.source = null;
    this.analyser = null;
    this.stream = null;
    this.context = null;
    this.onLevel?.(0);
  }

  private rms(input: Float32Array): number {
    let sum = 0;
    for (const v of input) sum += v * v;
    return Math.sqrt(sum / Math.max(1, input.length));
  }

  private resampleAndEncode(
    input: Float32Array,
    inputRate: number,
    outputRate: number
  ): Uint8Array {
    const ratio = inputRate / outputRate;
    const outputLength = Math.max(1, Math.floor(input.length / ratio));
    const out = new Uint8Array(outputLength * 2);
    const view = new DataView(out.buffer);

    for (let i = 0; i < outputLength; i++) {
      const pos = i * ratio;
      const index = Math.floor(pos);
      const frac = pos - index;
      const a = input[Math.min(index, input.length - 1)] ?? 0;
      const b = input[Math.min(index + 1, input.length - 1)] ?? a;
      const sample = Math.max(-1, Math.min(1, a + (b - a) * frac));
      const int16 = sample < 0 ? sample * 32768 : sample * 32767;
      view.setInt16(i * 2, int16, true);
    }
    return out;
  }
}