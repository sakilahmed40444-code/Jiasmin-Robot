package com.lia.assistant.voice

import android.util.Log
import java.net.HttpURLConnection
import java.net.URL

/**
 * OpenRouter STT — POST /api/v1/audio/transcriptions (base64 JSON).
 * Priya nijer mic-e record kore, nijei shune — Google UI lagbe na.
 */
object OpenRouterStt {

    /**
     * @param audio raw audio bytes (m4a/aac)
     * @param format "m4a"
     * @return transcribed text, or null on failure
     */
    fun transcribe(audio: ByteArray, format: String, apiKey: String,
                   language: String = "bn"): String? {
        if (audio.size < 2000 || audio.size > 20 * 1024 * 1024) return null
        return try {
            val b64 = android.util.Base64.encodeToString(audio, android.util.Base64.NO_WRAP)
            val body = org.json.JSONObject().apply {
                put("model", "openai/whisper-1")
                put("input_audio", org.json.JSONObject().apply {
                    put("data", b64)
                    put("format", format)
                })
                put("language", language)
            }.toString()
            val c = URL("https://openrouter.ai/api/v1/audio/transcriptions")
                .openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer $apiKey")
            c.setRequestProperty("HTTP-Referer", "https://priya.assistant")
            c.setRequestProperty("X-Title", "Priya Assistant")
            c.connectTimeout = 25000
            c.readTimeout = 60000
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (c.responseCode != 200) {
                val err = try { c.errorStream?.bufferedReader()?.readText()?.take(200) } catch (_: Exception) { "" }
                Log.e("OpenRouterStt", "HTTP ${c.responseCode}: $err")
                return null
            }
            val r = c.inputStream.bufferedReader().readText()
            org.json.JSONObject(r).optString("text", "").trim().ifBlank { null }
        } catch (e: Exception) {
            Log.e("OpenRouterStt", "transcribe fail", e)
            null
        }
    }
}
