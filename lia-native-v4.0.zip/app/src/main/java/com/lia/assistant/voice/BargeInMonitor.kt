package com.lia.assistant.voice

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder

/**
 * MYRA-style barge-in: Priya bolte thakle user bolna shuru kare
 * to TTS turant ruk jata hai aur sunna shuru hota hai.
 * AudioRecord (VOICE_RECOGNITION) se RMS monitor — pehle 900ms
 * echo-suppression (speaker ki awaz ignore).
 */
class BargeInMonitor(private val onBarge: () -> Unit) {

    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({
            var ar: AudioRecord? = null
            try {
                val sr = 16000
                val ch = AudioFormat.CHANNEL_IN_MONO
                val fmt = AudioFormat.ENCODING_PCM_16BIT
                val bs = AudioRecord.getMinBufferSize(sr, ch, fmt)
                if (bs <= 0) return@Thread
                ar = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sr, ch, fmt, bs * 2)
                if (ar.state != AudioRecord.STATE_INITIALIZED) return@Thread
                ar.startRecording()
                val buf = ShortArray(1024)
                var loudMs = 0L
                val ignoreUntil = System.currentTimeMillis() + 900
                var last = System.currentTimeMillis()
                while (running) {
                    val n = try { ar.read(buf, 0, buf.size) } catch (_: Exception) { -1 }
                    if (!running) break
                    val now = System.currentTimeMillis()
                    val dt = now - last; last = now
                    if (n > 0) {
                        var sum = 0.0
                        for (i in 0 until n) sum += buf[i].toDouble() * buf[i].toDouble()
                        val rms = Math.sqrt(sum / n)
                        if (now > ignoreUntil && rms > 2500) {
                            loudMs += dt
                            if (loudMs > 500) {
                                running = false
                                try { onBarge() } catch (_: Exception) { }
                                break
                            }
                        } else loudMs = 0
                    }
                }
            } catch (_: Exception) { } finally {
                try { ar?.stop() } catch (_: Exception) { }
                try { ar?.release() } catch (_: Exception) { }
                running = false
            }
        }, "barge").apply { isDaemon = true; start() }
    }

    fun stop() {
        running = false
        try { thread?.join(600) } catch (_: Exception) { }
        thread = null
    }

    fun isRunning() = running
}
