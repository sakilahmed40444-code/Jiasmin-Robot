package com.lia.assistant.ui

import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import java.text.SimpleDateFormat
import java.util.*

/** Coins tab — simple balance + daily bonus. */
class CoinsFragment : Fragment() {
    private fun act() = activity as MainActivity
    private var balTv: android.widget.TextView? = null

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val root = android.widget.ScrollView(ctx).apply { setBackgroundColor(Ui.col(Ui.BG)) }
        val col = Ui.colLayout(ctx)
        root.addView(col)

        col.addView(Ui.tv(ctx, "🪙 Coins", 24, Ui.TEXT, true).apply { gravity = Gravity.CENTER })
        col.addView(sp(12))

        balTv = Ui.tv(ctx, "", 40, Ui.ACCENT, true).apply { gravity = Gravity.CENTER }
        col.addView(balTv)
        col.addView(Ui.tv(ctx, "tumhare coins", 13, Ui.TEXT2).apply { gravity = Gravity.CENTER })
        col.addView(sp(16))

        col.addView(Ui.btn(ctx, "🎁 Daily Bonus +50", true) { claimDaily() })
        col.addView(sp(8))
        col.addView(Ui.tv(ctx, "Baat karne par coins milte rahenge.\nJaldi hi naye rewards aayenge! ✨", 13, Ui.TEXT3).apply {
            gravity = Gravity.CENTER
        })
        col.addView(sp(24))
        refresh()
        return root
    }

    private fun claimDaily() {
        val p = act().prefs
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (p.lastCoinDay == today) {
            act().toast("Aaj ka bonus le liya — kal phir aana! 🎁")
            return
        }
        p.lastCoinDay = today
        p.coins = p.coins + 50
        act().toast("+50 coins! 🪙")
        refresh()
    }

    private fun refresh() {
        balTv?.text = "🪙 ${act().prefs.coins}"
    }

    private fun sp(dp: Int): View {
        val v = View(requireContext())
        v.layoutParams = LinearLayout.LayoutParams(1, Ui.dp(requireContext(), dp))
        return v
    }
}
