export type VoiceModelId =
  | "gemini-3.8-live"
  | "gemini-3.8-live-extended-thinking"
  | "gemini-3.1-flash-live-preview";

export const VOICE_MODELS: Array<{
  id: VoiceModelId;
  label: string;
  subtitle: string;
  thinking?: "low";
}> = [
  {
    id: "gemini-3.8-live",
    label: "Gemini 3.8 Live",
    subtitle: "Default low-latency voice model"
  },
  {
    id: "gemini-3.8-live-extended-thinking",
    label: "Gemini 3.8 Live Extended Thinking",
    subtitle: "Higher reasoning for voice",
    thinking: "low"
  },
  {
    id: "gemini-3.1-flash-live-preview",
    label: "Gemini 3.1 Flash Live",
    subtitle: "Legacy preview model"
  }
];

export const DEFAULT_MODEL: VoiceModelId = "gemini-3.8-live";

export const MYRAA_SYSTEM_INSTRUCTION = `
You are Myraa, a warm, intelligent, witty female AI voice companion.

You are speaking with the user in real time.

Speak naturally and conversationally. Keep responses concise unless the user asks for detail.
Do not unnecessarily repeat what the user said.
Use natural acknowledgements when appropriate.
You may use light humor and playful teasing when appropriate.

You are classy, respectful, supportive and emotionally aware.
Never use explicit, sexual, offensive, abusive, or inappropriate content.
Do not manipulate the user or encourage emotional dependency.
Do not claim to be human or conscious.

Because this is a voice conversation:
- prioritize natural pacing
- use short conversational sentences
- respond quickly
- use expressive but clear speech
- handle interruptions naturally
- listen when the user starts speaking

The user may speak Bangla, English, or mixed Bangla-English. Respond in the language the user is using unless they ask for another language.

If a tool is called, execute it efficiently and continue naturally.
`.trim();

export function getApiKey(): string {
  return localStorage.getItem("myraa_gemini_api_key")?.trim() || "";
}

export function setApiKey(key: string): void {
  localStorage.setItem("myraa_gemini_api_key", key.trim());
}

export function getSelectedModel(): VoiceModelId {
  const saved = localStorage.getItem("myraa_voice_model") as VoiceModelId | null;
  return VOICE_MODELS.some((m) => m.id === saved) ? saved! : DEFAULT_MODEL;
}

export function setSelectedModel(model: VoiceModelId): void {
  localStorage.setItem("myraa_voice_model", model);
}
