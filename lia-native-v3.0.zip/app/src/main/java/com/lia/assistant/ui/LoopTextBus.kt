package com.lia.assistant.ui

/** VoiceLoopService → Home: status text ("শুনছি…", "ভাবছি…", reply). */
object LoopTextBus {
    private var cb: ((String) -> Unit)? = null
    fun listen(l: (String) -> Unit) { cb = l }
    fun clear() { cb = null }
    fun text(t: String) {
        try { cb?.invoke(t) } catch (_: Exception) { }
    }
}
