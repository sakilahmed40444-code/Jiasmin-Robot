import React from "react";

type Props = {
  state: string;
  level: number;
  onClick: () => void;
};

export function VoiceOrb({ state, level, onClick }: Props) {
  const active = state === "listening" || state === "speaking";
  const scale = 1 + Math.min(level, 1) * 0.16;

  return (
    <button
      className={`orb-button ${active ? "orb-active" : ""} ${state === "speaking" ? "orb-speaking" : ""}`}
      style={{ transform: `scale(${scale})` }}
      onClick={onClick}
      aria-label={active ? "Stop Myraa" : "Start Myraa"}
    >
      <span className="orb-ring ring-one" />
      <span className="orb-ring ring-two" />
      <span className="orb-core">
        <span className="orb-dot" />
      </span>
    </button>
  );
}