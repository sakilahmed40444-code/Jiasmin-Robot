# MYRA – GitHub Ready Android Project

This is the MYRA Android source project with the voice pipeline fixed for:

- Gemini AI + OpenRouter AI
- Gemini native voice list
- Voice input → AI → TTS → speaker flow
- Gemini 3.8 Flash TTS (`gemini-3.8-flash-tts`)
- 24 kHz PCM audio normalization for playback
- WAV/PCM response handling
- Emergency Android TTS fallback so the app does not become completely silent when a network TTS request fails
- GitHub Actions workflow that builds a debug APK automatically

## Build on GitHub

1. Create a GitHub repository.
2. Upload all files from this project.
3. Push to `main` or `master`, or open **Actions → Build MYRA APK → Run workflow**.
4. When the workflow finishes, open the workflow run and download the **MYRA-debug-apk** artifact.

## API keys

Do not hard-code API keys in the source code. Enter Gemini/OpenRouter keys inside the app Settings/API screen.

## Voice list

The app keeps the Gemini native prebuilt voices used by the UI, including Achernar, Algenib, Algieba, Alnilam, Aoede, Autonoe, Callirrhoe, Charon, Despina, Enceladus, Erinome, Fenrir, Gacrux, Iapetus, Kore, Laomedeia, Leda, Orus, Puck, Pulcherrima, Achird, Rasalgethi, Schedar, Sadachbia, Sadaltager, Sulafat, Umbriel, Vindemiatrix, Zephyr and Zubenelgenubi.
