package com.lia.assistant.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import java.net.HttpURLConnection
import java.net.URL

/**
 * Gemini TTS — "Kore", "Aoede" jaisi voices me bole.
 * API key chahiye; nahi to VoiceEngine Android TTS par gir jata hai.
 * Audio: 24kHz 16-bit mono PCM → AudioTrack se play.
 */
object GeminiTts {

    @Volatile private var track: AudioTrack? = null
    @Volatile private var stopped = false

    fun speak(text: String, voice: String, apiKey: String, onDone: () -> Unit) {
        stop()
        stopped = false
        Thread {
            try {
                val pcm = fetchPcm(text, voice, apiKey)
                if (stopped || pcm == null || pcm.isEmpty()) { onDone(); return@Thread }
                playPcm(pcm)
            } catch (_: Exception) { }
            onDone()
        }.start()
    }

    fun stop() {
        stopped = true
        try { track?.stop() } catch (_: Exception) { }
        try { track?.release() } catch (_: Exception) { }
        track = null
    }

    private fun fetchPcm(text: String, voice: String, apiKey: String): ByteArray? {
        val clean = text.take(900)
        val body = "{\"contents\":[{\"parts\":[{\"text\":" + jsonStr("Say warmly, naturally: $clean") + "}]}]," +
                "\"generationConfig\":{\"responseModalities\":[\"AUDIO\"]," +
                "\"speechConfig\":{\"voiceConfig\":{\"prebuiltVoiceConfig\":{\"voiceName\":" + jsonStr(voice) + "}}}}}"
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey)
            connectTimeout = 20000; readTimeout = 30000
            doOutput = true
        }
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val resp = try {
            (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.readText() ?: ""
        } catch (_: Exception) { "" }
        conn.disconnect()
        if (code !in 200..299) return null
        // parts me inlineData.data dhoondho
        val m = Regex("\"inlineData\"\\s*:\\s*\\{[^}]*\"data\"\\s*:\\s*\"([^\"]+)\"").find(resp)
            ?: Regex("\"data\"\\s*:\\s*\"([A-Za-z0-9+/=]{100,})\"").find(resp)
            ?: return null
        return try { Base64.decode(m.groupValues[1], Base64.DEFAULT) } catch (_: Exception) { null }
    }

    private fun playPcm(pcm: ByteArray) {
        val sr = 24000
        val at = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(pcm.size, 8192))
                .build()
        } catch (_: Exception) { return }
        track = at
        try {
            at.play()
            var off = 0
            while (off < pcm.size && !stopped) {
                val n = at.write(pcm, off, pcm.size - off)
                if (n <= 0) break
                off += n
            }
            val totalFrames = pcm.size / 2
            var guard = 0
            while (!stopped && at.playState == AudioTrack.PLAYSTATE_PLAYING &&
                at.playbackHeadPosition < totalFrames && guard < 600) {
                Thread.sleep(100); guard++
            }
        } catch (_: Exception) { }
        try { at.stop() } catch (_: Exception) { }
        try { at.release() } catch (_: Exception) { }
        if (track === at) track = null
    }

    private fun jsonStr(s: String): String {
        val sb = StringBuilder("\"")
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
            }
        }
        sb.append("\"")
        return sb.toString()
    }
}
