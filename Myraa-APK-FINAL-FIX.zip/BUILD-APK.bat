@echo off
echo ======================================
echo Myraa Assistant APK Builder
echo ======================================
call npm install
if errorlevel 1 goto fail
call npm run android:add
if errorlevel 1 goto fail
cd android
call gradlew.bat assembleDebug
if errorlevel 1 goto fail
echo.
echo APK:
echo android\app\build\outputs\apk\debug\app-debug.apk
pause
exit /b 0
:fail
echo Build failed. Check the error above.
pause
exit /b 1
