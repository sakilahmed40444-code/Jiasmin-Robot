package com.lia.assistant.brain

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini REST — generateContent, model fallback ke saath. Koi extra dependency nahi. */
object GeminiClient {
    private val FALLBACK = listOf("gemini-2.0-flash", "gemini-1.5-flash", "gemini-2.0-flash-lite")

    @Throws(Exception::class)
    fun chat(
        apiKey: String,
        model: String,
        system: String,
        history: List<Pair<Boolean, String>>,
        userText: String
    ): String {
        if (apiKey.isBlank()) throw Exception("no-key")
        val models = (listOf(model) + FALLBACK.filter { it != model }).distinct()
        var lastErr = "unknown"
        for (m in models) {
            try {
                return post(apiKey, m, system, history, userText)
            } catch (e: Exception) {
                lastErr = e.message ?: "error"
            }
        }
        throw Exception(lastErr)
    }

    @Throws(Exception::class)
    private fun post(
        apiKey: String,
        model: String,
        system: String,
        history: List<Pair<Boolean, String>>,
        userText: String
    ): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", apiKey)
            c.doOutput = true
            c.connectTimeout = 20000
            c.readTimeout = 60000

            val contents = JSONArray()
            for ((isUser, t) in history.takeLast(10)) {
                contents.put(
                    JSONObject().put("role", if (isUser) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", t)))
                )
            }
            contents.put(
                JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", userText)))
            )
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("maxOutputTokens", 220).put("temperature", 0.9))
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)
                .bufferedReader().readText()
            val j = JSONObject(txt)
            if (j.has("error")) throw Exception(j.getJSONObject("error").optString("message", "API error $code"))
            val parts = j.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val out = StringBuilder()
            for (i in 0 until parts.length()) out.append(parts.getJSONObject(i).optString("text", ""))
            val res = out.toString().trim()
            if (res.isEmpty()) throw Exception("empty reply")
            return res
        } finally {
            c.disconnect()
        }
    }
}
