package com.myra.assistant.ai

import android.content.Context
import android.util.Base64
import com.myra.assistant.data.Prefs
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import org.json.JSONArray
import org.json.JSONObject

interface PipelineUi {
    fun onState(s: State)
    fun onUserMessage(t: String)
    fun onMyraMessage(t: String)
    fun onCode(lang: String, code: String)
    fun onError(msg: String)
    fun onAmplitude(a: Float)
    fun onCaption(t: String)
    suspend fun confirm(msg: String): Boolean
}

class VoicePipeline(private val ctx: Context, private val ui: PipelineUi) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var client: BrainClient? = null
    private val http: OkHttpClient by lazy {
        OkHttpClient.Builder().connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(90, java.util.concurrent.TimeUnit.SECONDS).build()
    }
    private val audio = AudioEngine().also { it.onAmp = { a -> ui.onAmplitude(a) } }
    private val fallback = FallbackTts(ctx)
    private val tools = ToolExecutor(ctx, ui)
    private val history = ArrayList<JSONObject>()
    @Volatile private var turnJob: Job? = null
    @Volatile private var micJob: Job? = null
    @Volatile var muted = false
    @Volatile var state = State.IDLE; private set
    @Volatile private var voiceTurn = false

    private class Speech(val text: String, val pcm: Deferred<ByteArray?>?)

    private fun setState(s: State) { state = s; ui.onState(s) }
    val listening get() = micJob?.isActive == true

    // ---------------- microphone loop ----------------
    fun start() {
        if (listening) return
        micJob = scope.launch(Dispatchers.IO) {
            val bargeOk = Prefs.bargeIn && audio.aecAvailable()
            val rec = audio.startMic(Prefs.bargeIn)
            if (rec == null) { ui.onError("Mic start hoy nai. Permission check koro."); return@launch }
            val frame = ShortArray(320)
            val vad = Vad(Prefs.silenceMs, onStart = {
                if (state == State.SPEAKING || state == State.THINKING) interrupt()
                setState(State.RECORDING)
            }, onUtterance = { pcm ->
                val b64 = Base64.encodeToString(pcmToWav(pcm), Base64.NO_WRAP)
                val content = JSONArray().put(JSONObject().put("type", "input_audio")
                    .put("input_audio", JSONObject().put("data", b64).put("format", "wav")))
                // Voice mode: pure voice, no chat bubbles — ball animates + caption shows words.
                startTurn(content, "[voice message]", Prefs.codeMode, voice = true)
            })
            setState(State.LISTENING)
            try {
                while (isActive) {
                    val n = rec.read(frame, 0, frame.size)
                    if (n < 0) break
                    if (n < frame.size) continue
                    val busy = state == State.SPEAKING || state == State.THINKING
                    if (muted || (busy && !bargeOk)) { vad.reset(); continue }
                    vad.feed(frame)
                }
            } finally { audio.stopMic(rec); if (turnJob?.isActive != true) setState(State.IDLE) }
        }
    }

    /** Stops the mic only; a running reply keeps going (e.g. after opening another app). */
    fun stopListening() { micJob?.cancel() }
    fun release() { scope.cancel(); client?.cancel(); audio.stop(); fallback.stop() }

    fun interrupt() {
        client?.cancel(); turnJob?.cancel(); audio.stop(); fallback.stop()
        setState(if (listening) State.LISTENING else State.IDLE)
    }

    /** One voice for both keys: follows the active brain provider (Gemini key or OpenRouter key). */
    private fun synthTts(text: String): ByteArray? {
        val b = BrainClient.resolve() ?: return null
        return if (b.openRouter) OpenRouterTts(b.http).synth(text, Prefs.voice)
        else GeminiTts(b.http).synth(text, Prefs.voice)
    }

    private fun useNeuralTts(t: String): Boolean {
        if (Prefs.fallbackIndic && t.any { it.code in 0x0900..0x09FF }) return false
        return true
    }

    // ---------------- entry points ----------------
    fun sendText(text: String, shown: String = text, forceCode: Boolean = false) {
        ui.onUserMessage(shown)
        startTurn(text, text, Prefs.codeMode || forceCode, voice = false)
    }

    fun say(text: String) {
        interrupt()
        voiceTurn = true
        turnJob = scope.launch(Dispatchers.IO) {
            audio.begin(); setState(State.SPEAKING)
            val clean = TextSanitizer.clean(text)
            ui.onCaption(clean)
            try {
                val pcm = if (useNeuralTts(clean)) synthTts(clean) else null
                if (pcm != null) audio.write(pcm) else fallback.speak(clean)
                audio.drain()
            } finally { if (isActive) setState(if (listening) State.LISTENING else State.IDLE) }
        }
    }

    private fun startTurn(content: Any, placeholder: String, code: Boolean, voice: Boolean) {
        interrupt()
        voiceTurn = voice
        turnJob = scope.launch(Dispatchers.IO) { runTurn(content, placeholder, code, voice) }
    }

    // ---------------- one conversation turn ----------------
    private fun buildMessages(local: List<JSONObject>, code: Boolean): JSONArray {
        val a = JSONArray().put(JSONObject().put("role", "system").put("content", Prompt.build(ctx, code)))
        history.takeLast(20).forEach { a.put(it) }
        local.forEach { a.put(it) }
        return a
    }

    private suspend fun runTurn(content: Any, placeholder: String, code: Boolean, voice: Boolean) {
        val brain = BrainClient.resolve()
        if (brain == null) {
            ui.onError("🔑 Settings e API key boshao — Gemini key ba OpenRouter key (jekono ekta)")
            setState(if (listening) State.LISTENING else State.IDLE)
            return
        }
        client = brain
        val local = ArrayList<JSONObject>()
        local.add(JSONObject().put("role", "user").put("content", content))
        val display = StringBuilder(); val codes = ArrayList<Pair<String, String>>(); var finalText = ""
        setState(State.THINKING); audio.begin()
        try {
            coroutineScope {
                val ch = Channel<Speech>(Channel.UNLIMITED)
                launch { for (s in ch) speak(s); audio.drain() }
                val chunker = SentenceChunker { raw ->
                    val t = TextSanitizer.clean(raw)
                    if (t.isNotEmpty()) {
                        val d = if (useNeuralTts(t)) async(Dispatchers.IO) { synthTts(t) } else null
                        ch.trySend(Speech(t, d))
                    }
                }
                val splitter = CodeSplitter({ t -> display.append(t); chunker.add(t) }, { l, c -> codes.add(l to c) })
                try {
                    var iter = 0
                    while (iter++ < 4) {
                        val res = brain.stream(buildMessages(local, code), tools.schema, if (code) 8000 else 2000,
                            if (code) "high" else Prefs.thinking) { splitter.feed(it) }
                        splitter.finish(); chunker.flush()
                        finalText += res.text
                        if (res.toolCalls.isEmpty()) break
                        val tc = JSONArray()
                        res.toolCalls.forEach { c -> tc.put(JSONObject().put("id", c.id).put("type", "function")
                            .put("function", JSONObject().put("name", c.name).put("arguments", c.args))) }
                        val am = JSONObject().put("role", "assistant")
                            .put("content", if (res.text.isBlank()) JSONObject.NULL else res.text).put("tool_calls", tc)
                        if (res.reasoning.length() > 0) am.put("reasoning_details", res.reasoning)   // Gemini 3 needs this echoed back
                        local.add(am)
                        for (c in res.toolCalls) {
                            ensureActive()
                            val r = tools.run(c.name, c.args)
                            local.add(JSONObject().put("role", "tool").put("tool_call_id", c.id).put("content", r))
                        }
                    }
                } finally { ch.close() }
                // text mode: show bubbles; voice mode: caption already showed each sentence
                if (!voice) {
                    val shown = display.toString().trim()
                    if (shown.isNotEmpty()) ui.onMyraMessage(shown)
                    codes.forEach { ui.onCode(it.first, it.second) }
                }
            }
            history.add(JSONObject().put("role", "user").put("content", placeholder))
            history.add(JSONObject().put("role", "assistant").put("content", finalText.ifBlank { "(done)" }))
            while (history.size > 40) history.removeAt(0)
        } catch (e: CancellationException) { throw e
        } catch (e: ApiException) {
            // Honest errors: always show what the server actually said (fixes false "credits shesh").
            val srv = e.message?.trim()?.take(160).orEmpty()
            val tail = if (srv.isNotEmpty()) "\n(Server: $srv)" else ""
            val audioBlocked = e.code == 402 && (srv.contains("audio", true) || srv.contains("$0.50") || srv.contains("0.50"))
            val m = when (e.code) {
                401 -> "API key ta vul mone hocche. Settings e key ta check koro.$tail"
                402 -> if (audioBlocked)
                    "Voice-এর জন্য OpenRouter $0.50 balance চায়। Settings → API → Gemini key ON করো, তাহলে voice চলবে।$tail"
                    else "Server request ta reject koreche (402).$tail"
                429 -> "Ektu beshi request hoye geche, ektu pore abar try koro.$tail"
                else -> "API error ${e.code}.$tail"
            }
            if (voice) {
                // voice mode: speak the error, no chat bubble
                val vm = when {
                    e.code == 401 -> "API key ta check koro"
                    audioBlocked -> "Voice-er jonno Gemini key chalu koro"
                    else -> "Error hoyeche, abar try koro"
                }
                try { fallback.speak(vm) } catch (_: Exception) {}
            } else ui.onError(m)
        } catch (e: Exception) {
            currentCoroutineContext().ensureActive()
            if (voice) try { fallback.speak("Error hoyeche, abar try koro") } catch (_: Exception) {}
            else ui.onError("Error: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            if (currentCoroutineContext().isActive) setState(if (listening) State.LISTENING else State.IDLE)
        }
    }

    private suspend fun speak(s: Speech) {
        setState(State.SPEAKING)
        if (voiceTurn) ui.onCaption(s.text)  // live subtitle under the ball (no chat bubble)
        val pcm = s.pcm?.await()
        if (pcm != null) withContext(Dispatchers.IO) { audio.write(pcm) } else fallback.speak(s.text)
    }
}
