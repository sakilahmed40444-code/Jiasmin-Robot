# 🔥 LIA Native v1.1 — Android app (Kotlin)

**"Talk to it. Watch it build."** — ab asli native Android app me:
floating bubble, full phone control (screen dekho + tap + scroll + type),
17 personalities, Website Forge.

## 🆕 v1.1 me naya (Zara-style functions)

- **🎤 Wake word mode** — Voice tab me ON karo: LIA hamesha sunegi, "hello lia" bolo tabhi jawab degi; "bye bye" bolo to wapas sunne lagegi. Auto timeout setting bhi.
- **🔊 Voice chooser** — Settings me phone ki saari TTS voices me se apni pasand ki awaaz chuno.
- **🎭 17 personalities + Custom** — Boss, Soft Romantic Listener, Hyper Energetic, Savage Girl, Mystical, MT Assistant… aur apni khud ki personality likho.
- **🧠 Memories** — "yaad rakho mera birthday 5 Jan hai" bolo, ya Settings → My Memories me add karo. Lia baat me yaad rakhegi.
- **🔑 3 API keys** — Gemini (brain), OpenRouter (backup brain), Serp API (web search). Keys sirf phone me.
- **🌤️ Asli mausam** — "mausam kaisa hai?" bolo: GPS se location lekar bina key ke live mausam.
- **🔐 GRANT ALL** — Setup me ek button se saari permissions ek saath.

> ⚠️ Ye **Android Studio project** hai — Hopweb se APK nahi banega.
> PC par Android Studio chahiye APK build karne ke liye.

## Features

| Feature | Kahan |
|---|---|
| 🫧 **Floating bubble** | App minimize karo → chhoti gol LIA screen par tairti rahegi. Drag karo, tap karo → voice screen khul jayegi |
| 👁️ **Screen dekho** | "Screen padho" bolo → accessibility se screen ki lines padh ke sunayegi |
| 👆 **Full control** | "Neeche scroll karo", "'Send' dabao", "Type karo hello", "Wapas jao", "Home jao" |
| 🔐 **Setup screen** | Mic, Bubble (draw over apps), Accessibility, Battery OFF, Notifications — one-tap rows, live ✅/❌ |
| 🎙️ **Voice loop** | Native STT + TTS — sunai bhi dega, bolega bhi (web wali dikkat nahi) |
| 🎭 **10 personalities** | Normal…Nautanki, beech baat me badlo |
| 🔥 **Website Forge** | "Ek cafe ki website banao" → 3D reactor scene, real SSE stream, Share/Save/Edit |
| 📱 **Phone actions** | 25+ apps kholo, call (dialer), WhatsApp/SMS composer |

## APK kaise banayein

### Option A: Sirf phone se (PC nahi chahiye) ✅ — RECOMMENDED

GitHub ka free cloud computer tumhara APK banake dega. Sab phone ke browser se:

1. **github.com** kholo (Chrome) → **Sign up** (free account banao, email verify karo).
2. **New repository** banao: naam `lia-app`, Public rakho → **Create repository**.
3. Repo page par **"uploading an existing file"** link dabao → **`lia-native-v1.0.zip`** upload karo → **Commit changes**.
4. Ab **Add file → Create new file** dabao. Filename box me likho:
   `.github/workflows/main.yml`
   Neeche bade box me **yeh paste karo**:
   ```yaml
   name: Build LIA APK
   on:
     push:
     workflow_dispatch:
   jobs:
     build:
       runs-on: ubuntu-latest
       steps:
         - name: Checkout code
           uses: actions/checkout@v4
         - name: Unzip project
           run: unzip -o lia-native-*.zip -d build-src
         - name: Set up JDK 17
           uses: actions/setup-java@v4
           with:
             distribution: 'temurin'
             java-version: '17'
         - name: Set up Android SDK
           run: |
             yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null || true
             "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "platforms;android-34" "build-tools;34.0.0" "platform-tools"
         - name: Build debug APK
           run: |
             cd build-src
             chmod +x gradlew
             ./gradlew assembleDebug --stacktrace
         - name: Upload APK
           uses: actions/upload-artifact@v4
           with:
             name: lia-apk
             path: build-src/app/build/outputs/apk/debug/app-debug.apk
   ```
   → **Commit changes**.
5. Upar **Actions** tab kholo → workflow chal raha hoga (pehli baar 5–10 min lag sakta hai).
6. Build green ✅ hone par neeche **Artifacts** me `lia-apk.zip` → download karo → Files app se extract karo → **`app-debug.apk`** milega.
7. APK par tap karo → **"Install unknown apps" Allow** karo → Install. Ho gaya! 🎉

> Note: yehi `main.yml` zip ke andar `.github/workflows/` me bhi rakha hai reference ke liye.

### Option B: PC par Android Studio se

## Pehli baar app kholne par

1. **Setup** tab → har ❌ row par tap karke Allow karo:
   - 🎙️ Microphone → Allow
   - 🫧 Draw over apps → **LIA ko Allow karo** (bubble ke liye)
   - ♿ Accessibility → **LIA Service ON karo** (screen control ke liye)
   - 🔋 Battery optimization → **Don't optimize**
2. **Settings** → naam + (optional) Gemini API key dalo. Bina key ke offline dimaag chalega.
3. **Home** → 🫧 Bubble chalu karo. Ab app minimize karke bhi bubble se baat karo!

## Sach (imandaar note)

- **Accessibility aur Bubble permission koi app khud on nahi kar sakti** — Android tumse khud puchega, ek baar Allow dabana hai. Isi liye Setup screen hai.
- WhatsApp/SMS **composer** khulta hai — Send tum dabate ho (Play Store policy).
- Voice input (STT) ke liye internet chahiye — Google ka free engine, koi key nahi.

## Project structure

```
lia-native/
├── settings.gradle, build.gradle, gradle.properties
├── gradle/wrapper/gradle-wrapper.properties   (Gradle 8.7)
└── app/
    ├── build.gradle                            (minSdk 26, viewBinding, koi org.json dep nahi)
    └── src/main/
        ├── AndroidManifest.xml                 (BubbleService FGS specialUse, AccessibilityService, FileProvider)
        ├── res/xml/accessibility_config.xml
        ├── res/xml/filepaths.xml
        ├── res/values/ (strings, colors, themes)
        └── java/com/lia/assistant/
            ├── LiaApp.kt
            ├── data/Prefs.kt
            ├── brain/ (LanguageDetector, Personalities, ConversationMemory, OfflineBrain, GeminiClient, CommandParser, LiaResponder)
            ├── action/ActionExecutor.kt
            ├── voice/VoiceEngine.kt            (SpeechRecognizer + TextToSpeech)
            ├── service/ (LiaAccessibilityService, BubbleService)
            ├── ui/ (MainActivity, HomeFragment, VoiceFragment, ChatFragment, ForgeFragment, SetupFragment, SettingsFragment, BubbleView, ForgeReactorView, Ui)
            └── forge/ForgeManager.kt           (SSE streaming)
```

## Tech

Kotlin · AppCompat + Material (programmatic UI, koi XML layout nahi) · HttpURLConnection (SSE + REST, koi OkHttp nahi) · org.json (Android SDK wala) · TextToSpeech + SpeechRecognizer · AccessibilityService · WindowManager overlay
