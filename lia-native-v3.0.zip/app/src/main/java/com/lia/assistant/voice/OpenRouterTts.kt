package com.lia.assistant.voice

import android.media.MediaPlayer
import android.util.Log
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * OpenRouter TTS — POST /api/v1/audio/speech (OpenAI-compatible).
 * Model: google/gemini-3.1-flash-tts-preview → Kore, Aoede… (Gemini prebuilt voices).
 * Key thakle manusher moto gola — Zara-r moto.
 */
object OpenRouterTts {

    @Volatile private var player: MediaPlayer? = null
    @Volatile private var stopped = false

    fun speak(text: String, voice: String, apiKey: String, onDone: () -> Unit) {
        stop()
        stopped = false
        Thread {
            try {
                val mp3 = fetchMp3(text, voice, apiKey)
                if (stopped || mp3 == null || mp3.isEmpty()) { onDone(); return@Thread }
                playMp3(mp3, onDone)
            } catch (e: Exception) {
                Log.e("OpenRouterTts", "speak fail", e)
                onDone()
            }
        }.start()
    }

    fun stop() {
        stopped = true
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
    }

    private fun fetchMp3(text: String, voice: String, apiKey: String): ByteArray? {
        val clean = text.take(800)
        val body = org.json.JSONObject().apply {
            put("model", "google/gemini-3.1-flash-tts-preview")
            put("input", clean)
            put("voice", voice.ifBlank { "Kore" })
            put("response_format", "mp3")
            put("instructions", "Speak warmly and naturally, like a caring friend.")
        }.toString()
        val c = URL("https://openrouter.ai/api/v1/audio/speech")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer $apiKey")
        c.setRequestProperty("HTTP-Referer", "https://priya.assistant")
        c.setRequestProperty("X-Title", "Priya Assistant")
        c.connectTimeout = 25000
        c.readTimeout = 45000
        c.doOutput = true
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        if (c.responseCode != 200) {
            val err = try { c.errorStream?.bufferedReader()?.readText()?.take(200) } catch (_: Exception) { "" }
            Log.e("OpenRouterTts", "HTTP ${c.responseCode}: $err")
            return null
        }
        return c.inputStream.use { it.readBytes() }.takeIf { it.size > 1000 }
    }

    private fun playMp3(mp3: ByteArray, onDone: () -> Unit) {
        try {
            val f = File.createTempFile("priya_tts", ".mp3")
            f.writeBytes(mp3)
            val mp = MediaPlayer()
            player = mp
            var done = false
            fun finish() { if (!done) { done = true; onDone() } }
            mp.setOnCompletionListener { finish() }
            mp.setOnErrorListener { _, _, _ -> finish(); true }
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            if (stopped) { finish(); return }
            mp.start()
        } catch (e: Exception) {
            Log.e("OpenRouterTts", "play fail", e)
            onDone()
        }
    }
}
