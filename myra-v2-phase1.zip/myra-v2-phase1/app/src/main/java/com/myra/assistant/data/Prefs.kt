package com.myra.assistant.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    private lateinit var sp: SharedPreferences
    private lateinit var secure: SharedPreferences

    fun init(c: Context) {
        val app = c.applicationContext
        sp = app.getSharedPreferences("myra", Context.MODE_PRIVATE)
        secure = try {
            val mk = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(app, "myra_secure", mk,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
        } catch (e: Exception) { app.getSharedPreferences("myra_secure_fallback", Context.MODE_PRIVATE) }
    }

    private fun str(k: String, d: String) = sp.getString(k, d) ?: d
    private fun put(k: String, v: Any) {
        sp.edit().apply { when (v) { is String -> putString(k, v); is Boolean -> putBoolean(k, v); is Int -> putInt(k, v); else -> {} } }.apply()
    }

    var apiKey: String
        get() = secure.getString("openrouter_key", "") ?: ""
        set(v) { secure.edit().putString("openrouter_key", v.trim()).apply() }
    // ---- Second AI key: Google Gemini (never auto-changed; only written on explicit Save/Test) ----
    var geminiKey: String
        get() = secure.getString("gemini_key", "") ?: ""
        set(v) { secure.edit().putString("gemini_key", v.trim()).apply() }
    var geminiKeyOn: Boolean get() = sp.getBoolean("gemini_key_on", true)
        set(v) = put("gemini_key_on", v)
    var openRouterKeyOn: Boolean get() = sp.getBoolean("or_key_on", true)
        set(v) = put("or_key_on", v)
    fun hasAnyKey() = (geminiKeyOn && geminiKey.isNotBlank()) || (openRouterKeyOn && apiKey.isNotBlank())
    // ---- Providers: AUTO = use whichever key is set (Gemini first) ----
    var brainProvider: String get() = str("brain_provider", "AUTO")
        set(v) = put("brain_provider", v)
    var geminiModel: String get() = str("gemini_model", "gemini-3.8-flash")
        set(v) = put("gemini_model", v)
    // Single unified voice — same voice list for Gemini key and OpenRouter key, never separated.
    var voice: String get() = str("voice", "Kore")
        set(v) = put("voice", v)
    var userName: String get() = str("user_name", "")
        set(v) = put("user_name", v)
    var userEmail: String get() = str("user_email", "")
        set(v) = put("user_email", v)
    var avatarUri: String get() = str("avatar_uri", "")
        set(v) = put("avatar_uri", v)
    var personality: String get() = str("personality_mode", "GirlFriend")
        set(v) = put("personality_mode", v)
    // Custom personalities: JSON array string [{"name":"...","prompt":"..."}]
    var customPersonas: String get() = str("custom_personas_json", "[]")
        set(v) = put("custom_personas_json", v)
    var screenCapGranted: Boolean get() = sp.getBoolean("screen_cap_granted", false)
        set(v) = put("screen_cap_granted", v)
    var brainModel: String get() = str("brain_model", "google/gemini-3.8-flash")
        set(v) = put("brain_model", v)
    var thinking: String get() = str("thinking_level", "low")
        set(v) = put("thinking_level", v)
    var ttsModel: String get() = str("tts_model", "mistralai/voxtral-mini-tts-2603")
        set(v) = put("tts_model", v)
    var ttsVoice: String get() = str("tts_voice", "en_paul_neutral")
        set(v) = put("tts_voice", v)
    var ttsRate: Int get() = sp.getInt("tts_rate", 24000)
        set(v) = put("tts_rate", v)
    var language: String get() = str("reply_language", "AUTO")
        set(v) = put("reply_language", v)
    var bargeIn: Boolean get() = sp.getBoolean("barge_in", true)
        set(v) = put("barge_in", v)
    var silenceMs: Int get() = sp.getInt("vad_silence_ms", 700)
        set(v) = put("vad_silence_ms", v)
    var confirm: Boolean get() = sp.getBoolean("confirm_sensitive", true)
        set(v) = put("confirm_sensitive", v)
    var memoryOn: Boolean get() = sp.getBoolean("memory_enabled", true)
        set(v) = put("memory_enabled", v)
    var webSearch: Boolean get() = sp.getBoolean("web_search", false)
        set(v) = put("web_search", v)
    var fallbackIndic: Boolean get() = sp.getBoolean("fallback_indic", true)
        set(v) = put("fallback_indic", v)
    var codeMode: Boolean get() = sp.getBoolean("code_mode", false)
        set(v) = put("code_mode", v)

    // ---- Prime contacts (JSON array in prime_contacts_json) ----
    fun primes(): List<Pair<String, String>> {
        val raw = sp.getString("prime_contacts_json", null)
        if (raw == null) {
            val n = sp.getString("prime_name", "") ?: ""; val num = sp.getString("prime_number", "") ?: ""
            return if (n.isNotBlank() && num.isNotBlank()) listOf(n to num) else emptyList()
        }
        return try { val a = JSONArray(raw); (0 until a.length()).map { a.getJSONObject(it).let { o -> o.optString("name") to o.optString("number") } } }
        catch (e: Exception) { emptyList() }
    }
    fun savePrimes(l: List<Pair<String, String>>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("name", it.first).put("number", it.second)) }
        sp.edit().putString("prime_contacts_json", a.toString()).apply()
    }

    // ---- Memory (key/value) ----
    private fun mem(): JSONObject = try { JSONObject(sp.getString("memory_json", "{}")!!) } catch (e: Exception) { JSONObject() }
    fun memoryAll(): Map<String, String> = mem().let { m -> m.keys().asSequence().associateWith { m.optString(it) } }
    fun remember(k: String, v: String) { val m = mem(); m.put(k, v); sp.edit().putString("memory_json", m.toString()).apply() }
    fun forget(k: String) { val m = mem(); m.remove(k); sp.edit().putString("memory_json", m.toString()).apply() }
    fun clearMemory() { sp.edit().remove("memory_json").apply() }
}
