package com.lia.assistant.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin

/** AI core diagnostics — animated waveform. */
class WaveView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF2E88")
        strokeWidth = 4f
        style = Paint.Style.STROKE
    }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800; repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0 || h <= 0) return
        val mid = h / 2f
        var prevX = 0f; var prevY = mid
        val steps = 60
        for (i in 1..steps) {
            val x = w * i / steps
            val y = mid + sin(i * 0.35f + t * 12.56f).toFloat() * (h * 0.38f) *
                (0.4f + 0.6f * sin(i * 0.11f + t * 6.28f).toFloat().let { kotlin.math.abs(it) })
            c.drawLine(prevX, prevY, x, y, paint)
            prevX = x; prevY = y
        }
    }
}
