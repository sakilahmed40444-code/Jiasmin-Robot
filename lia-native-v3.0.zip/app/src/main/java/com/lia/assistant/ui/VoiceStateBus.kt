package com.lia.assistant.ui

/** Home ka voice loop → bubble ka orb: sunte waqt hara, bolte waqt gulabi. */
object VoiceStateBus {
    private var cb: ((BubbleView.State) -> Unit)? = null

    fun listen(l: (BubbleView.State) -> Unit) { cb = l }
    fun clear() { cb = null }
    fun state(s: BubbleView.State) {
        try { cb?.invoke(s) } catch (_: Exception) { }
    }
}
