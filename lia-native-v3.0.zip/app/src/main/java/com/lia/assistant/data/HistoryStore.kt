package com.lia.assistant.data

import android.content.Context

/** Kotha-barta history — save, delete, download. */
object HistoryStore {
    private const val FILE = "chat_history.txt"
    private const val MAX = 500

    data class Entry(val who: String, val text: String, val time: String)

    private fun file(ctx: Context) = java.io.File(ctx.filesDir, FILE)

    @Synchronized
    fun add(ctx: Context, who: String, text: String) {
        try {
            val t = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.getDefault())
                .format(java.util.Date())
            val line = "$t\t$who\t${text.replace("\n", " ").take(500)}\n"
            val f = file(ctx)
            val lines = if (f.exists()) f.readLines() else emptyList()
            val kept = (lines + line).takeLast(MAX)
            f.writeText(kept.joinToString("\n"))
        } catch (_: Exception) { }
    }

    @Synchronized
    fun all(ctx: Context): List<Entry> {
        return try {
            val f = file(ctx)
            if (!f.exists()) return emptyList()
            f.readLines().mapNotNull { l ->
                val p = l.split("\t", limit = 3)
                if (p.size == 3) Entry(p[1], p[2], p[0]) else null
            }.reversed()
        } catch (_: Exception) { emptyList() }
    }

    @Synchronized
    fun clear(ctx: Context) {
        try { file(ctx).delete() } catch (_: Exception) { }
    }

    @Synchronized
    fun exportFile(ctx: Context): java.io.File? {
        return try {
            val src = file(ctx)
            if (!src.exists()) return null
            val dst = java.io.File(ctx.getExternalFilesDir(null), "priya-history.txt")
            src.copyTo(dst, overwrite = true)
            dst
        } catch (_: Exception) { null }
    }
}
