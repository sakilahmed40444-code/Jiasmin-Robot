export type ToolCall = {
  id: string;
  name: string;
  args: Record<string, unknown>;
};

export const TOOL_DECLARATIONS = [
  {
    name: "openWebsite",
    description: "Open a website requested by the user in the device browser.",
    parameters: {
      type: "object",
      properties: {
        url: {
          type: "string",
          description: "A complete URL beginning with https://"
        }
      },
      required: ["url"]
    }
  }
];

export class ToolManager {
  async execute(call: ToolCall): Promise<Record<string, unknown>> {
    if (call.name === "openWebsite") {
      const raw = String(call.args.url ?? "").trim();
      const url = /^https?:\\/\\//i.test(raw) ? raw : `https://${raw}`;
      try {
        const parsed = new URL(url);
        if (!["http:", "https:"].includes(parsed.protocol)) {
          return { ok: false, error: "Only http and https URLs are allowed." };
        }
        window.open(parsed.toString(), "_blank", "noopener,noreferrer");
        return { ok: true, opened: parsed.toString() };
      } catch {
        return { ok: false, error: "Invalid website URL." };
      }
    }

    return { ok: false, error: `Unknown tool: ${call.name}` };
  }
}