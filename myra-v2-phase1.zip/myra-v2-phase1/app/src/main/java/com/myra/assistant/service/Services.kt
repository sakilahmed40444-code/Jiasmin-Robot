package com.myra.assistant.service

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AccessibilityHelperService : AccessibilityService() {
    companion object {
        @Volatile var instance: AccessibilityHelperService? = null
        fun isEnabled(c: Context): Boolean {
            val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            val cn = ComponentName(c, AccessibilityHelperService::class.java)
            return s.contains(cn.flattenToString()) || s.contains(cn.flattenToShortString())
        }
    }
    override fun onServiceConnected() { instance = this }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun clickOnText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            var x: AccessibilityNodeInfo? = n
            while (x != null) { if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK); x = x.parent }
        }
        return false
    }

    fun typeText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }
    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) { n.getChild(i)?.let { c -> findEditable(c)?.let { return it } } }
        return null
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val a = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        fun find(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            if (n.isScrollable) return n
            for (i in 0 until n.childCount) { n.getChild(i)?.let { c -> find(c)?.let { return it } } }
            return null
        }
        return find(root)?.performAction(a) ?: false
    }

    fun readScreen(): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > 4000) return
            val t = n.text ?: n.contentDescription
            if (!t.isNullOrBlank()) sb.append(t).append('\n')
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return sb.toString().take(4000)
    }
}

class MyraNotificationListener : NotificationListenerService() {
    companion object {
        private val recent = java.util.ArrayDeque<String>()
        fun latest(): List<String> = synchronized(recent) { recent.toList() }
    }
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val e = sbn.notification.extras
        val line = "${sbn.packageName}: ${e.getCharSequence("android.title") ?: ""} - ${e.getCharSequence("android.text") ?: ""}"
        synchronized(recent) { recent.addFirst(line.take(300)); while (recent.size > 20) recent.removeLast() }
    }
}
