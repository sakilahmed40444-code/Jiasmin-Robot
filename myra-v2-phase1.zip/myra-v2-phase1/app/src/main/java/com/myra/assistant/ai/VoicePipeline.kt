package com.myra.assistant.ai

import android.content.Context
import android.util.Base64
import com.myra.assistant.data.Prefs
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import org.json.JSONArray
import org.json.JSONObject

interface PipelineUi {
    fun onState(s: State)
    fun onUserMessage(t: String)
    fun onMyraMessage(t: String)
    fun onCode(lang: String, code: String)
    fun onError(msg: String)
    fun onAmplitude(a: Float)
    suspend fun confirm(msg: String): Boolean
}

class VoicePipeline(private val ctx: Context, private val ui: PipelineUi) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val client = OpenRouterClient()
    private val tts = OpenRouterTts(client.http)
    private val audio = AudioEngine().also { it.onAmp = { a -> ui.onAmplitude(a) } }
    private val fallback = FallbackTts(ctx)
    private val tools = ToolExecutor(ctx, ui)
    private val history = ArrayList<JSONObject>()
    @Volatile private var turnJob: Job? = null
    @Volatile private var micJob: Job? = null
    @Volatile var muted = false
    @Volatile var state = State.IDLE; private set

    private class Speech(val text: String, val pcm: Deferred<ByteArray?>?)

    private fun setState(s: State) { state = s; ui.onState(s) }
    val listening get() = micJob?.isActive == true

    // ---------------- microphone loop ----------------
    fun start() {
        if (listening) return
        micJob = scope.launch(Dispatchers.IO) {
            val bargeOk = Prefs.bargeIn && audio.aecAvailable()
            val rec = audio.startMic(Prefs.bargeIn)
            if (rec == null) { ui.onError("Mic start hoy nai. Permission check koro."); return@launch }
            val frame = ShortArray(320)
            val vad = Vad(Prefs.silenceMs, onStart = {
                if (state == State.SPEAKING || state == State.THINKING) interrupt()
                setState(State.RECORDING)
            }, onUtterance = { pcm ->
                val b64 = Base64.encodeToString(pcmToWav(pcm), Base64.NO_WRAP)
                val content = JSONArray().put(JSONObject().put("type", "input_audio")
                    .put("input_audio", JSONObject().put("data", b64).put("format", "wav")))
                ui.onUserMessage("🎤 (voice)")
                startTurn(content, "[voice message]", Prefs.codeMode)
            })
            setState(State.LISTENING)
            try {
                while (isActive) {
                    val n = rec.read(frame, 0, frame.size)
                    if (n < 0) break
                    if (n < frame.size) continue
                    val busy = state == State.SPEAKING || state == State.THINKING
                    if (muted || (busy && !bargeOk)) { vad.reset(); continue }
                    vad.feed(frame)
                }
            } finally { audio.stopMic(rec); if (turnJob?.isActive != true) setState(State.IDLE) }
        }
    }

    /** Stops the mic only; a running reply keeps going (e.g. after opening another app). */
    fun stopListening() { micJob?.cancel() }
    fun release() { scope.cancel(); client.cancel(); audio.stop(); fallback.stop() }

    fun interrupt() {
        client.cancel(); turnJob?.cancel(); audio.stop(); fallback.stop()
        setState(if (listening) State.LISTENING else State.IDLE)
    }

    // ---------------- entry points ----------------
    fun sendText(text: String, shown: String = text, forceCode: Boolean = false) {
        ui.onUserMessage(shown)
        startTurn(text, text, Prefs.codeMode || forceCode)
    }

    fun say(text: String) {
        interrupt()
        turnJob = scope.launch(Dispatchers.IO) {
            audio.begin(); setState(State.SPEAKING)
            val clean = TextSanitizer.clean(text)
            try {
                val indic = clean.any { it in '\u0900'..'\u09FF' }
                val pcm = if (Prefs.ttsModel.isBlank() || (Prefs.fallbackIndic && indic)) null else tts.synth(clean)
                if (pcm != null) audio.write(pcm) else fallback.speak(clean)
                audio.drain()
            } finally { if (isActive) setState(if (listening) State.LISTENING else State.IDLE) }
        }
    }

    private fun startTurn(content: Any, placeholder: String, code: Boolean) {
        interrupt()
        turnJob = scope.launch(Dispatchers.IO) { runTurn(content, placeholder, code) }
    }

    // ---------------- one conversation turn ----------------
    private fun buildMessages(local: List<JSONObject>, code: Boolean): JSONArray {
        val a = JSONArray().put(JSONObject().put("role", "system").put("content", Prompt.build(ctx, code)))
        history.takeLast(20).forEach { a.put(it) }
        local.forEach { a.put(it) }
        return a
    }

    private suspend fun runTurn(content: Any, placeholder: String, code: Boolean) {
        val local = ArrayList<JSONObject>()
        local.add(JSONObject().put("role", "user").put("content", content))
        val display = StringBuilder(); val codes = ArrayList<Pair<String, String>>(); var finalText = ""
        setState(State.THINKING); audio.begin()
        try {
            coroutineScope {
                val ch = Channel<Speech>(Channel.UNLIMITED)
                launch { for (s in ch) speak(s); audio.drain() }
                val chunker = SentenceChunker { raw ->
                    val t = TextSanitizer.clean(raw)
                    if (t.isNotEmpty()) {
                        val indic = Prefs.fallbackIndic && t.any { it in '\u0900'..'\u09FF' }
                        val d = if (indic || Prefs.ttsModel.isBlank()) null else async(Dispatchers.IO) { tts.synth(t) }
                        ch.trySend(Speech(t, d))
                    }
                }
                val splitter = CodeSplitter({ t -> display.append(t); chunker.add(t) }, { l, c -> codes.add(l to c) })
                try {
                    var iter = 0
                    while (iter++ < 4) {
                        val res = client.stream(buildMessages(local, code), tools.schema, if (code) 8000 else 2000,
                            if (code) "high" else Prefs.thinking) { splitter.feed(it) }
                        splitter.finish(); chunker.flush()
                        finalText += res.text
                        if (res.toolCalls.isEmpty()) break
                        val tc = JSONArray()
                        res.toolCalls.forEach { c -> tc.put(JSONObject().put("id", c.id).put("type", "function")
                            .put("function", JSONObject().put("name", c.name).put("arguments", c.args))) }
                        val am = JSONObject().put("role", "assistant")
                            .put("content", if (res.text.isBlank()) JSONObject.NULL else res.text).put("tool_calls", tc)
                        if (res.reasoning.length() > 0) am.put("reasoning_details", res.reasoning)   // Gemini 3 needs this echoed back
                        local.add(am)
                        for (c in res.toolCalls) {
                            ensureActive()
                            val r = tools.run(c.name, c.args)
                            local.add(JSONObject().put("role", "tool").put("tool_call_id", c.id).put("content", r))
                        }
                    }
                } finally { ch.close() }
                // show text + code boxes immediately; speech may still be playing
                val shown = display.toString().trim()
                if (shown.isNotEmpty()) ui.onMyraMessage(shown)
                codes.forEach { ui.onCode(it.first, it.second) }
            }
            history.add(JSONObject().put("role", "user").put("content", placeholder))
            history.add(JSONObject().put("role", "assistant").put("content", finalText.ifBlank { "(done)" }))
            while (history.size > 40) history.removeAt(0)
        } catch (e: CancellationException) { throw e
        } catch (e: ApiException) {
            val m = when (e.code) {
                401 -> "API key galat hai. Settings e key check koro."
                402 -> "OpenRouter credits shesh."
                429 -> "Onek beshi request, ektu pore try koro."
                else -> "API error ${e.code}: ${e.message?.take(120)}"
            }
            ui.onError(m); if (e.code == 401 || e.code == 402) try { fallback.speak(m) } catch (_: Exception) {}
        } catch (e: Exception) {
            currentCoroutineContext().ensureActive()
            ui.onError("Error: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            if (currentCoroutineContext().isActive) setState(if (listening) State.LISTENING else State.IDLE)
        }
    }

    private suspend fun speak(s: Speech) {
        setState(State.SPEAKING)
        val pcm = s.pcm?.await()
        if (pcm != null) withContext(Dispatchers.IO) { audio.write(pcm) } else fallback.speak(s.text)
    }
}
