package com.myra.assistant.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    private lateinit var sp: SharedPreferences
    private lateinit var secure: SharedPreferences

    fun init(c: Context) {
        val app = c.applicationContext
        sp = app.getSharedPreferences("myra", Context.MODE_PRIVATE)
        secure = try {
            val mk = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(app, "myra_secure", mk,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
        } catch (e: Exception) { app.getSharedPreferences("myra_secure_fallback", Context.MODE_PRIVATE) }
    }

    private fun str(k: String, d: String) = sp.getString(k, d) ?: d
    private fun put(k: String, v: Any) {
        sp.edit().apply { when (v) { is String -> putString(k, v); is Boolean -> putBoolean(k, v); is Int -> putInt(k, v); else -> {} } }.apply()
    }

    var apiKey: String
        get() = secure.getString("openrouter_key", "") ?: ""
        set(v) { secure.edit().putString("openrouter_key", v.trim()).apply() }
    // ---- Second AI key: Google Gemini (never auto-changed; only written on explicit Save/Test) ----
    var geminiKey: String
        get() = secure.getString("gemini_key", "") ?: ""
        set(v) { secure.edit().putString("gemini_key", v.trim()).apply() }
    var geminiKeyOn: Boolean get() = sp.getBoolean("gemini_key_on", true)
        set(v) = put("gemini_key_on", v)
    var openRouterKeyOn: Boolean get() = sp.getBoolean("or_key_on", true)
        set(v) = put("or_key_on", v)
    fun hasAnyKey() = (geminiKeyOn && geminiKey.isNotBlank()) || (openRouterKeyOn && apiKey.isNotBlank())
    var voiceOn: Boolean get() = sp.getBoolean("voice_on", true)
        set(v) = put("voice_on", v)
    var voiceInputOn: Boolean get() = sp.getBoolean("voice_input_on", true)
        set(v) = put("voice_input_on", v)
    var wakeWord: String get() = sp.getString("wake_word", "Hello Myra") ?: "Hello Myra"
        set(v) = put("wake_word", v)
    var dismissWord: String get() = sp.getString("dismiss_word", "Bye Bye") ?: "Bye Bye"
        set(v) = put("dismiss_word", v)
    var autoTimeoutSec: Int get() = sp.getInt("auto_timeout", 10)
        set(v) = put("auto_timeout", v)
    var fastReply: Boolean get() = sp.getBoolean("fast_reply", false)
        set(v) = put("fast_reply", v)
    var webSearchGemini: Boolean get() = sp.getBoolean("web_search_gemini", false)
        set(v) = put("web_search_gemini", v)
    var floatingBall: Boolean get() = sp.getBoolean("floating_ball", false)
        set(v) = put("floating_ball", v)
    var orTtsModel: String get() = sp.getString("or_tts_model", "google/gemini-3.8-flash-tts") ?: "google/gemini-3.8-flash-tts"
        set(v) = put("or_tts_model", v)
    var geminiTtsModel: String get() = sp.getString("gemini_tts_model", "gemini-3.8-flash-lite-tts") ?: "gemini-3.8-flash-lite-tts"
        set(v) = put("gemini_tts_model", v)
    var appName: String get() = sp.getString("app_name", "MYRA") ?: "MYRA"
        set(v) = put("app_name", v)
    var addressMe: String get() = sp.getString("address_me", "সবুজ জান") ?: "সবুজ জান"
        set(v) = put("address_me", v)
    // Notes + History
    fun notes(): List<String> = sp.getString("notes_json", "[]")?.let {
        try { val a = org.json.JSONArray(it); List(a.length()) { i -> a.getString(i) } } catch (e: Exception) { emptyList() }
    } ?: emptyList()
    fun setNotes(l: List<String>) = put("notes_json", org.json.JSONArray(l).toString())
    fun addNote(t: String) = setNotes(notes() + t)
    fun history(): List<String> = sp.getString("history_json", "[]")?.let {
        try { val a = org.json.JSONArray(it); List(a.length()) { i -> a.getString(i) } } catch (e: Exception) { emptyList() }
    } ?: emptyList()
    fun setHistory(l: List<String>) = put("history_json", org.json.JSONArray(l).toString())
    fun addHistory(t: String) = setHistory(history() + t)
    var needGreet: Boolean get() = sp.getBoolean("need_greet", false)
        set(v) = put("need_greet", v)
    // ---- Providers: AUTO = use whichever key is set (Gemini first) ----
    var brainProvider: String get() = str("brain_provider", "AUTO")
        set(v) = put("brain_provider", v)
    var geminiModel: String get() = str("gemini_model", "gemini-2.5-flash")
        set(v) = put("gemini_model", v)
    // Single unified voice — same voice list for Gemini key and OpenRouter key, never separated.
    var voice: String get() = str("voice", "Kore")
        set(v) = put("voice", v)
    var userName: String get() = str("user_name", "")
        set(v) = put("user_name", v)
    var userEmail: String get() = str("user_email", "")
        set(v) = put("user_email", v)
    var avatarUri: String get() = str("avatar_uri", "")
        set(v) = put("avatar_uri", v)
    var personality: String get() = str("personality_mode", "GirlFriend")
        set(v) = put("personality_mode", v)
    // Custom personalities: JSON array string [{"name":"...","prompt":"..."}]
    var customPersonas: String get() = str("custom_personas_json", "[]")
        set(v) = put("custom_personas_json", v)
    var screenCapGranted: Boolean get() = sp.getBoolean("screen_cap_granted", false)
        set(v) = put("screen_cap_granted", v)
    var brainModel: String get() = str("brain_model", "google/gemini-flash-1.5")
        set(v) = put("brain_model", v)
    var thinking: String get() = str("thinking_level", "low")
        set(v) = put("thinking_level", v)
    var ttsModel: String get() = str("tts_model", "mistralai/voxtral-mini-tts-2603")
        set(v) = put("tts_model", v)
    var ttsVoice: String get() = str("tts_voice", "en_paul_neutral")
        set(v) = put("tts_voice", v)
    var ttsRate: Int get() = sp.getInt("tts_rate", 24000)
        set(v) = put("tts_rate", v)
    var language: String get() = str("reply_language", "AUTO")
        set(v) = put("reply_language", v)
    var bargeIn: Boolean get() = sp.getBoolean("barge_in", true)
        set(v) = put("barge_in", v)
    var speechRate: Float get() = sp.getFloat("speech_rate", 1.0f)
        set(v) = put("speech_rate", v)
    var pitch: Float get() = sp.getFloat("pitch", 1.0f)
        set(v) = put("pitch", v)
    var silenceMs: Int get() = sp.getInt("vad_silence_ms", 700)
        set(v) = put("vad_silence_ms", v)
    var confirm: Boolean get() = sp.getBoolean("confirm_sensitive", true)
        set(v) = put("confirm_sensitive", v)
    var memoryOn: Boolean get() = sp.getBoolean("memory_enabled", true)
        set(v) = put("memory_enabled", v)
    var webSearch: Boolean get() = sp.getBoolean("web_search", false)
        set(v) = put("web_search", v)
    var fallbackIndic: Boolean get() = sp.getBoolean("fallback_indic", true)
        set(v) = put("fallback_indic", v)
    var codeMode: Boolean get() = sp.getBoolean("code_mode", false)
        set(v) = put("code_mode", v)

    // ---- Prime contacts (JSON array in prime_contacts_json) ----
    fun primes(): List<Pair<String, String>> {
        val raw = sp.getString("prime_contacts_json", null)
        if (raw == null) {
            val n = sp.getString("prime_name", "") ?: ""; val num = sp.getString("prime_number", "") ?: ""
            return if (n.isNotBlank() && num.isNotBlank()) listOf(n to num) else emptyList()
        }
        return try { val a = JSONArray(raw); (0 until a.length()).map { a.getJSONObject(it).let { o -> o.optString("name") to o.optString("number") } } }
        catch (e: Exception) { emptyList() }
    }
    fun savePrimes(l: List<Pair<String, String>>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("name", it.first).put("number", it.second)) }
        sp.edit().putString("prime_contacts_json", a.toString()).apply()
    }

    // ---- Memory (key/value) ----
    private fun mem(): JSONObject = try { JSONObject(sp.getString("memory_json", "{}")!!) } catch (e: Exception) { JSONObject() }
    fun memoryAll(): Map<String, String> = mem().let { m -> m.keys().asSequence().associateWith { m.optString(it) } }
    fun remember(k: String, v: String) { val m = mem(); m.put(k, v); sp.edit().putString("memory_json", m.toString()).apply() }
    fun forget(k: String) { val m = mem(); m.remove(k); sp.edit().putString("memory_json", m.toString()).apply() }
    fun clearMemory() { sp.edit().remove("memory_json").apply() }
}
