import React, { useState } from "react";
import { getApiKey, setApiKey } from "../config";

type Props = {
  open: boolean;
  onClose: () => void;
};

export function SettingsPanel({ open, onClose }: Props) {
  const [key, setKey] = useState(getApiKey());

  if (!open) return null;

  const save = () => {
    setApiKey(key);
    onClose();
  };

  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="model-sheet settings-sheet" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-handle" />
        <div className="sheet-title">Settings</div>

        <label className="field-label">Gemini API key</label>
        <input
          className="api-input"
          type="password"
          autoComplete="off"
          value={key}
          onChange={(e) => setKey(e.target.value)}
          placeholder="Paste your Gemini API key"
        />

        <p className="settings-note">
          Personal testing only. For a public production app, use an ephemeral-token backend instead of shipping a permanent API key in the app.
        </p>

        <button className="save-button" onClick={save}>Save</button>
        <button className="close-sheet" onClick={onClose}>Close</button>
      </div>
    </div>
  );
}