package com.lia.assistant.service

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Screen dekho, tap karo, scroll karo, type karo.
 * User ko Settings > Accessibility me ek baar ON karna hoga —
 * koi app ise khud on nahi kar sakti (Android ka rule).
 */
class LiaAccessibilityService : AccessibilityService() {

    companion object {
        var instance: LiaAccessibilityService? = null
            private set

        fun isEnabled(ctx: Context): Boolean {
            val expected = ComponentName(ctx, LiaAccessibilityService::class.java).flattenToString()
            val enabled = Settings.Secure.getString(
                ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
        }
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Screen par kya-kya dikh raha hai — chhoti unique lines. */
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val lines = LinkedHashSet<String>()
        collect(root, lines)
        return lines.take(40).joinToString("\n")
    }

    private fun collect(n: AccessibilityNodeInfo, out: LinkedHashSet<String>) {
        val t = ((n.text ?: n.contentDescription)?.toString() ?: "").trim()
        if (t.isNotEmpty() && t.length <= 60) {
            val tag = when {
                n.isEditable -> "[input] "
                n.isClickable -> "[tap] "
                else -> "[text] "
            }
            out.add(tag + t)
        }
        for (i in 0 until n.childCount) {
            n.getChild(i)?.let { collect(it, out) }
        }
    }

    /** Text wala element dhoondh ke tap karo. */
    fun tapText(query: String): String {
        val root = rootInActiveWindow ?: return "screen_not_available"
        val node = findText(root, query.lowercase().trim()) ?: return "element_not_found"
        var c: AccessibilityNodeInfo? = node
        while (c != null && !c.isClickable) c = c.parent
        return if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) "tapped" else "tap_failed"
    }

    private fun findText(n: AccessibilityNodeInfo, q: String): AccessibilityNodeInfo? {
        val t = ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).lowercase()
        if (q.isNotEmpty() && q in t) return n
        for (i in 0 until n.childCount) {
            val f = n.getChild(i)?.let { findText(it, q) }
            if (f != null) return f
        }
        return null
    }

    fun typeText(text: String): String {
        val root = rootInActiveWindow ?: return "screen_not_available"
        val input = findEditable(root) ?: return "no_focused_field"
        input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return if (input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "typed" else "type_failed"
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val f = n.getChild(i)?.let { findEditable(it) }
            if (f != null) return f
        }
        return null
    }

    fun scroll(down: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        return scrollNode(root, down)
    }

    private fun scrollNode(n: AccessibilityNodeInfo, down: Boolean): Boolean {
        if (n.isScrollable) {
            val act = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                      else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            if (n.performAction(act)) return true
        }
        for (i in 0 until n.childCount) {
            if (n.getChild(i)?.let { scrollNode(it, down) } == true) return true
        }
        return false
    }

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
}
