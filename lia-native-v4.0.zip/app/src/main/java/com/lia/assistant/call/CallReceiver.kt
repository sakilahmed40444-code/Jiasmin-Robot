package com.lia.assistant.call

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.ContactsContract
import android.telephony.TelephonyManager

/**
 * Incoming call detect — PHONE_STATE broadcast.
 *
 * RINGING → loop chal raha hai (foreground) to voice announce,
 * nahi to notification (background se mic-FGS start = Android 14 crash!).
 */
class CallReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val appCtx = ctx.applicationContext
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                if (number.isNullOrBlank()) return
                val name = lookupName(appCtx, number) ?: number
                val svc = com.lia.assistant.service.VoiceLoopService.instance
                if (svc != null && com.lia.assistant.service.VoiceLoopService.isRunning) {
                    // service already foreground — voice announce safe
                    com.lia.assistant.service.VoiceLoopService.announceCall(appCtx, name, number)
                } else {
                    // background — FGS start karne par SecurityException crash!
                    showCallNotification(appCtx, name, number)
                }
            }
            TelephonyManager.EXTRA_STATE_IDLE,
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                com.lia.assistant.service.VoiceLoopService.cancelCallAnnounce(appCtx)
                cancelCallNotification(appCtx)
            }
        }
    }

    private fun showCallNotification(ctx: Context, name: String, number: String) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = "priya_call"
            nm.createNotificationChannel(
                NotificationChannel(ch, "Incoming Calls", NotificationManager.IMPORTANCE_HIGH))
            val accPi = PendingIntent.getBroadcast(ctx, 11,
                Intent(ctx, CallActionReceiver::class.java).setAction(CallActionReceiver.ACTION_ACCEPT),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val rejPi = PendingIntent.getBroadcast(ctx, 12,
                Intent(ctx, CallActionReceiver::class.java).setAction(CallActionReceiver.ACTION_REJECT),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(ctx, ch)
                .setContentTitle("📞 $name")
                .setContentText("$number — কল আসছে")
                .setSmallIcon(android.R.drawable.sym_def_app_icon)
                .addAction(Notification.Action.Builder(null, "ধরো", accPi).build())
                .addAction(Notification.Action.Builder(null, "কাটো", rejPi).build())
                .setAutoCancel(true)
                .build()
            nm.notify(CALL_NOTIF_ID, n)
        } catch (_: Exception) { }
    }

    private fun cancelCallNotification(ctx: Context) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(CALL_NOTIF_ID)
        } catch (_: Exception) { }
    }

    private fun lookupName(ctx: Context, number: String): String? {
        return try {
            val uri = android.net.Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                android.net.Uri.encode(number))
            ctx.contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    companion object {
        const val CALL_NOTIF_ID = 1001
    }
}
