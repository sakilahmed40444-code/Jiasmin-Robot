package com.lia.assistant.service

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent

/** Pardarshi activity — system speech dialog kholkar result service ko deti hai. */
class SysDialogActivity : Activity() {

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            startActivityForResult(i, 999)
        } catch (_: Exception) {
            done(null)
        }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        var text: String? = null
        if (req == 999 && res == RESULT_OK) {
            text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        }
        done(text)
    }

    private fun done(text: String?) {
        try {
            if (!text.isNullOrBlank()) VoiceLoopService.submitSpeechText(text)
            else VoiceLoopService.instance?.resumeLoop()
        } catch (_: Exception) { }
        finish()
    }
}
