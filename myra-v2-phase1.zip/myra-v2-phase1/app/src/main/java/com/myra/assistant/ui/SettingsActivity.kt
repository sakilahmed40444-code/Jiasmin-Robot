package com.myra.assistant.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.myra.assistant.ai.OpenRouterClient
import com.myra.assistant.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : AppCompatActivity() {
    private lateinit var body: LinearLayout
    private lateinit var key: EditText; private lateinit var name: EditText; private lateinit var custom: EditText
    private lateinit var ttsModel: EditText; private lateinit var ttsVoice: EditText; private lateinit var ttsRate: EditText
    private lateinit var primeBox: LinearLayout; private lateinit var permBox: LinearLayout
    private val presets = listOf("google/gemini-3.8-flash", "google/gemini-3.7-flash", "Custom slug")
    private val levels = listOf("low", "medium", "high")
    private val langs = listOf("AUTO" to "Auto (mirror my language)", "HINGLISH" to "Hinglish", "ENGLISH" to "English", "HINDI" to "Hindi", "BENGALI" to "Bengali (বাংলা)")
    private var preset = 0; private var level = 0; private var lang = 0; private var silence = Prefs.silenceMs

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(44), dp(16), dp(30)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(C.bg); addView(body) })
        build()
    }
    override fun onResume() { super.onResume(); if (::permBox.isInitialized) drawPerms() }

    private fun h(t: String) = body.addView(tv(t, 12f, C.red, true).apply { letterSpacing = 0.15f }, lp(top = 22))
    private fun lp(top: Int = 8) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }
    private fun add(v: View, top: Int = 8) = body.addView(v, lp(top))
    private fun spinner(items: List<String>, sel: Int, on: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, items); setSelection(sel)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, i: Int, id: Long) { on(i) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }
    private fun switch(label: String, v: Boolean, on: (Boolean) -> Unit) = Switch(this).apply {
        text = label; setTextColor(C.text); isChecked = v; setOnCheckedChangeListener { _, c -> on(c) }; setPadding(0, dp(6), 0, dp(6))
    }

    private fun build() {
        body.addView(tv("SETTINGS", 22f, C.text, true))

        h("VOICE ENGINE")
        add(tv("OpenRouter (Gemini 3.8 Flash brain + neural TTS voice)  [Engine A]", 13f, C.hint))
        add(tv("Gemini Live (native audio) = Phase 2", 11f, C.hint), 2)

        h("OPENROUTER API KEY")
        key = edit("sk-or-...", Prefs.apiKey, true); add(key)
        val row = LinearLayout(this)
        row.addView(btn("Get key") { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://openrouter.ai/workspaces/default/keys"))) })
        row.addView(btn("Test") { testKey() }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        add(row)

        h("YOU")
        name = edit("Your name", Prefs.userName); add(name)

        h("BRAIN MODEL")
        preset = presets.indexOf(Prefs.brainModel).let { if (it < 0) 2 else it }
        add(spinner(presets, preset) { preset = it; if (::custom.isInitialized) custom.visibility = if (it == 2) View.VISIBLE else View.GONE })
        custom = edit("any OpenRouter model slug", if (preset == 2) Prefs.brainModel else "").apply { visibility = if (preset == 2) View.VISIBLE else View.GONE }
        add(custom)
        h("THINKING LEVEL")
        level = levels.indexOf(Prefs.thinking).coerceAtLeast(0); add(spinner(levels, level) { level = it })

        h("VOICE (TTS)")
        ttsModel = edit("TTS model slug", Prefs.ttsModel); add(ttsModel)
        add(btn("Load available TTS models") { loadTts() })
        ttsVoice = edit("Voice id (model specific)", Prefs.ttsVoice); add(ttsVoice)
        ttsRate = edit("PCM sample rate (default 24000)", Prefs.ttsRate.toString()); add(ttsRate)
        add(switch("Use phone voice for Hindi/Bengali script", Prefs.fallbackIndic) { Prefs.fallbackIndic = it })

        h("REPLY LANGUAGE")
        lang = langs.indexOfFirst { it.first == Prefs.language }.coerceAtLeast(0); add(spinner(langs.map { it.second }, lang) { lang = it })

        h("PERSONALITY")
        val rg = RadioGroup(this)
        listOf("GF" to "💖 GF Mode", "PRO" to "💼 Professional", "ASSIST" to "🤖 Assistant").forEach { (k, l) ->
            rg.addView(RadioButton(this).apply { id = View.generateViewId(); text = l; setTextColor(C.text); isChecked = Prefs.personality == k; tag = k })
        }
        rg.setOnCheckedChangeListener { g, id -> Prefs.personality = g.findViewById<View>(id).tag as String }
        add(rg)

        h("CONVERSATION")
        add(switch("Allow interruption (barge-in)", Prefs.bargeIn) { Prefs.bargeIn = it })
        val sl = tv("Silence length: ${silence} ms", 13f, C.text)
        add(sl)
        add(SeekBar(this).apply { max = 800; progress = silence - 400; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { silence = 400 + p; sl.text = "Silence length: $silence ms" }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {} }) }, 2)
        add(switch("Confirm sensitive actions (call/SMS/WhatsApp/email)", Prefs.confirm) { Prefs.confirm = it })
        add(switch("Web search", Prefs.webSearch) { Prefs.webSearch = it })
        add(switch("Code mode (high thinking, long output, strict checks)", Prefs.codeMode) { Prefs.codeMode = it })
        add(switch("Memory", Prefs.memoryOn) { Prefs.memoryOn = it })
        add(btn("Clear memory") { Prefs.clearMemory(); Toast.makeText(this, "Memory cleared", Toast.LENGTH_SHORT).show() })

        h("PRIME CONTACTS")
        primeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; add(primeBox); drawPrimes()
        add(btn("＋ ADD PRIME CONTACT") { addPrime() })

        h("PERMISSIONS (tap to open the setting)")
        add(btn("Grant all normal permissions") { val m = Perms.missing(this); if (m.isEmpty()) toast("All granted") else requestPermissions(m, 1) })
        permBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; add(permBox); drawPerms()

        add(btn("SAVE") { save() }.apply { textSize = 16f }, 28)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun save() {
        Prefs.apiKey = key.text.toString(); Prefs.userName = name.text.toString().trim()
        Prefs.brainModel = if (preset == 2) custom.text.toString().trim().ifBlank { presets[0] } else presets[preset]
        Prefs.thinking = levels[level]; Prefs.language = langs[lang].first
        Prefs.ttsModel = ttsModel.text.toString().trim(); Prefs.ttsVoice = ttsVoice.text.toString().trim()
        Prefs.ttsRate = ttsRate.text.toString().toIntOrNull()?.takeIf { it in 8000..48000 } ?: 24000
        Prefs.silenceMs = silence
        toast("Saved. Back jaoa — notun settings sathe sathe kaj korbe."); finish()
    }

    private fun testKey() {
        Prefs.apiKey = key.text.toString()
        if (preset != 2) Prefs.brainModel = presets[preset] else Prefs.brainModel = custom.text.toString().trim().ifBlank { presets[0] }
        lifecycleScope.launch { val r = withContext(Dispatchers.IO) { OpenRouterClient().test() }; toast(if (r == null) "✅ Key OK" else "❌ $r") }
    }

    private fun loadTts() {
        Prefs.apiKey = key.text.toString()
        lifecycleScope.launch {
            val l = withContext(Dispatchers.IO) { OpenRouterClient().listTtsModels() }
            if (l.isEmpty()) toast("Could not load list") else AlertDialog.Builder(this@SettingsActivity).setTitle("TTS models")
                .setItems(l.toTypedArray()) { _, i -> ttsModel.setText(l[i]) }.show()
        }
    }

    private fun drawPrimes() {
        primeBox.removeAllViews()
        Prefs.primes().forEachIndexed { i, (n, num) ->
            val r = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL; background = round(0xFF1A0000.toInt(), 12, C.red); setPadding(dp(12), dp(8), dp(12), dp(8)) }
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            c.addView(tv("⭐ $n", 14f, C.text, true)); c.addView(tv(num, 12f, C.hint))
            r.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(tv("✕", 18f, C.red).apply { setPadding(dp(10), 0, dp(4), 0); setOnClickListener { Prefs.savePrimes(Prefs.primes().filterIndexed { k, _ -> k != i }); drawPrimes() } })
            primeBox.addView(r, lp(6))
        }
    }

    private fun addPrime() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val n = edit("Name"); val num = edit("Number (+91...)"); box.addView(n); box.addView(num, lp())
        AlertDialog.Builder(this).setTitle("Add prime contact").setView(box).setPositiveButton("Add") { _, _ ->
            if (n.text.isNotBlank() && num.text.isNotBlank()) { Prefs.savePrimes(Prefs.primes() + (n.text.toString().trim() to num.text.toString().trim())); drawPrimes() }
        }.setNegativeButton("Cancel", null).show()
    }

    private fun drawPerms() {
        permBox.removeAllViews()
        Perms.special.forEach { p ->
            val ok = p.granted(this)
            permBox.addView(tv("${if (ok) "✅" else "❌"}  ${p.label}", 14f, if (ok) C.ok else C.text).apply {
                setPadding(dp(12), dp(12), dp(12), dp(12)); background = round(C.card, 12)
                setOnClickListener { try { startActivity(p.intent(this@SettingsActivity)) } catch (e: Exception) { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) } }
            }, lp(6))
        }
        val m = Perms.missing(this)
        permBox.addView(tv(if (m.isEmpty()) "✅  Runtime permissions: all granted" else "❌  Runtime permissions missing: ${m.size} (tap button above)", 13f, if (m.isEmpty()) C.ok else C.text), lp(10))
    }
}
