package com.lia.assistant.action

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import com.lia.assistant.brain.Action
import com.lia.assistant.brain.CommandParser
import com.lia.assistant.brain.OfflineBrain
import com.lia.assistant.data.MemStore
import com.lia.assistant.service.LiaAccessibilityService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Action → asli kaam. Result: Lia kya bole. */
class ActionExecutor(private val ctx: Context) {

    interface ForgeOpener { fun openForge(subject: String); fun showSites() }
    var forgeOpener: ForgeOpener? = null

    // package + aliases (label match ke liye)
    private val APPS = mapOf(
        "com.google.android.youtube" to listOf("youtube", "yt"),
        "com.whatsapp" to listOf("whatsapp", "watsapp"),
        "com.facebook.katana" to listOf("facebook", "fb"),
        "com.instagram.android" to listOf("instagram", "insta"),
        "com.android.chrome" to listOf("chrome", "browser"),
        "com.google.android.gm" to listOf("gmail", "mail"),
        "com.google.android.apps.maps" to listOf("maps", "map", "navigation"),
        "com.google.android.apps.photos" to listOf("photos", "gallery"),
        "com.google.android.apps.messaging" to listOf("messages", "sms"),
        "com.android.settings" to listOf("settings", "setting"),
        "com.android.vending" to listOf("play store", "playstore"),
        "com.spotify.music" to listOf("spotify"),
        "com.google.android.apps.youtube.music" to listOf("youtube music", "music"),
        "com.google.android.calendar" to listOf("calendar"),
        "com.google.android.deskclock" to listOf("clock", "alarm", "ghadi"),
        "org.telegram.messenger" to listOf("telegram"),
        "com.twitter.android" to listOf("twitter", "x"),
        "com.netflix.mediaclient" to listOf("netflix"),
        "in.startv.hotstar" to listOf("hotstar"),
        "in.swiggy.android" to listOf("swiggy"),
        "com.application.zomato" to listOf("zomato"),
        "in.amazon.m2" to listOf("amazon"),
        "com.flipkart.android" to listOf("flipkart"),
        "net.one97.paytm" to listOf("paytm"),
        "com.phonepe.app" to listOf("phonepe"),
        "com.google.android.apps.nbu.paisa.user" to listOf("google pay", "gpay")
    )

    fun findAppPackage(query: String): String? {
        val q = query.lowercase().trim()
        if (q.length < 2) return null
        for ((pkg, aliases) in APPS) {
            for (a in aliases) {
                if (a == q || (a.length >= 3 && (a.startsWith(q) || q.startsWith(a)))) return pkg
            }
        }
        // har word prefix-match
        val qw = q.split(" ")
        for ((pkg, aliases) in APPS) {
            val aws = aliases.joinToString(" ").split(" ")
            if (qw.all { w -> aws.any { a -> a.startsWith(w) || w.startsWith(a) } }) return pkg
        }
        // phone me installed apps ke naam se milao — koi bhi app khul jayegi
        return resolveViaPackageManager(q)
    }

    /** Launcher apps ke labels se best match dhoondho (YouTube, Facebook, Ludo King...). */
    private fun resolveViaPackageManager(q: String): String? {
        return try {
            val pm = ctx.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(intent, 0)
            var best: String? = null
            var bestScore = -1
            for (ri in apps) {
                val label = try { ri.loadLabel(pm)?.toString()?.lowercase()?.trim() } catch (_: Exception) { null }
                    ?: continue
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg == ctx.packageName) continue
                val score = when {
                    label == q -> 100
                    label.replace(" ", "") == q.replace(" ", "") -> 90
                    label.startsWith(q) -> 80
                    q.startsWith(label) && label.length >= 3 -> 70
                    label.contains(q) -> 50
                    q.split(" ").filter { it.length >= 3 }.all { label.contains(it) } -> 40
                    else -> -1
                }
                if (score > bestScore) { bestScore = score; best = pkg }
            }
            best
        } catch (_: Exception) { null }
    }

    /** Naam se contact ka number dhoondho (fuzzy, manusher moto). */
    private fun lookupContact(name: String): String? {
        return try {
            val q = name.lowercase().trim()
            if (q.length < 2) return null
            val uri = android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val cur = ctx.contentResolver.query(
                uri,
                arrayOf(
                    android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER
                ), null, null, null
            )
            var best: String? = null
            var bestScore = -1
            cur?.use {
                val nI = it.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val pI = it.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (it.moveToNext()) {
                    val dn = it.getString(nI)?.lowercase()?.trim() ?: continue
                    val score = when {
                        dn == q -> 100
                        dn.startsWith(q) -> 80
                        dn.contains(q) -> 60
                        q.split(" ").filter { w -> w.length >= 3 }.all { w -> dn.contains(w) } -> 50
                        else -> -1
                    }
                    if (score > bestScore) { bestScore = score; best = it.getString(pI) }
                }
            }
            best?.filter { c -> c.isDigit() || c == '+' }?.takeIf { it.filter { c -> c.isDigit() }.length >= 5 }
        } catch (_: Exception) { null }
    }

    /** Returns: (spokenReply, wasHandled) */
    fun execute(a: Action, name: String): Pair<String, Boolean> {
        return when (a) {
            is Action.OpenApp -> {
                val pkg = findAppPackage(a.appName)
                if (pkg != null) {
                    val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
                    if (i != null) {
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        try { ctx.startActivity(i); "\"${a.appName}\" khol diya, $name. ✨" to true }
                        catch (e: Exception) { "App kholne me dikkat aayi $name." to true }
                    } else "Ye app install nahi lag rahi $name." to true
                } else "Ye app nahi mili $name — naam thoda saaf bolo?" to true
            }
            is Action.Call -> {
                var digits = a.target.filter { it.isDigit() || it == '+' }
                // "শূন্য এক সাত..." → digits
                if (digits.filter { it.isDigit() }.length < 5) {
                    val w = CommandParser.wordsToDigits(a.target.lowercase())
                    if (w.filter { it.isDigit() }.length >= 5) digits = w
                }
                if (digits.filter { it.isDigit() }.length >= 5) {
                    try {
                        val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:$digits")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        ctx.startActivity(i); "Call laga rahi hoon, $name. 📞" to true
                    } catch (e: SecurityException) {
                        val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        ctx.startActivity(i); "Dialer khol diya — call dabana bas." to true
                    }
                } else if (a.target.isNotBlank()) {
                    // naam se number dhoondho (contacts)
                    val num = lookupContact(a.target)
                    if (num != null) {
                        try {
                            val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            ctx.startActivity(i); "\"${a.target}\" ko call laga rahi hoon, $name. 📞" to true
                        } catch (e: SecurityException) {
                            val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            ctx.startActivity(i); "Dialer khol diya — call dabana bas." to true
                        }
                    } else {
                        val i = Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        try { ctx.startActivity(i) } catch (_: Exception) { }
                        "\"${a.target}\" ka number contacts me nahi mila $name — dialer khol diya." to true
                    }
                } else {
                    val i = Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    ctx.startActivity(i); "Kisko call karun $name? Naam ya number bolo." to true
                }
            }
            Action.EndCall -> {
                val svc = LiaAccessibilityService.instance
                if (svc == null) "Pehle Accessibility on karo $name, tabhi main call kaat paungi. ♿" to true
                else {
                    val r = svc.tapText("End call").takeIf { it == "tapped" }
                        ?: svc.tapText("end").takeIf { it == "tapped" }
                        ?: svc.tapText("Decline").takeIf { it == "tapped" }
                    if (r == "tapped") "Call kaat diya. 📴" to true
                    else "End call button nahi mila $name — screen par call screen khuli honi chahiye." to true
                }
            }
            is Action.YtSearch -> {
                val q = Uri.encode(a.query)
                val url = "https://www.youtube.com/results?search_query=$q"
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val yt = findAppPackage("youtube")
                if (yt != null) i.setPackage(yt)
                try {
                    ctx.startActivity(i)
                    "\"${a.query}\" YouTube par dhoondh rahi hoon — jo pasand aaye use kholo. 🎵" to true
                } catch (_: Exception) { "YouTube nahi khul paya $name." to true }
            }
            is Action.FbPost -> {
                if (a.text.isBlank()) {
                    val pkg = findAppPackage("facebook")
                    if (pkg != null) {
                        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        if (i != null) { try { ctx.startActivity(i); "Facebook khol diya. 📘" to true }
                        catch (_: Exception) { "Facebook nahi khul paya." to true } }
                        else "Facebook install nahi lag rahi." to true
                    } else "Facebook nahi mili $name." to true
                } else {
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, a.text).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        ctx.startActivity(Intent.createChooser(i, "Post karo").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        "Post taiyaar hai — Facebook chuno aur Share dabao. 📝" to true
                    } catch (_: Exception) { "Share nahi ho paya $name." to true }
                }
            }
            is Action.Message -> {
                if (a.app == "whatsapp") {
                    val txt = Uri.encode(a.msg)
                    val waInstalled = try { ctx.packageManager.getPackageInfo("com.whatsapp", 0); true } catch (e: Exception) { false }
                    val url = "https://wa.me/?text=$txt"
                    val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    if (waInstalled) i.setPackage("com.whatsapp")
                    ctx.startActivity(i)
                    "WhatsApp khol diya${if (a.to.isNotBlank()) " — ${a.to} ke liye" else ""}. Message taiyaar hai, bas Send dabana. 💬" to true
                } else {
                    val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    i.putExtra("sms_body", a.msg)
                    ctx.startActivity(i)
                    "SMS composer khol diya. Message likha hai — Send tum dabana. 💬" to true
                }
            }
            is Action.Forge -> { forgeOpener?.openForge(a.subject); "Forge khol rahi hoon, $name! Dekho, tumhari website banti hai. 🔥" to true }
            Action.ShowCoding -> { forgeOpener?.showSites(); "Tumhari coding dikhati hoon. 💻" to true }
            Action.ChromeForge -> {
                try {
                    val i = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    val chrome = findAppPackage("chrome")
                    if (chrome != null) i.setPackage(chrome)
                    ctx.startActivity(i)
                } catch (_: Exception) { }
                forgeOpener?.openForge("tumhara business")
                "Chrome khol diya aur Forge me website bana rahi hoon! 🔥" to true
            }
            is Action.Tap -> {
                val svc = LiaAccessibilityService.instance
                if (svc == null) "Pehle Setup me Accessibility on karo $name, tabhi main screen par tap kar paungi. ♿" to true
                else when (svc.tapText(a.target)) {
                    "tapped" -> "\"${a.target}\" daba diya. ✅" to true
                    "element_not_found" -> "\"${a.target}\" screen par nahi mila $name." to true
                    else -> "Tap nahi ho paya $name." to true
                }
            }
            is Action.Scroll -> {
                val svc = LiaAccessibilityService.instance
                if (svc == null) "Pehle Setup me Accessibility on karo $name. ♿" to true
                else if (svc.scroll(a.down)) (if (a.down) "Neeche scroll kar diya. ⬇️" else "Upar scroll kar diya. ⬆️") to true
                else "Scroll nahi ho paya — shayad aur scroll nahi hai." to true
            }
            is Action.Type -> {
                val svc = LiaAccessibilityService.instance
                if (svc == null) "Pehle Setup me Accessibility on karo $name. ♿" to true
                else when (svc.typeText(a.text)) {
                    "typed" -> "Likh diya: \"${a.text}\". ⌨️" to true
                    else -> "Type nahi ho paya — pehle kisi input box par tap karo." to true
                }
            }
            Action.ReadScreen -> {
                // Screen Capture ON ho to aankhon se dekho, warna accessibility text
                val prefs = com.lia.assistant.data.Prefs(ctx)
                if (com.lia.assistant.vision.ScreenVision.hasGrant(prefs)) {
                    val desc = com.lia.assistant.vision.ScreenVision.describeSync(ctx, prefs)
                    if (desc.isNotBlank()) "Screen par ye dekh rahi hoon $name: $desc 👀" to true
                    else "Screen capture to hai par dekh nahi payi $name — API key check karo." to true
                } else {
                    val svc = LiaAccessibilityService.instance
                    if (svc == null) "Pehle Setup me Accessibility on karo $name, tabhi main screen dekh paungi. ♿" to true
                    else {
                        val r = svc.readScreen()
                        if (r.isBlank() || r == "screen_empty") "Screen par kuch khaas nahi dikh raha $name." to true
                        else "Screen par ye dikh raha hai $name: $r" to true
                    }
                }
            }
            Action.GoBack -> {
                val svc = LiaAccessibilityService.instance
                if (svc == null) "Accessibility off hai $name." to true
                else { svc.goBack(); "Peeche chali gayi. ↩️" to true }
            }
            Action.GoHome -> {
                val svc = LiaAccessibilityService.instance
                if (svc == null) "Accessibility off hai $name." to true
                else { svc.goHome(); "Home par aa gayi. 🏠" to true }
            }
            Action.Time -> OfflineBrain.reply("time kya hai", "hing", name) to true
            Action.Date -> OfflineBrain.reply("aaj ki date", "hing", name) to true
            Action.Joke -> OfflineBrain.reply("joke sunao", "hing", name) to true
            Action.Help -> OfflineBrain.reply("help", "hing", name) to true
            Action.Greet -> OfflineBrain.reply("namaste", "hing", name) to true
            Action.MyName -> OfflineBrain.reply("tumhara naam", "hing", name) to true
            Action.Thanks -> OfflineBrain.reply("shukriya", "hing", name) to true
            Action.Bye -> OfflineBrain.reply("bye", "hing", name) to true
            is Action.Honest -> a.reply to true
            is Action.PythonCode -> "Python code likh rahi hoon… 💻" to true
            is Action.Remember -> {
                MemStore.add(ctx, a.text)
                "Yaad rakh liya, $name. ✅" to true
            }
        }
    }

    fun openAppSettings() {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }
}
