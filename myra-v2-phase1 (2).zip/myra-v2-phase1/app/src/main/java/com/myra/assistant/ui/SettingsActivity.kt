package com.myra.assistant.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.myra.assistant.ai.BrainClient
import com.myra.assistant.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * MYRA v2.1 settings — easy sections:
 * 1. API keys (Gemini + OpenRouter, visible, only change when YOU tap Save)
 * 2. Brain  3. Voice  4. Personality  5. Language  6. Permissions  7. My Memory  8. Prime contacts
 */
class SettingsActivity : AppCompatActivity() {
    private lateinit var body: LinearLayout
    private lateinit var gemKey: EditText
    private lateinit var orKey: EditText
    private lateinit var name: EditText
    private lateinit var gemModel: EditText
    private lateinit var custom: EditText
    private lateinit var primeBox: LinearLayout
    private lateinit var permBox: LinearLayout

    private val brainProviders = listOf("AUTO" to "✨ Auto (jeta key ache, setai cholbe)", "GEMINI" to "🔷 Gemini key diye", "OPENROUTER" to "🟣 OpenRouter key diye")
    private val orPresets = listOf("google/gemini-3.8-flash", "google/gemini-3.7-flash", "Custom slug")
    // One voice list for BOTH keys — Gemini key or OpenRouter key, same voices.
    private val voices = listOf("Kore","Aoede","Puck","Charon","Fenrir","Zephyr","Leda","Orus","Callirrhoe","Autonoe","Enceladus","Iapetus","Umbriel","Algieba","Despina","Erinome","Algenib","Rasalgethi","Laomedeia","Alnilam","Schedar","Gacrux","Pulcherrima","Achird","Zubenelgenubi","Vindemiatrix","Sadachbia","Sadaltager","Sulafat")
    private val levels = listOf("low", "medium", "high")
    private val langs = listOf("AUTO" to "Auto (amar vasha mirror koro)", "BENGALI" to "Bengali (বাংলা)", "HINGLISH" to "Hinglish", "HINDI" to "Hindi", "ENGLISH" to "English")
    private val personas = listOf("GF" to "💖 GirlFriend", "ASSIST" to "🤖 Assistant", "PRO" to "💼 Professional", "TEACHER" to "📚 Teacher", "BOSS" to "💪 Boss", "FUNNY" to "😂 Funny")

    private var brainProv = 0; private var preset = 0; private var level = 0
    private var lang = 0; private var voiceIdx = 0; private var silence = Prefs.silenceMs

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(44), dp(16), dp(30)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(C.bg); addView(body) })
        build()
    }
    override fun onResume() { super.onResume(); if (::permBox.isInitialized) drawPerms() }

    private fun h(t: String) = body.addView(tv(t, 13f, C.red, true).apply { letterSpacing = 0.12f }, lp(top = 24))
    private fun note(t: String) = body.addView(tv(t, 11.5f, C.hint), lp(top = 4))
    private fun lp(top: Int = 8) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }
    private fun add(v: View, top: Int = 8) = body.addView(v, lp(top))
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun spinner(items: List<String>, sel: Int, on: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, items); setSelection(sel)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, i: Int, id: Long) { on(i) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }
    private fun switch(label: String, v: Boolean, on: (Boolean) -> Unit) = Switch(this).apply {
        text = label; setTextColor(C.text); isChecked = v; setOnCheckedChangeListener { _, c -> on(c) }; setPadding(0, dp(6), 0, dp(6))
    }

    private fun build() {
        body.addView(tv("⚙️ SETTINGS", 22f, C.text, true))

        // ---------- 1. API KEYS ----------
        h("1️⃣ API KEY — GEMINI (Google)")
        gemKey = edit("AIza...  (key dekha jabe)", Prefs.geminiKey); add(gemKey)
        val gr = LinearLayout(this)
        gr.addView(btn("🔑 Get key") { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey"))) })
        gr.addView(btn("Test") { testGemini() }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        add(gr)

        h("1️⃣ API KEY — OPENROUTER")
        orKey = edit("sk-or-...  (key dekha jabe)", Prefs.apiKey); add(orKey)
        val or = LinearLayout(this)
        or.addView(btn("🔑 Get key") { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://openrouter.ai/workspaces/default/keys"))) })
        or.addView(btn("Test") { testOpenRouter() }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        add(or)
        note("👆 Key shudhu tumi SAVE chaple save/change hobe. App nije theke kokhono key paltabe na.")

        h("2️⃣ BRAIN (buddhi kontar cholbe)")
        brainProv = brainProviders.indexOfFirst { it.first == Prefs.brainProvider }.coerceAtLeast(0)
        add(spinner(brainProviders.map { it.second }, brainProv) { brainProv = it })
        add(tv("Gemini model:", 12f, C.hint), 4)
        gemModel = edit("gemini-2.5-flash", Prefs.geminiModel); add(gemModel, 2)
        add(tv("OpenRouter model:", 12f, C.hint), 4)
        preset = orPresets.indexOf(Prefs.brainModel).let { if (it < 0) 2 else it }
        add(spinner(orPresets, preset) { preset = it; if (::custom.isInitialized) custom.visibility = if (it == 2) View.VISIBLE else View.GONE }, 2)
        custom = edit("OpenRouter model slug", if (preset == 2) Prefs.brainModel else "").apply { visibility = if (preset == 2) View.VISIBLE else View.GONE }
        add(custom, 2)
        add(tv("Thinking level:", 12f, C.hint), 4)
        level = levels.indexOf(Prefs.thinking).coerceAtLeast(0); add(spinner(levels, level) { level = it }, 2)

        // ---------- 3. VOICE (one list, both keys) ----------
        h("3️⃣ VOICE (golar awaz)")
        note("Ekta voice select koro — Gemini key ba OpenRouter key, jekono ta diye same voice cholbe.")
        voiceIdx = voices.indexOf(Prefs.voice).coerceAtLeast(0)
        add(spinner(voices, voiceIdx) { voiceIdx = it })
        add(switch("Bangla/Hindi lekha phone voice e bolo", Prefs.fallbackIndic) { Prefs.fallbackIndic = it })

        h("4️⃣ TOMAR NAAM")
        name = edit("Tomar naam", Prefs.userName); add(name)

        // ---------- 5. PERSONALITY ----------
        h("5️⃣ PERSONALITY (mood / character)")
        val rg = RadioGroup(this)
        personas.forEach { (k, l) ->
            rg.addView(RadioButton(this).apply { id = View.generateViewId(); text = l; setTextColor(C.text); isChecked = Prefs.personality == k; tag = k })
        }
        rg.setOnCheckedChangeListener { g, id -> Prefs.personality = g.findViewById<View>(id).tag as String }
        add(rg)

        h("6️⃣ REPLY LANGUAGE")
        lang = langs.indexOfFirst { it.first == Prefs.language }.coerceAtLeast(0); add(spinner(langs.map { it.second }, lang) { lang = it })

        // ---------- 7. PERMISSIONS ----------
        h("7️⃣ PERMISSIONS (ja dorkar diye dao)")
        add(btn("✨ Sob normal permission ekbare dao") {
            val m = Perms.missing(this); if (m.isEmpty()) toast("✅ Sob permission deoa ache") else requestPermissions(m, 1)
        })
        permBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; add(permBox); drawPerms()

        // ---------- 8. MY MEMORY ----------
        h("8️⃣ MY MEMORY")
        add(switch("Memory ON (kotha mone rakhbe)", Prefs.memoryOn) { Prefs.memoryOn = it })
        add(btn("💾 My Memory dekho / save koro") { showMemoryDialog() })
        note("Voice e bolo “mone rakho …” — MYRA mone rakhbe.")

        // ---------- 9. PRIME CONTACTS ----------
        h("9️⃣ PRIME CONTACTS")
        primeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; add(primeBox); drawPrimes()
        add(btn("＋ ADD PRIME CONTACT") { addPrime() })

        // ---------- 10. OTHERS ----------
        h("🔟 OTHERS")
        add(switch("Kothar majhe thamano jabe (barge-in)", Prefs.bargeIn) { Prefs.bargeIn = it })
        val sl = tv("Chup thakar somoy: ${silence} ms", 13f, C.text)
        add(sl)
        add(SeekBar(this).apply { max = 800; progress = (silence - 400).coerceIn(0, 800); setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { silence = 400 + p; sl.text = "Chup thakar somoy: $silence ms" }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {} }) }, 2)
        add(switch("Call/SMS er age confirm koro", Prefs.confirm) { Prefs.confirm = it })
        add(switch("Web search", Prefs.webSearch) { Prefs.webSearch = it })
        add(switch("Code mode", Prefs.codeMode) { Prefs.codeMode = it })

        add(btn("💾 SAVE") { save() }.apply { textSize = 17f; setPadding(dp(14), dp(12), dp(14), dp(12)) }, 28)
        note("SAVE na chaple kichui change hobe na 🙂")
    }

    private fun save() {
        // Keys: ONLY written here (or Test) — never auto-changed.
        Prefs.geminiKey = gemKey.text.toString()
        Prefs.apiKey = orKey.text.toString()
        Prefs.brainProvider = brainProviders[brainProv].first
        Prefs.geminiModel = gemModel.text.toString().trim().ifBlank { "gemini-2.5-flash" }
        Prefs.voice = voices[voiceIdx]
        Prefs.brainModel = if (preset == 2) custom.text.toString().trim().ifBlank { orPresets[0] } else orPresets[preset]
        Prefs.thinking = levels[level]; Prefs.language = langs[lang].first
        Prefs.userName = name.text.toString().trim()
        Prefs.silenceMs = silence
        toast("✅ Saved! Back jao — notun settings ekhoni kaj korbe.")
        finish()
    }

    private fun testGemini() {
        val k = gemKey.text.toString().trim()
        if (k.isBlank()) { toast("Age key boshao"); return }
        val m = gemModel.text.toString().trim().ifBlank { "gemini-2.5-flash" }
        lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) { BrainClient(BrainClient.GEM_BASE, k, m, false).test() }
            toast(if (r == null) "✅ Gemini key OK ($m)" else "❌ $r")
        }
    }

    private fun testOpenRouter() {
        val k = orKey.text.toString().trim()
        if (k.isBlank()) { toast("Age key boshao"); return }
        val m = if (preset == 2) custom.text.toString().trim().ifBlank { orPresets[0] } else orPresets[preset]
        lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) { BrainClient(BrainClient.OR_BASE, k, m, true).test() }
            toast(if (r == null) "✅ OpenRouter key OK" else "❌ $r")
        }
    }

    // ---------------- My Memory ----------------
    private fun showMemoryDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(4)) }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list); layoutParams = LinearLayout.LayoutParams(-1, dp(260)) }
        box.addView(scroll)
        fun refresh() {
            list.removeAllViews()
            val mem = Prefs.memoryAll()
            if (mem.isEmpty()) list.addView(tv("(ekhono kichu mone rakha hoy nai)", 13f, C.hint).apply { setPadding(0, dp(8), 0, dp(8)) })
            mem.forEach { (k, v) ->
                val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
                r.addView(tv("🧠 $k: $v", 13f, C.text).apply { setPadding(0, 0, dp(8), 0) }, LinearLayout.LayoutParams(0, -2, 1f))
                r.addView(tv("🗑", 16f, C.red).apply { setPadding(dp(8), dp(4), dp(8), dp(4)); setOnClickListener { Prefs.forget(k); refresh() } })
                list.addView(r)
            }
        }
        refresh()
        val kIn = edit("notun kotha (jemon: amar priyo khabar)"); val vIn = edit("mone rakhar jinish")
        box.addView(kIn, lp(8)); box.addView(vIn, lp(6))
        val btnRow = LinearLayout(this)
        btnRow.addView(btn("＋ Mone rakho") {
            if (kIn.text.isNotBlank() && vIn.text.isNotBlank()) {
                Prefs.remember(kIn.text.toString().trim(), vIn.text.toString().trim())
                kIn.setText(""); vIn.setText(""); refresh(); toast("✅ Mone rakhlam")
            }
        })
        btnRow.addView(btn("🧹 Sob mucho") { Prefs.clearMemory(); refresh() }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        box.addView(btnRow, lp(8))
        AlertDialog.Builder(this).setTitle("💾 My Memory").setView(box).setPositiveButton("Done", null).show()
    }

    // ---------------- Prime contacts ----------------
    private fun drawPrimes() {
        primeBox.removeAllViews()
        Prefs.primes().forEachIndexed { i, (n, num) ->
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; background = round(0xFF1A0000.toInt(), 12, C.red); setPadding(dp(12), dp(8), dp(12), dp(8)) }
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            c.addView(tv("⭐ $n", 14f, C.text, true)); c.addView(tv(num, 12f, C.hint))
            r.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(tv("✕", 18f, C.red).apply { setPadding(dp(10), 0, dp(4), 0); setOnClickListener { Prefs.savePrimes(Prefs.primes().filterIndexed { k, _ -> k != i }); drawPrimes() } })
            primeBox.addView(r, lp(6))
        }
    }

    private fun addPrime() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val n = edit("Name"); val num = edit("Number (+880...)"); box.addView(n); box.addView(num, lp())
        AlertDialog.Builder(this).setTitle("Add prime contact").setView(box).setPositiveButton("Add") { _, _ ->
            if (n.text.isNotBlank() && num.text.isNotBlank()) { Prefs.savePrimes(Prefs.primes() + (n.text.toString().trim() to num.text.toString().trim())); drawPrimes() }
        }.setNegativeButton("Cancel", null).show()
    }

    // ---------------- Permissions: colorful serial buttons ----------------
    private val permColors = listOf(0xFF6A1B9A.toInt(), 0xFF1565C0.toInt(), 0xFF00838F.toInt(), 0xFFE65100.toInt(), 0xFFAD1457.toInt(), 0xFF2E7D32.toInt())
    private fun drawPerms() {
        permBox.removeAllViews()
        Perms.special.forEachIndexed { i, p ->
            val ok = p.granted(this)
            val bg = if (ok) 0xFF1B5E20.toInt() else permColors[i % permColors.size]
            permBox.addView(tv("${if (ok) "✅" else "❌"}  ${p.label}", 14f, 0xFFFFFFFF.toInt(), true).apply {
                setPadding(dp(14), dp(13), dp(14), dp(13)); background = round(bg, 14); gravity = Gravity.CENTER_VERTICAL
                setOnClickListener { try { startActivity(p.intent(this@SettingsActivity)) } catch (e: Exception) { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) } }
            }, lp(6))
        }
        val m = Perms.missing(this)
        permBox.addView(tv(
            if (m.isEmpty()) "✅ Runtime permissions: sob deoa ache" else "❌ Runtime permission baki: ${m.size} ta (uporer button e tap koro)",
            13f, if (m.isEmpty()) C.ok else C.text), lp(10))
    }
}
