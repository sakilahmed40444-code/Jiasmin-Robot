package com.lia.assistant.forge

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * Gemini se website stream karo (SSE) — stages asli stream se nikalte hain,
 * timer se nahi. Guide spec step 14.
 */
class ForgeManager(private val apiKey: String, private val model: String) {

    interface Listener {
        fun onStage(i: Int)          // 0..5
        fun onProgress(pct: Int, kb: Double, sections: Int, tps: Double, secs: Int)
        fun onLog(line: String)
        fun onDone(html: String)
        fun onError(msg: String)
    }

    @Volatile private var cancelled = false
    private var thread: Thread? = null

    fun cancel() { cancelled = true; thread?.interrupt() }

    fun start(subject: String, editOf: String?, change: String?, l: Listener) {
        cancelled = false
        thread = Thread {
            try {
                val sys = FORGE_SYS + if (editOf != null)
                    "\nEDIT MODE: you get the current full HTML. Apply the requested change and return the COMPLETE updated HTML only, no fences."
                    else ""
                val user = if (editOf != null)
                    "Current HTML:\n${editOf.take(50000)}\n\nRequested change: $change"
                    else
                    "Build a stunning animated single-file website for: $subject."
                val html = stream(sys, user, l)
                if (cancelled) return@Thread
                var out = html.replace("```html", "").replace("```", "").trim()
                if (out.length < 1500) throw Exception("Output bahut chhota aaya")
                if (!out.contains("</html>", true)) out += "\n</body></html>"
                out = withSafetyNet(out)
                l.onStage(6)
                l.onProgress(100, out.length / 1024.0, countSections(out), 0.0, 0)
                l.onDone(out)
            } catch (e: InterruptedException) {
                // cancel — chup
            } catch (e: Exception) {
                if (!cancelled) l.onError(e.message ?: "stream fail")
            }
        }
        thread?.start()
    }

    @Throws(Exception::class)
    private fun stream(sys: String, user: String, l: Listener): String {
        val models = (listOf(model) + listOf("gemini-2.0-flash", "gemini-1.5-flash").filter { it != model }).distinct()
        var lastErr = "stream fail"
        for (m in models) {
            if (cancelled) throw InterruptedException()
            try {
                return streamOnce(m, sys, user, l)
            } catch (e: InterruptedException) { throw e }
            catch (e: Exception) {
                lastErr = e.message ?: "stream fail"
                if (lastErr.contains("503") || lastErr.contains("overloaded", true)) {
                    l.onLog("Gemini busy hai… 4s me retry")
                    try { Thread.sleep(4000) } catch (_: InterruptedException) { throw InterruptedException() }
                    try { return streamOnce(m, sys, user, l) } catch (e2: Exception) { lastErr = e2.message ?: lastErr }
                }
            }
        }
        throw Exception(lastErr)
    }

    @Throws(Exception::class)
    private fun streamOnce(model: String, sys: String, user: String, l: Listener): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", apiKey)
            c.doOutput = true
            c.connectTimeout = 25000
            c.readTimeout = 180000
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", sys))))
                .put("contents", org.json.JSONArray().put(
                    JSONObject().put("role", "user").put("parts", org.json.JSONArray().put(JSONObject().put("text", user)))))
                .put("generationConfig", JSONObject().put("temperature", 0.8).put("maxOutputTokens", 16000))
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (c.responseCode !in 200..299) {
                val err = c.errorStream?.bufferedReader()?.readText() ?: ""
                throw Exception("HTTP ${c.responseCode} ${JSONObject(err).optJSONObject("error")?.optString("message") ?: ""}".trim())
            }
            val sb = StringBuilder()
            val t0 = System.currentTimeMillis()
            var stage = 0
            var lastEmit = 0L
            var lastLen = 0
            l.onStage(0); l.onLog("Forge reactor charge ho raha hai…")
            BufferedReader(InputStreamReader(c.inputStream)).use { r ->
                var line: String?
                while (r.readLine().also { line = it } != null) {
                    if (cancelled || Thread.currentThread().isInterrupted) throw InterruptedException()
                    val ln = line!!.trim()
                    if (!ln.startsWith("data:")) continue
                    val data = ln.removePrefix("data:").trim()
                    if (data == "[DONE]") continue
                    try {
                        val j = JSONObject(data)
                        if (j.has("error")) throw Exception(j.getJSONObject("error").optString("message", "stream error"))
                        val parts = j.optJSONArray("candidates")?.optJSONObject(0)
                            ?.optJSONObject("content")?.optJSONArray("parts") ?: continue
                        for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text", "") ?: "")
                    } catch (e: InterruptedException) { throw e }
                    catch (_: Exception) { /* adhura chunk — ignore */ }
                    val now = System.currentTimeMillis()
                    if (now - lastEmit > 150) {
                        lastEmit = now
                        val ns = stageOf(sb)
                        if (ns > stage) {
                            stage = ns; l.onStage(stage)
                            l.onLog(STAGE_LABELS[stage] + "…")
                        }
                        val secs = ((now - t0) / 1000).toInt().coerceAtLeast(1)
                        val tps = (sb.length - lastLen) / 0.15 / 4.0
                        lastLen = sb.length
                        val pct = maxOf((stage * 100 / 6), (sb.length * 100 / 60000)).coerceAtMost(98)
                        l.onProgress(pct, sb.length / 1024.0, countSections(sb), tps, secs)
                    }
                }
            }
            return sb.toString()
        } finally {
            c.disconnect()
        }
    }

    companion object {
        val STAGE_LABELS = listOf(
            "Apna idea padh rahi hoon", "Structure bicha rahi hoon",
            "Sections ko style de rahi hoon", "3D visuals bana rahi hoon",
            "Motion inject kar rahi hoon", "Final touch de rahi hoon", "Taiyaar! 🎉"
        )

        fun stageOf(sb: CharSequence): Int {
            val h = sb.toString().lowercase()
            if ("</html>" in h) return 5
            if ("gsap." in h || "scrolltrigger" in h) return 4
            if ("<canvas" in h || "perspective(" in h || "picsum" in h || "unsplash" in h) return 3
            val secs = Regex("<(section|header|footer)[\\s>]").findAll(h).count()
            if (secs >= 2) return 2
            if ("<body" in h || "<section" in h) return 1
            return 0
        }

        fun countSections(sb: CharSequence): Int =
            Regex("<(section|header|footer)[\\s>]").findAll(sb.toString().lowercase()).count()

        fun withSafetyNet(html: String): String {
            val sn = """<script>(function(){var d=false;function fix(){if(d)return;d=true;document.querySelectorAll("*").forEach(function(el){if(el.tagName==="CANVAS"||el.tagName==="SCRIPT")return;var cs=getComputedStyle(el);if(cs.position==="fixed"||el.getAttribute("aria-hidden")==="true")return;if(parseFloat(cs.opacity)===0&&el.textContent.trim().length>10){el.style.transition="opacity .6s";el.style.opacity="1"}})}setTimeout(fix,1400);})();</script>"""
            return html.replace("</body>", "$sn</body>", ignoreCase = true)
        }

        const val FORGE_SYS = """You are an expert single-file website builder. Output ONLY raw HTML, no markdown fences, no explanations.
Rules: ONE self-contained HTML file. Tailwind via CDN (https://cdn.tailwindcss.com). GSAP + ScrollTrigger via CDN for motion. Mobile-first, hamburger nav under 768px. 5-6 sections: nav, hero, features/services (bento grid), gallery or about, testimonials, CTA + footer.
Photos in AT MOST two sections (use https://picsum.photos/seed/<word>/800/600). Every other section gets a 3D visual: a Three.js scene in the hero background and CTA (via CDN https://cdnjs.cloudflare.com/ajax/libs/three.js/0.160.0/three.min.js), CSS 3D (tilt cards, flip cards) elsewhere.
Dark gradient overlay over photo sections so text is readable. Magnetic buttons, generous spacing, premium typography.
CRITICAL: never leave content at opacity:0 waiting for animation — always add a fallback timer so content is visible within 1.2s even if ScrollTrigger fails. Respect prefers-reduced-motion.
Write completely original markup and code. Finish the whole page with </body></html>."""
    }
}
