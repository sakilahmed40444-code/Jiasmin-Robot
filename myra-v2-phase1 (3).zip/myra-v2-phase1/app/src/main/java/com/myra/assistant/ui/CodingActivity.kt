package com.myra.assistant.ui

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream

/** Python Coding: code editor with save-as (PDF/txt/py/java...), copy, delete, select all. */
class CodingActivity : AppCompatActivity() {

    private lateinit var editor: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF0D0D0D.toInt()); setPadding(dp(14), dp(40), dp(14), dp(10)) }
        root.addView(tv("🐍 Coding", 22f, 0xFFFF1744.toInt(), true))

        editor = EditText(this).apply {
            hint = "Code লিখো... (Python, Java, ...)"
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF888888.toInt())
            typeface = Typeface.MONOSPACE; textSize = 13f
            gravity = Gravity.TOP; minLines = 12
            setBackgroundColor(0xFF1A1A1A.toInt())
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        root.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        bar.addView(btn("💾 Save") { saveDialog() })
        bar.addView(btn("📋 Copy") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("code", editor.text.toString()))
            Toast.makeText(this, "Copied ✅", Toast.LENGTH_SHORT).show()
        })
        bar.addView(btn("🗑️ Delete") { editor.setText("") })
        bar.addView(btn("☑️ All") { editor.selectAll() })
        root.addView(bar)

        setContentView(root)
    }

    private fun btn(label: String, act: () -> Unit): Button {
        return Button(this).apply { text = label; setOnClickListener { act() } }
    }

    private fun saveDialog() {
        val code = editor.text.toString()
        if (code.isBlank()) { Toast.makeText(this, "খালি", Toast.LENGTH_SHORT).show(); return }
        val formats = arrayOf("PDF (.pdf)", "Python (.py)", "Java (.java)", "Kotlin (.kt)", "Text (.txt)", "HTML (.html)")
        AlertDialog.Builder(this).setTitle("কি File-এ save করবো?")
            .setItems(formats) { _, which ->
                when (which) {
                    0 -> savePdf(code)
                    else -> {
                        val ext = listOf("", "py", "java", "kt", "txt", "html")[which]
                        saveTextFile(code, ext)
                    }
                }
            }.show()
    }

    private fun saveTextFile(code: String, ext: String) {
        try {
            val file = File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "myra_code_${System.currentTimeMillis()}.$ext")
            file.writeText(code)
            Toast.makeText(this, "Saved: ${file.name} ✅", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Fail: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun savePdf(code: String) {
        try {
            val doc = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            var page = doc.startPage(pageInfo)
            var y = 40f
            val paint = android.graphics.Paint().apply { textSize = 10f; color = 0xFF000000.toInt(); typeface = Typeface.MONOSPACE }
            for (line in code.lines()) {
                if (y > 800) { doc.finishPage(page); page = doc.startPage(pageInfo); y = 40f }
                page.canvas.drawText(line.take(90), 40f, y, paint); y += 14
            }
            doc.finishPage(page)
            val file = File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "myra_code_${System.currentTimeMillis()}.pdf")
            doc.writeTo(FileOutputStream(file)); doc.close()
            Toast.makeText(this, "PDF saved: ${file.name} ✅", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "PDF fail: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun tv(t: String, s: Float, c: Int = 0xFFFFFFFF.toInt(), b: Boolean = false): TextView {
        return TextView(this).apply { text = t; textSize = s; setTextColor(c); if (b) typeface = Typeface.DEFAULT_BOLD }
    }
    private fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
