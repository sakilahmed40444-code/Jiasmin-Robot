package com.lia.assistant.data

import android.content.Context
import android.content.SharedPreferences

/** Sab settings sirf phone me — koi server nahi. */
class Prefs(ctx: Context) {
    private val sp: SharedPreferences =
        ctx.getSharedPreferences("lia_prefs", Context.MODE_PRIVATE)

    var name: String
        get() = sp.getString("name", "dost") ?: "dost"
        set(v) = sp.edit().putString("name", v).apply()

    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(v) = sp.edit().putString("apiKey", v).apply()

    var model: String
        get() = sp.getString("model", "gemini-2.0-flash") ?: "gemini-2.0-flash"
        set(v) = sp.edit().putString("model", v).apply()

    var persona: String
        get() = sp.getString("persona", "normal") ?: "normal"
        set(v) = sp.edit().putString("persona", v).apply()

    /** auto / hi / hing / en */
    var langMode: String
        get() = sp.getString("langMode", "auto") ?: "auto"
        set(v) = sp.edit().putString("langMode", v).apply()

    var speechRate: Float
        get() = sp.getFloat("speechRate", 1.0f)
        set(v) = sp.edit().putFloat("speechRate", v).apply()

    var bubbleOn: Boolean
        get() = sp.getBoolean("bubbleOn", false)
        set(v) = sp.edit().putBoolean("bubbleOn", v).apply()

    // ---- v1.1: Zara-style functions ----
    var wakeWord: String
        get() = sp.getString("wakeWord", "hello lia") ?: "hello lia"
        set(v) = sp.edit().putString("wakeWord", v).apply()

    var dismissWord: String
        get() = sp.getString("dismissWord", "bye bye") ?: "bye bye"
        set(v) = sp.edit().putString("dismissWord", v).apply()

    var wakeMode: Boolean
        get() = sp.getBoolean("wakeMode", false)
        set(v) = sp.edit().putBoolean("wakeMode", v).apply()

    var wakeTimeoutSec: Int
        get() = sp.getInt("wakeTimeoutSec", 30)
        set(v) = sp.edit().putInt("wakeTimeoutSec", v).apply()

    /** TTS voice ka naam ("" = default) */
    var ttsVoiceName: String
        get() = sp.getString("ttsVoiceName", "") ?: ""
        set(v) = sp.edit().putString("ttsVoiceName", v).apply()

    /** Custom personality instruction */
    var customPersona: String
        get() = sp.getString("customPersona", "") ?: ""
        set(v) = sp.edit().putString("customPersona", v).apply()

    var openRouterKey: String
        get() = sp.getString("openRouterKey", "") ?: ""
        set(v) = sp.edit().putString("openRouterKey", v).apply()

    var openRouterModel: String
        get() = sp.getString("openRouterModel", "meta-llama/llama-3.1-8b-instruct:free")
            ?: "meta-llama/llama-3.1-8b-instruct:free"
        set(v) = sp.edit().putString("openRouterModel", v).apply()

    var serpKey: String
        get() = sp.getString("serpKey", "") ?: ""
        set(v) = sp.edit().putString("serpKey", v).apply()
}
