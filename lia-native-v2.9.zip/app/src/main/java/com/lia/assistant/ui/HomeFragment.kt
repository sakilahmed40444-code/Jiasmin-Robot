package com.lia.assistant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import com.lia.assistant.brain.LiaResponder
import com.lia.assistant.brain.Weather
import com.lia.assistant.data.HistoryStore
import com.lia.assistant.service.VoiceLoopService
import com.lia.assistant.voice.VoiceEngine

/** Priya Assistant — Zara-style neon dashboard. Voice loop = 24h foreground service. */
class HomeFragment : Fragment() {
    private fun act() = activity as MainActivity
    private var orb: BubbleView? = null
    private var weatherTv: TextView? = null
    private var locTv: TextView? = null
    private var loveSwitch: Switch? = null
    private var pttBtn: TextView? = null
    private var pttStatus: TextView? = null
    private var pttEngine: VoiceEngine? = null
    private var pttActive = false
    private var startStopBtn: android.widget.Button? = null
    private val REQ_MIC = 72

    /** START (Jiasmin On) ⇄ OFF (Jiasmin Stop) toggle */
    fun setStartStop(on: Boolean) {
        activity?.runOnUiThread {
            startStopBtn?.text = if (on) "⏹️ OFF (Jiasmin Stop)" else "🎙️ START (Jiasmin On)"
            startStopBtn?.setBackgroundColor(Ui.col(if (on) "#D32F2F" else Ui.ACCENT))
            pttBtn?.visibility = if (on) View.GONE else View.VISIBLE
        }
    }

    private fun toggleVoiceSession() {
        val ctx = context ?: return
        if (VoiceLoopService.isRunning) {
            VoiceLoopService.stop(ctx)
            setStartStop(false)
            act().toast("জিয়াসমিন ঘুমাচ্ছে 😴")
        } else {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
                act().toast("আগে মাইকের অনুমতি দাও 🎙️")
                return
            }
            act().toast("জিয়াসমিন জাগছে…")
            VoiceLoopService.start(ctx)
            setStartStop(true)
        }
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        if (rc == REQ_MIC && res.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            val ctx = context ?: return
            act().toast("মাইক পেয়ে গেছি! 🎙️")
            VoiceLoopService.start(ctx)
            setStartStop(true)
        }
    }

    override fun onResume() {
        super.onResume()
        setStartStop(VoiceLoopService.isRunning)
        VoiceStateBus.listen { s -> activity?.runOnUiThread { orb?.state = s } }
        LoopTextBus.listen { t -> activity?.runOnUiThread { pttStatus?.text = t } }
        if (VoiceLoopService.isRunning) orb?.state = BubbleView.State.LISTENING
    }

    override fun onPause() {
        super.onPause()
        // service choltei thakbe — shudhu UI sunna bondho
        VoiceStateBus.clear()
        LoopTextBus.clear()
        try { pttEngine?.stopListen() } catch (_: Exception) {}
        try { pttEngine?.stopSpeak() } catch (_: Exception) {}
        pttEngine = null
        pttActive = false
    }

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.col(Ui.BG))
        }
        val scroll = ScrollView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val col = Ui.colLayout(ctx, 14)
        scroll.addView(col)
        root.addView(scroll)

        // ---- Branding ----
        col.addView(Ui.tv(ctx, "Priya", 34, Ui.TEXT, true).apply { gravity = Gravity.CENTER })
        col.addView(Ui.tv(ctx, "💗  AI ASSISTANT  💗", 14, Ui.ACCENT, true).apply { gravity = Gravity.CENTER })
        col.addView(sp(10))

        // ---- System status card ----
        val statusCard = card(ctx)
        val sRow = hrow(ctx)
        sRow.addView(Ui.tv(ctx, "SYSTEM STATUS", 13, Ui.TEXT2, true))
        val dot = View(ctx).apply {
            setBackgroundColor(Ui.col(Ui.NEON_GREEN))
            layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 10), Ui.dp(ctx, 10)).apply {
                gravity = Gravity.CENTER_VERTICAL; leftMargin = Ui.dp(ctx, 8)
            }
        }
        sRow.addView(dot)
        val op = TextView(ctx).apply {
            text = "OPERATIONAL"; setTextColor(Ui.col(Ui.NEON_GREEN)); textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                gravity = Gravity.CENTER_VERTICAL
            }
            gravity = Gravity.END
        }
        sRow.addView(op)
        statusCard.addView(sRow)
        col.addView(statusCard)
        col.addView(sp(10))

        // ---- Main grid: left mini cards + AI core unit ----
        val grid = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val mini = listOf(
            Pair("🧠" to "Mem", MainActivity.TAB_SETTINGS),
            Pair("✨" to "Soul", MainActivity.TAB_SETTINGS),
            Pair("🗄️" to "Data", MainActivity.TAB_SETTINGS),
            Pair("📊" to "Stats", MainActivity.TAB_SETTINGS)
        )
        for ((label, tab) in mini) {
            val mc = card(ctx).apply { setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 10), Ui.dp(ctx, 10), Ui.dp(ctx, 10)) }
            val t1 = Ui.tv(ctx, label.first, 18, Ui.TEXT, true).apply { gravity = Gravity.CENTER }
            val t2 = Ui.tv(ctx, label.second, 12, Ui.TEXT2, true).apply { gravity = Gravity.CENTER }
            val t3 = Ui.tv(ctx, "Connected", 10, Ui.NEON_GREEN).apply { gravity = Gravity.CENTER }
            mc.addView(t1); mc.addView(t2); mc.addView(t3)
            mc.setOnClickListener { act().go(tab) }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = Ui.dp(ctx, 8)
            mc.layoutParams = lp
            left.addView(mc)
        }
        grid.addView(left)
        grid.addView(sp(10, true))

        val core = card(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.6f)
        }
        core.addView(Ui.tv(ctx, "AI CORE UNIT", 13, Ui.TEXT2, true).apply { gravity = Gravity.CENTER })
        orb = BubbleView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 130), Ui.dp(ctx, 130)).apply {
                gravity = Gravity.CENTER; topMargin = Ui.dp(ctx, 6); bottomMargin = Ui.dp(ctx, 6)
            }
            state = BubbleView.State.IDLE
        }
        core.addView(orb)
        core.addView(Ui.tv(ctx, "❤️  সক্রিয় ও শিখছে  ❤️", 11, Ui.ACCENT, true).apply { gravity = Gravity.CENTER })
        startStopBtn = Ui.btn(ctx, "🎙️ START (Jiasmin On)", true) { toggleVoiceSession() }
        core.addView(startStopBtn)
        setStartStop(VoiceLoopService.isRunning)
        // ---- Gol push-to-talk: dabao to sune, chhodo to jawab de ----
        core.addView(sp(6))
        pttBtn = TextView(ctx).apply {
            text = "🎙️"; textSize = 34f; gravity = Gravity.CENTER
            val sz = Ui.dp(ctx, 88)
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { gravity = Gravity.CENTER }
            setBackgroundColor(Ui.col("#00000000"))
            setOnTouchListener { v, ev ->
                when (ev.action) {
                    android.view.MotionEvent.ACTION_DOWN -> { startPtt(); true }
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> { stopPtt(); true }
                    else -> false
                }
            }
        }
        core.addView(pttBtn)
        pttStatus = Ui.tv(ctx, "গোল বাটন চেপে ধরে রাখো, বলো… 🎙️", 12, Ui.TEXT2).apply { gravity = Gravity.CENTER }
        core.addView(pttStatus)
        grid.addView(core)
        col.addView(grid)
        col.addView(sp(10))

        // ---- System overview ----
        col.addView(Ui.tv(ctx, "SYSTEM OVERVIEW", 14, Ui.TEXT2, true))
        col.addView(sp(4))
        val ov = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val loveCard = card(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        loveCard.addView(Ui.tv(ctx, "💘 Love Mode", 13, Ui.TEXT, true).apply { gravity = Gravity.CENTER })
        loveSwitch = Switch(ctx).apply {
            isChecked = act().prefs.loveMode
            setOnCheckedChangeListener { _, on ->
                act().prefs.loveMode = on
                act().toast(if (on) "Love Mode ON 💘" else "Love Mode OFF")
            }
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.CENTER }
        }
        loveCard.addView(loveSwitch)
        ov.addView(loveCard); ov.addView(sp(8, true))
        ov.addView(sysCard(ctx, "⚡", "CPU POWER", "98%"))
        ov.addView(sp(8, true))
        ov.addView(sysCard(ctx, "📶", "NETWORK", "CONNECTED"))
        col.addView(ov)
        col.addView(sp(10))

        // ---- Diagnostics waveform ----
        val dg = card(ctx)
        dg.addView(Ui.tv(ctx, "AI CORE DIAGNOSTICS", 13, Ui.TEXT2, true))
        dg.addView(WaveView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 44))
        })
        col.addView(dg)
        col.addView(sp(10))

        // ---- Location + weather ----
        val lw = card(ctx)
        locTv = Ui.tv(ctx, "📍 LOCATION", 13, Ui.TEXT2, true)
        lw.addView(locTv)
        lw.addView(Ui.tv(ctx, "Location services status yahan dikhega.", 12, Ui.TEXT3))
        weatherTv = Ui.tv(ctx, "🌤️ LOCAL WEATHER  --°C", 14, Ui.TEXT, true)
        lw.addView(weatherTv)
        val tz = java.util.TimeZone.getDefault().id
        lw.addView(Ui.tv(ctx, "🕐 TIMEZONE  $tz", 12, Ui.TEXT2))
        lw.setOnClickListener { loadWeather() }
        col.addView(lw)
        col.addView(sp(10))

        // ---- Command list: ki bolle ki hobe ----
        val vc = card(ctx)
        vc.addView(Ui.tv(ctx, "📋 কি বললে কি হবে", 14, Ui.TEXT, true))
        vc.addView(Ui.tv(ctx,
            "• \"ইউটিউব খোলো\" → ইউটিউব\n" +
            "• \"অমুক গান চালাও\" → গান বাজবে\n" +
            "• \"ফেসবুক খোলো\" → ফেসবুক\n" +
            "• \"রহিমকে কল করো\" → কল যাবে\n" +
            "• \"কল কেটে দাও\" → কল কাটবে\n" +
            "• \"আবহাওয়া কেমন\" → আবহাওয়া\n" +
            "• \"ওয়েবসাইট বানাও\" → Forge\n" +
            "• \"পাইথন লিখো\" → Python code\n" +
            "• \"স্ক্রিন দেখাও\" → স্ক্রিন পড়বে\n" +
            "• \"মনে রাখো …\" → মনে রাখবে", 13, Ui.TEXT))
        col.addView(vc)
        col.addView(sp(10))

        // ---- Forge ----
        val fg = card(ctx)
        val frow = hrow(ctx)
        frow.addView(Ui.tv(ctx, "🔥 Website Forge\nবলে website বানাও", 14, Ui.TEXT, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        frow.addView(Ui.btn(ctx, "OPEN", true) { act().go(MainActivity.TAB_FORGE) })
        fg.addView(frow)
        col.addView(fg)
        col.addView(sp(10))

        // ---- Chat ----
        val ch = card(ctx)
        val crow = hrow(ctx)
        crow.addView(Ui.tv(ctx, "💬 Chat\nলিখে কথা বলো", 14, Ui.TEXT, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        crow.addView(Ui.btn(ctx, "OPEN", true) { act().go(MainActivity.TAB_CHAT) })
        ch.addView(crow)
        col.addView(ch)
        col.addView(sp(10))

        // ---- Always here ----
        val al = card(ctx)
        al.addView(Ui.tv(ctx, "I'm here for you, always ❤️", 15, Ui.ACCENT, true).apply { gravity = Gravity.CENTER })
        col.addView(al)
        col.addView(sp(24))

        // ---- Bottom text bar (fixed) ----
        val brow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.col(Ui.SURFACE))
            val pp = Ui.dp(ctx, 8); setPadding(pp, pp, pp, pp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val histBtn = TextView(ctx).apply {
            text = "🕘"; textSize = 24f; gravity = Gravity.CENTER
            setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 8), Ui.dp(ctx, 8), Ui.dp(ctx, 8))
            setOnClickListener { showHistory() }
        }
        brow.addView(histBtn)
        val tinput = EditText(ctx).apply {
            hint = "লিখো… ✍️"
            setHintTextColor(Ui.col(Ui.TEXT3))
            setTextColor(Ui.col(Ui.TEXT))
            textSize = 14f
            setBackgroundColor(Ui.col(Ui.RAISED))
            val pp2 = Ui.dp(ctx, 10); setPadding(pp2, pp2, pp2, pp2)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            isSingleLine = true
        }
        brow.addView(tinput)
        val tsend = Ui.btn(ctx, "➤", true) {
            val t = tinput.text.toString().trim()
            if (t.isNotBlank()) {
                tinput.setText("")
                try {
                    val imm = ctx.getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                    imm.hideSoftInputFromWindow(tinput.windowToken, 0)
                } catch (_: Exception) { }
                val a = activity as? MainActivity ?: return@btn
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
                }
                VoiceLoopService.start(a, t)
                setStartStop(true)
            }
        }
        brow.addView(tsend)
        root.addView(brow)

        loadWeather()
        return root
    }

    // ================= History dialog =================

    private fun showHistory() {
        val ctx = requireContext()
        val list = HistoryStore.all(ctx)
        val dlg = android.app.AlertDialog.Builder(ctx).create()
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.col(Ui.SURFACE))
            val pp = Ui.dp(ctx, 14); setPadding(pp, pp, pp, pp)
        }
        col.addView(Ui.tv(ctx, "🕘 কথার History", 18, Ui.TEXT, true))
        val sv = ScrollView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 320))
        }
        val inner = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        if (list.isEmpty()) inner.addView(Ui.tv(ctx, "এখনো কোনো কথা হয়নি 💗", 13, Ui.TEXT3))
        for (e in list.take(100)) {
            inner.addView(Ui.tv(ctx, "${e.time}  ${e.who}: ${e.text}", 12,
                if (e.who == "তুমি") Ui.TEXT2 else Ui.ACCENT))
        }
        sv.addView(inner)
        col.addView(sv)
        val brow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        brow.addView(Ui.btn(ctx, "🗑️ Delete", false) {
            HistoryStore.clear(ctx); dlg.dismiss(); act().toast("History মুছে দিলাম 🗑️")
        })
        brow.addView(Ui.btn(ctx, "⬇️ Download", true) {
            val f = HistoryStore.exportFile(ctx)
            if (f != null) {
                try {
                    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_STREAM, uri)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    ctx.startActivity(Intent.createChooser(i, "History download"))
                } catch (_: Exception) { act().toast("Download করা গেল না") }
            } else act().toast("History খালি")
            dlg.dismiss()
        })
        col.addView(brow)
        dlg.setView(col)
        dlg.show()
    }

    private fun loadWeather() {
        val ctx = context ?: return
        val hasLoc = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED
        if (!hasLoc) {
            locTv?.text = "📍 LOCATION — off (Settings > Perms me on karo)"
            weatherTv?.text = "🌤️ LOCAL WEATHER  --°C"
            return
        }
        try {
            val lm = ctx.getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
            val loc: Location? = try {
                lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            } catch (_: Exception) { null }
            if (loc == null) {
                weatherTv?.text = "🌤️ LOCAL WEATHER  location mil nahi rahi…"
                return
            }
            locTv?.text = "📍 LOCATION  %.2f, %.2f".format(loc.latitude, loc.longitude)
            weatherTv?.text = "🌤️ LOCAL WEATHER  load ho raha…"
            Thread {
                val w = try { Weather.current(loc.latitude, loc.longitude) } catch (_: Exception) { null }
                Handler(Looper.getMainLooper()).post {
                    weatherTv?.text = if (w != null) "🌤️ LOCAL WEATHER  $w" else "🌤️ LOCAL WEATHER  --°C"
                }
            }.start()
        } catch (_: Exception) { }
    }

    private fun card(ctx: android.content.Context): LinearLayout {
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.col(Ui.SURFACE))
            val pp = Ui.dp(ctx, 14); setPadding(pp, pp, pp, pp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
    }

    private fun hrow(ctx: android.content.Context) = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
    }

    private fun sysCard(ctx: android.content.Context, icon: String, t1: String, t2: String): LinearLayout {
        val c = card(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        c.addView(Ui.tv(ctx, icon, 20, Ui.TEXT, true).apply { gravity = Gravity.CENTER })
        c.addView(Ui.tv(ctx, t1, 11, Ui.TEXT2, true).apply { gravity = Gravity.CENTER })
        c.addView(Ui.tv(ctx, t2, 12, Ui.NEON_GREEN, true).apply { gravity = Gravity.CENTER })
        return c
    }

    private fun sp(dp: Int, horizontal: Boolean = false): View {
        val v = View(context)
        v.layoutParams = if (horizontal)
            LinearLayout.LayoutParams(Ui.dp(context!!, dp), 1)
        else
            LinearLayout.LayoutParams(1, Ui.dp(context!!, dp))
        return v
    }

    // ================= Gol push-to-talk (one-shot) =================

    private fun startPtt() {
        val ctx = context ?: return
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            act().toast("আগে মাইকের অনুমতি দাও 🎙️")
            return
        }
        if (pttActive) return
        pttActive = true
        pttStatus?.text = "শুনছি… ছাড়ো 🎙️"
        orb?.state = BubbleView.State.LISTENING
        try {
            pttEngine = VoiceEngine(ctx).apply {
                cb = object : VoiceEngine.Cb {
                    override fun onListening() { }
                    override fun onPartial(t: String) { }
                    override fun onResult(text: String) {
                        pttActive = false
                        activity?.runOnUiThread { handlePtt(text) }
                    }
                    override fun onError(msg: String) {
                        pttActive = false
                        activity?.runOnUiThread {
                            orb?.state = BubbleView.State.IDLE
                            pttStatus?.text = "আবার চেষ্টা করো 🎙️"
                        }
                    }
                    override fun onSpeakDone() {
                        activity?.runOnUiThread {
                            if (!VoiceLoopService.isRunning) orb?.state = BubbleView.State.IDLE
                        }
                    }
                }
                listen("bn")
            }
        } catch (_: Exception) { pttActive = false }
    }

    private fun stopPtt() {
        if (!pttActive) return
        try { pttEngine?.finishListen() } catch (_: Exception) { pttActive = false }
    }

    private fun handlePtt(text: String) {
        orb?.state = BubbleView.State.THINKING
        pttStatus?.text = "🗣️ $text\nভাবছি…"
        HistoryStore.add(requireContext(), "তুমি", text)
        Thread {
            try {
                act().responder.respond(text, object : LiaResponder.Cb {
                    override fun onReply(reply: String, lang: String) {
                        activity?.runOnUiThread {
                            if (!isAdded) return@runOnUiThread
                            HistoryStore.add(requireContext(), "প্রিয়া", reply)
                            pttStatus?.text = "💗 $reply"
                            orb?.state = BubbleView.State.SPEAKING
                            val e = pttEngine ?: return@runOnUiThread
                            val p = act().prefs
                            e.geminiVoice = p.geminiVoice.ifBlank { null }
                            e.geminiKey = p.apiKey.takeIf { it.isNotBlank() }
                            e.setVoiceByName(p.ttsVoiceName)
                            e.setLang(lang, p.speechRate)
                            e.speak(reply)
                        }
                    }
                })
            } catch (_: Exception) { }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        try { pttEngine?.destroy() } catch (_: Exception) { }
        pttEngine = null
    }
}
