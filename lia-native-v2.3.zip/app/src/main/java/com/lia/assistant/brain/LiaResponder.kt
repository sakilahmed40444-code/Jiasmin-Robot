package com.lia.assistant.brain

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.core.content.ContextCompat
import com.lia.assistant.action.ActionExecutor
import com.lia.assistant.data.MemStore
import com.lia.assistant.data.Prefs

/**
 * Voice aur Chat dono ka shared dimaag:
 * text → Action? → execute : weather/search : (Gemini → OpenRouter → Offline) → reply
 * Hamesha background thread par chalao.
 */
class LiaResponder(private val ctx: Context, val prefs: Prefs, val mem: ConversationMemory) {

    val executor = ActionExecutor(ctx.applicationContext)

    interface Cb { fun onReply(text: String, lang: String) }

    fun respond(text: String, cb: Cb) {
        val detected = LanguageDetector.detect(text)
        val lang = LanguageDetector.effective(prefs.langMode, detected)
        val name = prefs.name.ifBlank { "dost" }
        try {
            val action = CommandParser.parse(text)
            if (action != null) {
                val (reply, _) = executor.execute(action, name)
                mem.addUser(text); mem.addAssistant(reply)
                cb.onReply(reply, lang)
                return
            }
            // Mausam — asli data, bina key ke
            if (needsWeather(text)) {
                val w = tryWeather(name)
                if (w != null) {
                    mem.addUser(text); mem.addAssistant(w)
                    cb.onReply(w, lang)
                    return
                }
            }
            // Web search — Serp API key ho to
            if (needsSearch(text) && prefs.serpKey.isNotBlank()) {
                try {
                    val res = WebSearch.search(prefs.serpKey, text)
                    val reply = "Internet par ye mila, $name:\n$res"
                    mem.addUser(text); mem.addAssistant(reply)
                    cb.onReply(reply, lang)
                    return
                } catch (_: Exception) { /* neeche LLM try karo */ }
            }
            val reply = brainReply(text, lang, name)
            mem.addUser(text); mem.addAssistant(reply)
            cb.onReply(reply, lang)
        } catch (e: Exception) {
            val fb = OfflineBrain.reply(text, lang, name)
            mem.addUser(text); mem.addAssistant(fb)
            cb.onReply(fb, lang)
        }
    }

    private fun brainReply(text: String, lang: String, name: String): String {
        val memories = MemStore.asPrompt(ctx)
        val sys = PromptBuilder.build(
            Persona.byKey(prefs.persona), lang, name,
            mem.recap().ifBlank { null }, prefs.customPersona, memories
        )
        // 1) Gemini
        if (prefs.apiKey.isNotBlank()) {
            try {
                return GeminiClient.chat(prefs.apiKey, prefs.model, sys, mem.history(), text)
            } catch (_: Exception) { /* 2) OpenRouter try karo */ }
        }
        // 2) OpenRouter
        if (prefs.openRouterKey.isNotBlank()) {
            try {
                return OpenRouterClient.chat(prefs.openRouterKey, prefs.openRouterModel, sys, mem.history(), text)
            } catch (_: Exception) { /* 3) offline */ }
        }
        // 3) Offline
        return OfflineBrain.reply(text, lang, name)
    }

    private fun needsWeather(t: String): Boolean {
        val s = t.lowercase()
        return s.contains("mausam") || s.contains("weather") || s.contains("temperature") ||
                s.contains("tapman") || s.contains("barish") || s.contains("garmi") || s.contains("thand")
    }

    private fun needsSearch(t: String): Boolean {
        val s = t.lowercase()
        return s.contains("search karo") || s.contains("google karo") || s.contains("taza khabar") ||
                s.contains("aaj ki khabar") || (s.contains("news") && s.length < 60) || s.contains("latest")
    }

    private fun tryWeather(name: String): String? {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) return null
        return try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                ?: return null
            val w = Weather.current(loc.latitude, loc.longitude)
            "Abhi ka mausam, $name: $w 🌤️"
        } catch (_: Exception) { null }
    }
}
