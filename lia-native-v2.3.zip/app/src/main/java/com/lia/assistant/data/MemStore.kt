package com.lia.assistant.data

import android.content.Context
import org.json.JSONArray

/** Long-term memories — "yaad rakho ..." se save, baat me yaad rahe. */
object MemStore {
    private const val PREF = "lia_prefs"
    private const val KEY = "lia_mems"
    private const val MAX = 50

    fun list(ctx: Context): MutableList<String> {
        return try {
            val s = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
            val a = JSONArray(s)
            MutableList(a.length()) { a.getString(it) }
        } catch (_: Exception) { mutableListOf() }
    }

    fun add(ctx: Context, m: String) {
        val clean = m.trim().take(300)
        if (clean.isEmpty()) return
        val l = list(ctx)
        l.remove(clean)
        l.add(0, clean)
        save(ctx, l.take(MAX))
    }

    fun remove(ctx: Context, m: String) {
        val l = list(ctx)
        l.remove(m)
        save(ctx, l)
    }

    fun clear(ctx: Context) = save(ctx, emptyList())

    private fun save(ctx: Context, l: List<String>) {
        val a = JSONArray()
        for (s in l) a.put(s)
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
    }

    /** System prompt me daalne ke liye. */
    fun asPrompt(ctx: Context): String =
        list(ctx).take(15).joinToString("\n") { "- $it" }
}
