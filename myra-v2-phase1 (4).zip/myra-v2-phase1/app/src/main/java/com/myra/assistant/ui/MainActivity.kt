package com.myra.assistant.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.myra.assistant.ai.GeminiLive
import com.myra.assistant.ai.PipelineUi
import com.myra.assistant.ai.State
import com.myra.assistant.ai.VoicePipeline
import com.myra.assistant.data.Prefs
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class MainActivity : AppCompatActivity(), PipelineUi {
    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var caption: TextView
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var micBtn: TextView
    private lateinit var codeBtn: TextView
    private lateinit var redOverlay: View
    private lateinit var pipeline: VoicePipeline
    private var live: GeminiLive? = null
    private var greeted = false

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { maybeStart() }
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) sendPhoto(uri)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = C.bg
        pipeline = VoicePipeline(applicationContext, this)
        startProactivePrompt()
        buildUi()
        val missing = Perms.missing(this)
        if (missing.isNotEmpty()) permLauncher.launch(missing)
        showLastCrash()
        if (intent?.getBooleanExtra("start_voice", false) == true) {
            // opened from floating ball: start listening right away
            maybeStart()
        } else {
            // fresh open: greet after a moment
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ greet() }, 1500)
        }
        // offline -> online greeting
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            var wasOffline = false
            cm.registerDefaultNetworkCallback(object : android.net.ConnectivityManager.NetworkCallback() {
                override fun onLost(n: android.net.Network) { wasOffline = true }
                override fun onAvailable(n: android.net.Network) {
                    if (wasOffline) { wasOffline = false; runOnUiThread { greet() } }
                }
            })
        } catch (e: Exception) {}
    }

    /** If the app crashed last time, show the saved stack trace so it can be reported. */
    private fun showLastCrash() {
        try {
            val f = java.io.File(filesDir, "crash.txt")
            if (!f.exists()) return
            val trace = f.readText().take(3000)
            f.delete()
            val sv = ScrollView(this).apply {
                addView(tv(trace, 11f).apply { setPadding(dp(16), dp(12), dp(16), dp(12)) })
            }
            AlertDialog.Builder(this).setTitle("⚠ গতবার app crash করেছিল")
                .setMessage("এই কারণটা developer-কে পাঠাও:")
                .setView(sv)
                .setPositiveButton("OK", null).show()
        } catch (e: Exception) {}
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply {
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF0A0A2E.toInt(), 0xFF1A1A3E.toInt(), 0xFF2D1B4E.toInt()))
        }
        redOverlay = View(this).apply { setBackgroundColor(C.red); alpha = 0f }
        root.addView(redOverlay, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(16), dp(14), dp(8)) }

        // === TOP BAR: MYRA logo + </> + gear ===
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(tv("MYRA", 30f, 0xFFE91E63.toInt(), true).apply { typeface = Typeface.create("sans-serif-black", Typeface.BOLD) })
        titleBox.addView(tv("AI COMPANION", 11f, C.hint))
        top.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        codeBtn = tv("</>", 20f, 0xFF4CAF50.toInt(), true).apply {
            background = round(0xFF1A1A2E.toInt(), 24, 0xFF4CAF50.toInt())
            setPadding(dp(14), dp(10), dp(14), dp(10)); setOnClickListener { toggleCode() } }
        top.addView(codeBtn, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(10) })
        top.addView(tv("\u2699\uFE0F", 24f).apply {
            background = round(0xFF1A1A2E.toInt(), 24, 0xFF888888.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) } })
        col.addView(top)

        // === BALL (orange/yellow, large) ===
        orb = OrbView(this)
        // Force IDLE orange colors
        col.addView(orb, LinearLayout.LayoutParams(-1, dp(260)))

        // === STATUS PILL ===
        val statusWrap = LinearLayout(this).apply { gravity = Gravity.CENTER }
        status = tv("START MYRA চাপো 🎤", 15f, C.text).apply {
            gravity = Gravity.CENTER
            background = round(0xFF1A1A2E.toInt(), 24, 0xFF555555.toInt())
            setPadding(dp(24), dp(12), dp(24), dp(12))
        }
        statusWrap.addView(status)
        col.addView(statusWrap, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(8) })

        // === START MYRA (white card) ===
        val startLabel = tv("START MYRA", 30f, 0xFF000000.toInt(), true).apply {
            gravity = Gravity.CENTER; typeface = Typeface.create("sans-serif-black", Typeface.BOLD) }
        val playBtn = tv("\u25B6", 36f, 0xFFFFFFFF.toInt()).apply {
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFFE91E63.toInt(), 0xFF9C27B0.toInt())).apply { cornerRadius = dp(40).toFloat() }
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val startCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = round(0xFFFFFFFF.toInt(), 24, 0)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        startCard.addView(startLabel)
        val playWrap = LinearLayout(this).apply { gravity = Gravity.CENTER }
        playWrap.addView(playBtn, LinearLayout.LayoutParams(dp(84), dp(84)).apply { topMargin = dp(12) })
        startCard.addView(playWrap)
        startCard.setOnClickListener {
            toggleLive()
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                val r = live?.isRunning == true
                startLabel.text = if (r) "STOP MYRA" else "START MYRA"
                playBtn.text = if (r) "\u23F9" else "\u25B6"
            }, 600)
        }
        col.addView(startCard, LinearLayout.LayoutParams(-1, -2).apply {
            marginStart = dp(8); marginEnd = dp(8); bottomMargin = dp(10) })

        // === MESSAGE INPUT ===
        val bottom = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = round(0xFF1A1A2E.toInt(), 28, 0xFFE91E63.toInt())
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        input = edit("মেসেজ লিখুন...").apply {
            imeOptions = EditorInfo.IME_ACTION_SEND; maxLines = 3
            setBackgroundColor(0x00000000); setHintTextColor(0xFF888888.toInt()); setTextColor(C.text)
            setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_SEND) { send(); true } else false }
        }
        bottom.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(tv("\uD83D\uDDBC\uFE0F", 24f).apply { setPadding(dp(10), dp(8), dp(6), dp(8)); setOnClickListener { pickImage.launch("image/*") } })
        bottom.addView(tv("\uD83D\uDCC4", 24f).apply { setPadding(dp(6), dp(8), dp(10), dp(8)) })
        val sendBtn = tv("\u27A4", 24f, 0xFFFFFFFF.toInt()).apply {
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFFE91E63.toInt(), 0xFF9C27B0.toInt())).apply { cornerRadius = dp(28).toFloat() }
            setPadding(dp(6), dp(6), dp(6), dp(6)); setOnClickListener { send() }
        }
        bottom.addView(sendBtn, LinearLayout.LayoutParams(dp(56), dp(56)))
        col.addView(bottom, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })

        // === MIC + LIVE ROW ===
        val micRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        micBtn = tv("\uD83C\uDFA4", 28f).apply {
            gravity = Gravity.CENTER; background = round(0xFF1A1A2E.toInt(), 36, C.red)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener { onMicTap() }
            setOnLongClickListener { pipeline.stopListen(); pipeline.interrupt(); live?.stop(); status.text = "থামিয়ে দিলাম"; true }
        }
        micRow.addView(micBtn, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(12) })
        val liveBtn = tv("\uD83D\uDD34 Live", 16f, C.text).apply {
            background = round(0xFF1A1A2E.toInt(), 20, 0xFFFF0000.toInt())
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setOnClickListener { toggleLive() }
        }
        micRow.addView(liveBtn)
        col.addView(micRow)
        col.addView(tv("Long press mic = stop speaking", 10f, C.hint).apply { gravity = Gravity.CENTER })

        // === CHAT (scrollable) ===
        caption = tv("", 14f, C.text).apply { gravity = Gravity.CENTER; setPadding(dp(16), dp(4), dp(16), 0) }
        col.addView(caption, LinearLayout.LayoutParams(-1, -2))
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(chat) }
        col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })

        // === BOTTOM NAV (4 buttons, Home active) ===
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFF6A1B9A.toInt(), 0xFFAD1457.toInt())).apply { cornerRadius = dp(28).toFloat() }
            setPadding(dp(8), dp(10), dp(8), dp(10))
        }
        fun navBtn(icon: String, label: String, active: Boolean, act: () -> Unit) {
            val b = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(4), dp(8), dp(4)) }
            b.addView(tv(icon, 28f).apply { gravity = Gravity.CENTER })
            b.addView(tv(label, 13f, if (active) 0xFFFFFFFF.toInt() else 0xFFCCCCCC.toInt(), active).apply { gravity = Gravity.CENTER })
            if (active) {
                val ul = View(this).apply { setBackgroundColor(0xFFE91E63.toInt()) }
                b.addView(ul, LinearLayout.LayoutParams(dp(48), dp(5)).apply { topMargin = dp(4); gravity = Gravity.CENTER })
            }
            b.setOnClickListener { act() }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        navBtn("\uD83C\uDFE0", "Home", true) { scroll.smoothScrollTo(0, 0) }
        navBtn("\u2699\uFE0F", "Settings", false) { startActivity(Intent(this, SettingsActivity::class.java)) }
        navBtn("\uD83D\uDCBE", "Memory", false) { startActivity(Intent(this, MemoryActivity::class.java)) }
        navBtn("\uD83D\uDC0D", "Coding", false) { startActivity(Intent(this, CodingActivity::class.java)) }
        col.addView(nav, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        // === SCROLL EVERYTHING ===
        val mainScroll = ScrollView(this).apply { addView(col) }
        root.addView(mainScroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        updateCodeBtn()
    }

    // ---------------- flow ----------------
    private val promptHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val promptRunnable = object : Runnable {
        override fun run() {
            if (Prefs.hasAnyKey() && !isFinishing) {
                val name = Prefs.addressMe.ifBlank { "সবুজ জান" }
                pipeline.say("বলো $name, কি কাজ করবো?")
            }
            promptHandler.postDelayed(this, 10000)  // Every 10 seconds
        }
    }

    private fun startProactivePrompt() {
        promptHandler.removeCallbacks(promptRunnable)
        promptHandler.postDelayed(promptRunnable, 10000)
    }

    private fun greet() {
        val name = Prefs.addressMe.ifBlank { "সবুজ জান" }
        // Proactive: greet + keep talking by itself
        pipeline.say("সালাম $name! আমি MYRA, তোমার AI companion. কেমন আছো?")
        // Follow up after a moment to keep conversation going
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (Prefs.hasAnyKey()) pipeline.say("বলো $name, আজকে কী করতে চাও? আমি সাহায্য করবো!")
        }, 8000)
    }

    private fun maybeStart() {
        if (!Prefs.hasAnyKey()) { status.text = "⚙️ Settings e API key boshao"; return }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) { status.text = "Mic permission dao"; return }
        pipeline.muted = false; pipeline.start()
        if (!greeted) {
            greeted = true
            pipeline.say(greetFor())
        }
    }

    private fun greetFor(): String = when (Prefs.personality) {
        "GirlFriend" -> "ওই শোনো… বলো না, কী হয়েছে? ❤️"
        "Boss" -> "বলো, কী কাজ?"
        "Teacher" -> "বলো, আজ কী শিখবে?"
        "Soft Romantic Listener" -> "বলো… আমি শুনছি ❤️"
        "Hyper Energetic" -> "ইয়ো! বলো বলো!!"
        "Caring Neon AI" -> "হাই! আমি আছি তোমার পাশে ✨"
        "Mystical" -> "…বলো, রহস্য উন্মোচন করি 🔮"
        "Savage Girl" -> "হ্যাঁ বলো, তাড়াতাড়ি 😏"
        "Unknown" -> "বলো।"
        "Manipulative" -> "বলো… দেখি তোমাকে convince করতে পারি কিনা 😌"
        "MT Assistant" -> "বলো, কী help লাগবে?"
        else -> "বলো 🎙️"
    }

    private fun toggleLive() {
        if (live?.isRunning == true) {
            live?.stop(); live = null
            status.text = "Live বন্ধ"
            return
        }
        // 3. Mic permission for Live
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            status.text = "Mic permission dao 🎤 (Live-এর জন্য)"
            permLauncher.launch(arrayOf(android.Manifest.permission.RECORD_AUDIO))
            return
        }
        if (!Prefs.geminiKeyOn || Prefs.geminiKey.isBlank()) {
            status.text = "⚙️ Settings e Gemini key boshao (Live-এর জন্য)"
            return
        }
        // Stop regular pipeline
        pipeline.stopListen(); pipeline.interrupt()
        live = GeminiLive(applicationContext, this@MainActivity).apply {
            onTranscript = { text: String, isUser: Boolean ->
                runOnUiThread {
                    if (isUser) { bubble(text, true); Prefs.addHistory("তুমি: $text") }
                    else { bubble(text, false); Prefs.addHistory("MYRA: $text") }
                }
            }
            start()
        }
        status.text = "🔴 Live Voice চালু — বলো!"
    }

    private fun onMicTap() {
        // New: toggle SpeechRecognizer STT (Mic -> Text -> AI -> Voice)
        if (!Prefs.hasAnyKey()) { status.text = "⚙️ Settings e API key boshao"; return }
        // Mic permission check (root cause of "not hearing")
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            status.text = "Mic permission dao 🎤"
            permLauncher.launch(arrayOf(android.Manifest.permission.RECORD_AUDIO))
            return
        }
        pipeline.toggleListen()
    }

    private fun send() {
        try {
            val t = input.text.toString().trim(); if (t.isEmpty()) return
            input.setText(""); pipeline.sendText(t)
        } catch (e: Exception) {
            Toast.makeText(this, "Error: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_SHORT).show()
        }
    }

    /** Send a photo: show in chat + let MYRA see it. */
    private fun sendPhoto(uri: android.net.Uri) {
        try {
            // show thumbnail in chat
            val iv = android.widget.ImageView(this).apply {
                setImageURI(uri)
                adjustViewBounds = true; maxHeight = dp(220)
                setPadding(dp(4), dp(4), dp(4), dp(4))
            }
            addToChat(iv, android.view.Gravity.END)
            // compress -> base64
            val b64 = compressToB64(uri) ?: run { Toast.makeText(this, "Photo read hoy nai", Toast.LENGTH_SHORT).show(); return }
            val caption = input.text.toString().trim().ifEmpty { "Ei photo-ta dekho to, ki dekhte paccho?" }
            input.setText("")
            pipeline.sendText(caption, caption, imageB64 = b64, imageMime = "image/jpeg")
        } catch (e: Exception) {
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun compressToB64(uri: android.net.Uri): String? = try {
        val bmp = android.provider.MediaStore.Images.Media.getBitmap(contentResolver, uri)
        val w = bmp.width; val h = bmp.height
        val scale = minOf(1f, 1024f / maxOf(w, h))
        val small = android.graphics.Bitmap.createScaledBitmap(bmp, (w * scale).toInt(), (h * scale).toInt(), true)
        val out = java.io.ByteArrayOutputStream()
        small.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, out)
        android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP)
    } catch (e: Exception) { null }

    private fun toggleCode() { Prefs.codeMode = !Prefs.codeMode; updateCodeBtn(); Toast.makeText(this, if (Prefs.codeMode) "Code mode ON (high thinking, long output)" else "Code mode OFF", Toast.LENGTH_SHORT).show() }
    private fun updateCodeBtn() { codeBtn.setTextColor(if (Prefs.codeMode) C.ok else C.hint) }

    override fun onResume() { super.onResume(); if (Prefs.needGreet) { Prefs.needGreet = false; greet() }; if (Prefs.hasAnyKey() && Perms.missing(this).none { it.endsWith("RECORD_AUDIO") }) maybeStart() }
    override fun onPause() { super.onPause(); pipeline.stopListening() }
    override fun onDestroy() { promptHandler.removeCallbacks(promptRunnable); pipeline.release(); super.onDestroy() }

    // ---------------- PipelineUi ----------------
    override fun onState(s: State) = runOnUiThread {
        orb.state = s
        status.text = when (s) { State.LISTENING -> "আমি শুনছি, বলো 🎙️"; State.RECORDING -> "শুনছি..."; State.THINKING -> "ভাবছি..."; State.SPEAKING -> "বলছি..."; State.IDLE -> "START MYRA চাপো 🎤" }
        if (s == State.LISTENING || s == State.RECORDING) caption.text = ""
        redOverlay.animate().alpha(if (s == State.IDLE) 0f else 0.08f).setDuration(if (s == State.IDLE) 500 else 300).start()
    }
    override fun onAmplitude(a: Float) { orb.amp = a }
    override fun onCaption(t: String) = runOnUiThread { caption.text = t }
    override fun onUserMessage(t: String) = runOnUiThread { bubble(t, true); Prefs.addHistory("তুমি: $t") }
    override fun onMyraMessage(t: String) = runOnUiThread { bubble(t, false); Prefs.addHistory("MYRA: $t") }
    override fun onError(msg: String) = runOnUiThread { bubble("⚠ $msg", false) }
    override fun onCode(lang: String, code: String) = runOnUiThread { codeCard(lang, code) }

    override suspend fun confirm(msg: String): Boolean = suspendCancellableCoroutine { cont ->
        runOnUiThread {
            val d = AlertDialog.Builder(this).setMessage(msg)
                .setPositiveButton("Haan") { _, _ -> if (cont.isActive) cont.resume(true) }
                .setNegativeButton("Nahi") { _, _ -> if (cont.isActive) cont.resume(false) }
                .setOnCancelListener { if (cont.isActive) cont.resume(false) }.create()
            d.show(); cont.invokeOnCancellation { runOnUiThread { d.dismiss() } }
        }
    }

    // ---------------- chat views ----------------
    private fun addToChat(v: View, gravity: Int) {
        chat.addView(v, LinearLayout.LayoutParams(-2, -2).apply { this.gravity = gravity; topMargin = dp(6) })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun bubble(t: String, user: Boolean) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (!user) {
            // header: avatar + name + time
            val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, dp(4)) }
            head.addView(tv("🪐", 20f).apply { setPadding(0, 0, dp(6), 0) })
            head.addView(tv(Prefs.appName.uppercase(), 13f, C.text, true).apply { setPadding(0, 0, dp(8), 0) })
            val time = java.text.SimpleDateFormat("h:mm a", java.util.Locale.US).format(java.util.Date())
            head.addView(tv(time, 11f, C.hint))
            wrap.addView(head)
        }
        val v = tv(t, 14f).apply {
            setPadding(dp(12), dp(8), dp(12), dp(8)); maxWidth = dp(290); setTextIsSelectable(true)
            background = if (user) round(C.user, 16, C.red) else round(0xFF2A1B4E.toInt(), 16, 0xFF9D4EDD.toInt())
            if (!user) setTextColor(0xFFE8D5FF.toInt())
        }
        wrap.addView(v)
        if (!user) {
            // action row: copy / play / like / dislike / share
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, 0) }
            fun act(icon: String, fn: () -> Unit) {
                row.addView(tv(icon, 16f, C.hint).apply { setPadding(dp(8), dp(4), dp(8), dp(4)); setOnClickListener { fn() } })
            }
            act("📋") { copyText(t); Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show() }
            act("▶️") { pipeline.say(t) }
            act("👍") { Toast.makeText(this, "❤️", Toast.LENGTH_SHORT).show() }
            act("👎") { Toast.makeText(this, "Noted", Toast.LENGTH_SHORT).show() }
            act("📤") { shareText(t) }
            wrap.addView(row)
        }
        addToChat(wrap, if (user) Gravity.END else Gravity.START)
    }

    private fun copyText(t: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
            .setPrimaryClip(android.content.ClipData.newPlainText("myra", t))
    }
    private fun shareText(t: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, t)
        }, "Share"))
    }

    private fun codeCard(lang: String, code: String) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(0xFF0B0B0B.toInt(), 12, 0xFF2A2A2A.toInt()); setPadding(dp(10), dp(8), dp(10), dp(8)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("</> $lang  •  ${code.lines().size} lines", 12f, C.ok, true), LinearLayout.LayoutParams(0, -2, 1f))
        val name = edit("file name", "myra_code.${FileSaver.ext(lang)}").apply { textSize = 12f; setPadding(dp(8), dp(4), dp(8), dp(4)); setSingleLine() }
        head.addView(name, LinearLayout.LayoutParams(dp(150), -2))
        card.addView(head)
        val body = tv(code, 12f, 0xFFCFE8CF.toInt()).apply { typeface = Typeface.MONOSPACE; setTextIsSelectable(true); maxLines = 12; setPadding(0, dp(8), 0, dp(8)) }
        card.addView(body)
        val row = LinearLayout(this)
        fun fn() = name.text.toString().trim().ifBlank { "myra_code.${FileSaver.ext(lang)}" }
        fun saved(f: () -> String) { try { Toast.makeText(this, "Saved: ${f()}", Toast.LENGTH_LONG).show() } catch (e: Exception) { Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show() } }
        var expanded = false
        val buttons = listOf(
            "Expand" to { expanded = !expanded; body.maxLines = if (expanded) Int.MAX_VALUE else 12 },
            "Copy" to { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("code", code)); Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show() },
            "File" to { saved { FileSaver.save(this, fn(), "text/plain", code.toByteArray()) } },
            "TXT" to { saved { FileSaver.save(this, fn().substringBeforeLast('.') + ".txt", "text/plain", code.toByteArray()) } },
            "PDF" to { saved { FileSaver.save(this, fn().substringBeforeLast('.') + ".pdf", "application/pdf", FileSaver.pdf(code)) } },
            "Share" to { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, code), "Share code")) },
            "Fix" to { pipeline.sendText("Review this $lang code very carefully for syntax errors, bugs, missing imports and wrong API usage. Return the full corrected code in one block and say what you changed.\n```$lang\n$code\n```", "🔧 Review & fix code", true) }
        )
        buttons.forEachIndexed { i, (label, action) ->
            val b = tv(label, 12f, C.text, true).apply { setPadding(dp(10), dp(6), dp(10), dp(6)); background = round(C.card, 8, C.red); setOnClickListener {
                action(); if (label == "Expand") (this as TextView).text = if (expanded) "Collapse" else "Expand" } }
            row.addView(b, LinearLayout.LayoutParams(-2, -2).apply { if (i > 0) leftMargin = dp(6) })
        }
        card.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        chat.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }
}
