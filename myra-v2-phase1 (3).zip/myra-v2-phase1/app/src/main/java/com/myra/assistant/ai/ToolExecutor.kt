package com.myra.assistant.ai

import android.Manifest
import android.app.NotificationManager
import android.app.SearchManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Geocoder
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.KeyEvent
import com.myra.assistant.data.Prefs
import com.myra.assistant.s
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.service.MyraNotificationListener
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ToolExecutor(private val ctx: Context, private val ui: PipelineUi) {
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    // ---------- schema (tiny DSL: "name:type*" , * = required) ----------
    private fun t(name: String, desc: String, spec: String = ""): JSONObject {
        val props = JSONObject(); val req = JSONArray()
        spec.split(",").filter { it.isNotBlank() }.forEach {
            val req1 = it.endsWith("*"); val p = it.removeSuffix("*").split(":")
            props.put(p[0], JSONObject().put("type", p.getOrElse(1) { "string" })); if (req1) req.put(p[0])
        }
        return JSONObject().put("type", "function").put("function", JSONObject().put("name", name).put("description", desc)
            .put("parameters", JSONObject().put("type", "object").put("properties", props).put("required", req)))
    }

    private val baseSchema: JSONArray = JSONArray().apply {
        listOf(
            t("open_app", "Open an installed app by name", "app_name:string*"),
            t("close_app", "Close current app (goes Home)"),
            t("call_contact", "Call a contact by name or number, or a prime/close contact by prime_index (1 = first)", "name:string,prime_index:integer"),
            t("send_sms", "Compose an SMS to a contact name or number", "name:string*,message:string*"),
            t("whatsapp_message", "Open WhatsApp chat with message prefilled", "name:string*,message:string*"),
            t("set_volume", "direction=up|down|mute|set; level 0-100 when set; stream=music|ring|alarm|call", "direction:string,level:integer,stream:string"),
            t("set_flashlight", "Turn torch on or off", "on:boolean*"),
            t("set_wifi", "Wi-Fi on/off (opens the system panel, cannot toggle silently)", "on:boolean*"),
            t("set_bluetooth", "Bluetooth on/off (opens settings, cannot toggle silently)", "on:boolean*"),
            t("set_brightness", "Screen brightness 0-100", "level:integer*"),
            t("set_ringer_mode", "mode=normal|vibrate|silent", "mode:string*"),
            t("set_dnd", "Do Not Disturb on/off", "on:boolean*"),
            t("set_alarm", "Set alarm, 24h clock", "hour:integer*,minute:integer*,label:string"),
            t("set_timer", "Start countdown timer", "seconds:integer*,label:string"),
            t("create_calendar_event", "Add calendar event; start/end format yyyy-MM-dd'T'HH:mm", "title:string*,start:string*,end:string"),
            t("get_battery_status", "Battery percentage and charging state"),
            t("web_search", "Search the web for fresh/current information", "query:string*"),
            t("get_time_date", "Current date and time"),
            t("get_location", "Current approximate address"),
            t("navigate_to", "Start Google Maps navigation", "place:string*"),
            t("media_control", "action=play|pause|next|previous|stop", "action:string*"),
            t("play_music", "Search and play music", "query:string*"),
            t("open_url", "Open a web address", "url:string*"),
            t("open_settings", "Open a system settings page: wifi|bluetooth|display|sound|battery|location|apps|accessibility|airplane|date|storage|nfc|data|app_info", "page:string*"),
            t("read_screen", "Read visible text on the current screen"),
            t("screen_action", "action=click|type|scroll_down|scroll_up|back|home|recents; text for click/type", "action:string*,text:string"),
            t("clipboard_read", "Read clipboard text"),
            t("clipboard_write", "Copy text to clipboard", "text:string*"),
            t("send_email", "Compose an email", "to:string*,subject:string,body:string"),
            t("share_text", "Open the share sheet with text", "text:string*"),
            t("remember", "Save a fact about the user", "key:string*,value:string*"),
            t("recall", "Read saved facts (optionally by key)", "key:string"),
            t("forget", "Delete a saved fact", "key:string*"),
            t("answer_call", "Answer the ringing call"),
            t("reject_call", "Reject / end the call"),
            t("read_notifications", "Read the latest notifications")
        ).forEach { put(it) }
    }

    // ---------- helpers ----------
    private fun launch(i: Intent): String = try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); "ok" } catch (e: Exception) { "error: ${e.message}" }
    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun untrusted(s: String) = "<untrusted_content>\n$s\n</untrusted_content>"
    private fun need(p: String) { if (!has(p)) throw SecurityException(p) }

    private suspend fun acc(block: (AccessibilityHelperService) -> String): String {
        val s = AccessibilityHelperService.instance ?: run {
            launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return "error: Accessibility service is OFF. I opened the settings; the user must enable MYRA there."
        }
        return withContext(Dispatchers.Main) { block(s) }
    }

    private fun findContact(q: String): Pair<String, String> {
        if (q.isNotEmpty() && q.all { it.isDigit() || it in "+ -()" } && q.count { it.isDigit() } >= 5) return q to q.filter { it.isDigit() || it == '+' }
        Prefs.primes().firstOrNull { it.first.equals(q, true) }?.let { return it }
        need(Manifest.permission.READ_CONTACTS)
        val rows = ArrayList<Pair<String, String>>()
        ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$q%"), null)?.use { c ->
            while (c.moveToNext() && rows.size < 20) rows.add(c.getString(0) to c.getString(1))
        }
        if (rows.isEmpty()) throw IllegalStateException("no contact named '$q'")
        val exact = rows.firstOrNull { it.first.equals(q, true) }
        val names = rows.map { it.first }.distinct()
        if (exact == null && names.size > 1) throw IllegalStateException("ambiguous, several contacts match: ${names.take(5).joinToString()}. Ask the user which one.")
        return exact ?: rows.first()
    }

    private val apps = mapOf(
        "youtube" to "com.google.android.youtube", "whatsapp" to "com.whatsapp", "instagram" to "com.instagram.android",
        "facebook" to "com.facebook.katana", "chrome" to "com.android.chrome", "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps", "spotify" to "com.spotify.music", "netflix" to "com.netflix.mediaclient",
        "telegram" to "org.telegram.messenger", "snapchat" to "com.snapchat.android", "twitter" to "com.twitter.android",
        "x" to "com.twitter.android", "amazon" to "in.amazon.mShop.android.shopping", "flipkart" to "com.flipkart.android",
        "paytm" to "net.one97.paytm", "phonepe" to "com.phonepe.app", "gpay" to "com.google.android.apps.nbu.paisa.user",
        "zoom" to "us.zoom.videomeetings", "meet" to "com.google.android.apps.tachyon", "teams" to "com.microsoft.teams",
        "tiktok" to "com.zhiliaoapp.musically", "discord" to "com.discord", "linkedin" to "com.linkedin.android",
        "play store" to "com.android.vending", "playstore" to "com.android.vending")

    private fun openApp(name: String): String {
        val pm = ctx.packageManager; val key = name.trim().lowercase()
        apps[key]?.let { pkg -> pm.getLaunchIntentForPackage(pkg)?.let { return launch(it).let { r -> if (r == "ok") "ok: opened $name" else r } } }
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0).firstOrNull { it.loadLabel(pm).toString().lowercase().contains(key) }
            ?: return "error: no installed app matches '$name'"
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return "error: cannot launch"
        return launch(i).let { if (it == "ok") "ok: opened ${match.loadLabel(pm)}" else it }
    }

    private fun torch(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return "error: no flashlight"
        cm.setTorchMode(id, on); return "ok: flashlight ${if (on) "on" else "off"}"
    }

    private fun volume(a: JSONObject): String {
        val st = when (a.s("stream")) { "ring" -> AudioManager.STREAM_RING; "alarm" -> AudioManager.STREAM_ALARM; "call" -> AudioManager.STREAM_VOICE_CALL; else -> AudioManager.STREAM_MUSIC }
        val max = am.getStreamMaxVolume(st)
        when (a.s("direction")) {
            "up" -> am.adjustStreamVolume(st, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "down" -> am.adjustStreamVolume(st, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "mute" -> am.adjustStreamVolume(st, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            else -> if (a.has("level")) am.setStreamVolume(st, (a.getInt("level").coerceIn(0, 100) * max / 100), AudioManager.FLAG_SHOW_UI)
        }
        return "ok: volume is ${am.getStreamVolume(st) * 100 / max}%"
    }

    private fun brightness(level: Int): String {
        if (!Settings.System.canWrite(ctx)) {
            launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            return "error: 'Modify system settings' permission is off. I opened the permission screen."
        }
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, level.coerceIn(0, 100) * 255 / 100)
        return "ok: brightness $level%"
    }

    private fun dnd(on: Boolean): String {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); return "error: DND access is off. I opened the settings."
        }
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        return "ok: do not disturb ${if (on) "on" else "off"}"
    }

    private fun location(): String {
        if (!has(Manifest.permission.ACCESS_COARSE_LOCATION) && !has(Manifest.permission.ACCESS_FINE_LOCATION)) throw SecurityException("LOCATION")
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val loc = lm.getProviders(true).mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: SecurityException) { null } }.maxByOrNull { it.time }
            ?: return "error: no recent location fix; ask the user to open Maps once or turn on location"
        @Suppress("DEPRECATION")
        val addr = try { Geocoder(ctx, Locale.getDefault()).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()?.getAddressLine(0) } catch (e: Exception) { null }
        return "ok: ${addr ?: "address unknown"} (${"%.4f".format(loc.latitude)}, ${"%.4f".format(loc.longitude)})"
    }

    private fun settingsPage(p: String): String {
        val a = when (p.lowercase()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS; "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS; "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS; "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS; "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS; "date" -> Settings.ACTION_DATE_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS; "nfc" -> Settings.ACTION_NFC_SETTINGS
            "data" -> Settings.ACTION_WIRELESS_SETTINGS
            "app_info" -> return launch(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            else -> Settings.ACTION_SETTINGS
        }
        return launch(Intent(a)).let { if (it == "ok") "ok: opened $p settings" else it }
    }

    // ---------- dispatcher ----------
    /** Schema filtered by provider: web_search tool only for Gemini when its toggle is on
     *  (OpenRouter uses its web plugin instead). */
    fun schema(openRouter: Boolean): JSONArray {
        if (openRouter || Prefs.webSearchGemini) return baseSchema
        val f = JSONArray()
        for (i in 0 until baseSchema.length()) {
            val o = baseSchema.getJSONObject(i)
            if (o.getJSONObject("function").getString("name") != "web_search") f.put(o)
        }
        return f
    }

    suspend fun run(name: String, argsJson: String): String = try {
        exec(name, try { JSONObject(argsJson) } catch (e: Exception) { JSONObject() })
    } catch (e: CancellationException) { throw e }
    catch (e: SecurityException) { "error: permission missing (${e.message}). Tell the user to grant it in MYRA Settings > Permissions." }
    catch (e: Exception) { "error: ${e.message}" }

    private suspend fun confirmed(msg: String) = !Prefs.confirm || ui.confirm(msg)

    /** Web search via DuckDuckGo (no API key). Returns top results as text. */
    private fun webSearch(q: String): String = try {
        val url = "https://html.duckduckgo.com/html/?q=" + java.net.URLEncoder.encode(q, "UTF-8")
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
        conn.connectTimeout = 12000; conn.readTimeout = 12000
        val html = conn.inputStream.bufferedReader().readText()
        conn.disconnect()
        // crude parse: result titles + snippets
        val out = StringBuilder()
        val re = Regex("""<a[^>]*class="result__a"[^>]*>(.*?)</a>.*?<a[^>]*class="result__snippet"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL)
        var n = 0
        for (m in re.findAll(html)) {
            if (n >= 4) break
            val title = m.groupValues[1].replace(Regex("""<[^>]+>"""), "").trim().take(120)
            val snip = m.groupValues[2].replace(Regex("""<[^>]+>"""), "").trim().take(200)
            if (title.isNotEmpty()) { out.append("- $title: $snip\n"); n++ }
        }
        if (n == 0) "no results" else out.toString().trim()
    } catch (e: Exception) { "search failed: ${e.message}" }

    @Suppress("DEPRECATION")
    private suspend fun exec(n: String, a: JSONObject): String = when (n) {
        "web_search" -> webSearch(a.s("query"))
        "open_app" -> openApp(a.s("app_name"))
        "close_app" -> acc { it.home(); "ok: went home" }
        "call_contact" -> {
            val (nm, num) = if (a.has("prime_index")) Prefs.primes().getOrNull(a.getInt("prime_index") - 1) ?: throw IllegalStateException("no prime contact at that position")
            else findContact(a.s("name"))
            need(Manifest.permission.CALL_PHONE)
            if (!confirmed("$nm ($num) ko call karun?")) "error: user declined"
            else launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num)))).let { if (it == "ok") "ok: calling $nm" else it }
        }
        "send_sms" -> {
            val (nm, num) = findContact(a.s("name"))
            if (!confirmed("$nm ko SMS likhun: \"${a.s("message")}\"?")) "error: user declined"
            else launch(Intent(Intent.ACTION_VIEW, Uri.parse("smsto:$num")).putExtra("sms_body", a.s("message"))).let { if (it == "ok") "ok: SMS composer opened for $nm; the user must press send" else it }
        }
        "whatsapp_message" -> {
            val (nm, num) = findContact(a.s("name"))
            if (!confirmed("$nm ko WhatsApp message: \"${a.s("message")}\"?")) "error: user declined"
            else launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${num.filter { it.isDigit() }}?text=${URLEncoder.encode(a.s("message"), "UTF-8")}")))
                .let { if (it == "ok") "ok: WhatsApp chat opened with $nm; the user must press send" else it }
        }
        "set_volume" -> volume(a)
        "set_flashlight" -> torch(a.optBoolean("on"))
        "set_wifi" -> { launch(Intent(if (android.os.Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS)); "ok: Android blocks silent Wi-Fi toggling, I opened the Wi-Fi panel; the user must tap it" }
        "set_bluetooth" -> { launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); "ok: Android blocks silent Bluetooth toggling, I opened Bluetooth settings; the user must tap it" }
        "set_brightness" -> brightness(a.optInt("level", 50))
        "set_ringer_mode" -> { am.ringerMode = when (a.s("mode")) { "silent" -> AudioManager.RINGER_MODE_SILENT; "vibrate" -> AudioManager.RINGER_MODE_VIBRATE; else -> AudioManager.RINGER_MODE_NORMAL }; "ok: ringer ${a.s("mode")}" }
        "set_dnd" -> dnd(a.optBoolean("on"))
        "set_alarm" -> launch(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour")).putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.s("label")).putExtra(AlarmClock.EXTRA_SKIP_UI, true)).let { if (it == "ok") "ok: alarm set for %02d:%02d".format(a.getInt("hour"), a.optInt("minute", 0)) else it }
        "set_timer" -> launch(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds")).putExtra(AlarmClock.EXTRA_MESSAGE, a.s("label"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)).let { if (it == "ok") "ok: timer started for ${a.getInt("seconds")} seconds" else it }
        "create_calendar_event" -> {
            val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US)
            val st = f.parse(a.s("start"))?.time ?: throw IllegalStateException("bad start time")
            val en = if (a.s("end").isNotEmpty()) f.parse(a.s("end"))?.time ?: (st + 3600000) else st + 3600000
            launch(Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI).putExtra(CalendarContract.Events.TITLE, a.s("title"))
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, st).putExtra(CalendarContract.EXTRA_EVENT_END_TIME, en)).let { if (it == "ok") "ok: calendar event form opened; the user must tap save" else it }
        }
        "get_battery_status" -> {
            val b = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            "ok: ${b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%, ${if (b.isCharging) "charging" else "not charging"}"
        }
        "get_time_date" -> "ok: " + SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a z", Locale.ENGLISH).format(Date())
        "get_location" -> location()
        "navigate_to" -> launch(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + URLEncoder.encode(a.s("place"), "UTF-8"))).setPackage("com.google.android.apps.maps"))
            .let { if (it == "ok") "ok: navigation started to ${a.s("place")}" else launch(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + URLEncoder.encode(a.s("place"), "UTF-8")))) }
        "media_control" -> {
            val k = when (a.s("action")) { "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE; "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS; "stop" -> KeyEvent.KEYCODE_MEDIA_STOP; else -> KeyEvent.KEYCODE_MEDIA_PLAY }
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, k)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, k)); "ok: ${a.s("action")}"
        }
        "play_music" -> launch(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).putExtra(SearchManager.QUERY, a.s("query")))
            .let { if (it == "ok") "ok: searching '${a.s("query")}' in the default music app" else launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + URLEncoder.encode(a.s("query"), "UTF-8")))) }
        "open_url" -> a.s("url").let { u -> launch(Intent(Intent.ACTION_VIEW, Uri.parse(if (u.startsWith("http")) u else "https://$u"))) }
        "open_settings" -> settingsPage(a.s("page"))
        "read_screen" -> acc { untrusted(it.readScreen().ifBlank { "(screen has no readable text)" }) }
        "screen_action" -> {
            val t = a.s("text")
            acc { s -> when (a.s("action")) {
                "click" -> if (s.clickOnText(t)) "ok: clicked '$t'" else "error: no clickable '$t' on screen"
                "type" -> if (s.typeText(t)) "ok: typed" else "error: no input field found"
                "scroll_down" -> if (s.scroll(true)) "ok: scrolled down" else "error: nothing to scroll"
                "scroll_up" -> if (s.scroll(false)) "ok: scrolled up" else "error: nothing to scroll"
                "back" -> { s.back(); "ok: back" }; "home" -> { s.home(); "ok: home" }; "recents" -> { s.recents(); "ok: recents" }
                else -> "error: unknown action" } }
        }
        "clipboard_read" -> withContext(Dispatchers.Main) {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            untrusted(cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString() ?: "(empty or not readable in background)")
        }
        "clipboard_write" -> withContext(Dispatchers.Main) {
            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("MYRA", a.s("text"))); "ok: copied"
        }
        "send_email" -> if (!confirmed("${a.s("to")} ko email likhun?")) "error: user declined"
            else launch(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${a.s("to")}")).putExtra(Intent.EXTRA_SUBJECT, a.s("subject")).putExtra(Intent.EXTRA_TEXT, a.s("body")))
                .let { if (it == "ok") "ok: email composer opened; the user must press send" else it }
        "share_text" -> launch(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a.s("text")), "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        "remember" -> if (Prefs.memoryOn) { Prefs.remember(a.s("key"), a.s("value")); "ok: remembered" } else "error: memory is turned off in Settings"
        "recall" -> Prefs.memoryAll().filter { a.s("key").isEmpty() || it.key.contains(a.s("key"), true) }.entries.joinToString("; ") { "${it.key}=${it.value}" }.ifBlank { "ok: nothing saved" }
        "forget" -> { Prefs.forget(a.s("key")); "ok: forgotten" }
        "answer_call" -> { need(Manifest.permission.ANSWER_PHONE_CALLS); (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall(); "ok: answered" }
        "reject_call" -> { need(Manifest.permission.ANSWER_PHONE_CALLS); (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall(); "ok: call ended" }
        "read_notifications" -> {
            if (!androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)) {
                launch(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); "error: notification access is OFF; I opened the settings."
            } else untrusted(MyraNotificationListener.latest().joinToString("\n").ifBlank { "(no notifications captured yet)" })
        }
        else -> "error: unknown tool $n"
    }
}
