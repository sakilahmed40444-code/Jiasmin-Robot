package com.lia.assistant.brain

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** OpenRouter — Gemini na ho to dusra LLM brain. */
object OpenRouterClient {
    @Throws(Exception::class)
    fun chat(
        apiKey: String,
        model: String,
        system: String,
        history: List<Pair<Boolean, String>>,
        userText: String
    ): String {
        if (apiKey.isBlank()) throw Exception("no-key")
        val url = URL("https://openrouter.ai/api/v1/chat/completions")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer $apiKey")
            c.setRequestProperty("HTTP-Referer", "https://lia.app")
            c.setRequestProperty("X-Title", "LIA")
            c.doOutput = true
            c.connectTimeout = 20000
            c.readTimeout = 30000

            val msgs = JSONArray()
            msgs.put(JSONObject().put("role", "system").put("content", system))
            for ((isUser, t) in history.takeLast(10)) {
                msgs.put(JSONObject().put("role", if (isUser) "user" else "assistant").put("content", t))
            }
            msgs.put(JSONObject().put("role", "user").put("content", userText))
            val body = JSONObject()
                .put("model", model)
                .put("messages", msgs)
                .put("max_tokens", 300)
                .put("temperature", 0.9)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
            val j = JSONObject(txt)
            if (j.has("error")) throw Exception(j.optJSONObject("error")?.optString("message", "API error"))
            val out = j.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "").trim()
            if (out.isEmpty()) throw Exception("empty reply")
            return out
        } finally {
            c.disconnect()
        }
    }
}
