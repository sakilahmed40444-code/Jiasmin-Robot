import React from "react";
import { VOICE_MODELS, VoiceModelId } from "../config";

type Props = {
  value: VoiceModelId;
  onChange: (model: VoiceModelId) => void;
  open: boolean;
  onClose: () => void;
};

export function VoiceModelSelector({ value, onChange, open, onClose }: Props) {
  if (!open) return null;

  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="model-sheet" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-handle" />
        <div className="sheet-title">Voice model</div>

        <div className="model-list">
          {VOICE_MODELS.map((model) => (
            <button
              key={model.id}
              className="model-option"
              onClick={() => {
                onChange(model.id);
                onClose();
              }}
            >
              <div>
                <div className="model-name">{model.label}</div>
                <div className="model-subtitle">{model.subtitle}</div>
              </div>
              {value === model.id && <span className="check">✓</span>}
            </button>
          ))}
        </div>

        <button className="close-sheet" onClick={onClose}>Close</button>
      </div>
    </div>
  );
}