package com.lia.assistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import com.lia.assistant.ui.MainActivity

/**
 * Power button double-press (600ms) → Priya kholo + voice shuru.
 * MYRA feature. VoiceLoopService me dynamically register hota hai.
 */
class PowerButtonReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        val a = intent.action
        if (a != Intent.ACTION_SCREEN_OFF && a != Intent.ACTION_SCREEN_ON) return
        val prefs = com.lia.assistant.data.Prefs(ctx)
        if (!prefs.powerDoubleTap) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastPress < 600) {
            lastPress = 0
            try {
                val i = Intent(ctx, MainActivity::class.java)
                    .putExtra("tab", MainActivity.TAB_HOME)
                    .putExtra("autostart", true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                ctx.startActivity(i)
            } catch (_: Exception) { }
        } else {
            lastPress = now
        }
    }

    companion object {
        @Volatile private var lastPress = 0L
    }
}
