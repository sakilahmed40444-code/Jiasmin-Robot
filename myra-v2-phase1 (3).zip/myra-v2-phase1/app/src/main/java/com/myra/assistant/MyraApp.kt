package com.myra.assistant

import android.app.Application
import android.util.Log
import com.myra.assistant.data.Prefs
import org.json.JSONObject
import java.io.File
import java.util.Date

class MyraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Crash catcher: save the stack trace so the real cause can be seen on next launch.
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                File(filesDir, "crash.txt").writeText("${Date()}\n${Log.getStackTraceString(e)}")
            } catch (_: Exception) {}
            prev?.uncaughtException(t, e)
        }
        Prefs.init(this)
    }
}

/** Null-safe string read (org.json returns "null" for JSON null). */
fun JSONObject.s(k: String): String = if (isNull(k)) "" else optString(k, "")
