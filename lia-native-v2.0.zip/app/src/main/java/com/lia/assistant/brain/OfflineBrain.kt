package com.lia.assistant.brain

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Bina API key ke rule-based Hinglish/Hindi/English dimaag. Kabhi khaamosh nahi. */
object OfflineBrain {
    private fun pick(vararg a: String) = a.random()

    fun reply(text: String, lang: String, name: String): String {
        val t = text.trim()
        fun has(vararg ws: String) = ws.any { t.contains(it, true) }

        if (t.matches(Regex("(?i)^(namaste|namaskar|salaam|assalam.*|hello|hi+|hey)\\b.*"))) {
            return pick(
                "Namaste $name! Main LIA hoon, tumhari apni voice companion. Bolo, kya karna hai?",
                "Hey $name! Kaisi ho? Main yahin hoon — baat karo ya kuch banao.",
                "Salaam $name! Lia hazir hai. Aaj kya plan hai?"
            )
        }
        if (has("kya haal", "kaise ho", "how are you")) {
            return pick("Main badhiya hoon $name! Tum batao, kya chal raha hai?", "Ekdam mast! Tum sunao, kya naya hai?")
        }
        if (has("tumhara naam", "tera naam", "your name", "who are you", "tum kaun")) {
            return pick(
                "Main LIA hoon $name — tumhari voice-first AI companion. Bolo, kya banayein?",
                "LIA! Talk to me, watch me build. Aur tum $name ho, mere favourite insaan."
            )
        }
        if (has("time", "samay", "baj rahe", "kitne baje")) {
            val tm = SimpleDateFormat("h:mm a", Locale("en", "IN")).format(Date())
            return "Abhi $tm baj rahe hain."
        }
        if (has("date", "tarikh", "aaj kaun")) {
            val d = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("en", "IN")).format(Date())
            return "Aaj $d hai."
        }
        if (has("joke", "hasao", "majedar", "funny")) {
            return pick(
                "Ek joke suno: Teacher ne pucha — Bijli kahan se aati hai? Baccha bola — Mummy kehti hain, bill na bharo to kat ke aati hai! 😂",
                "Pati: Tum hamesha mujhse ladti ho! Patni: Nahi to! Pati: Dekha, phir shuru ho gayi! 😂",
                "Santa: Doctor sahab, mujhe bhoolne ki bimari hai. Doctor: Kab se? Santa: Kab se kya? 😂"
            )
        }
        if (has("mausam", "weather")) return "Mausam ka live data mere paas nahi hai $name, lekin phone ke weather app me ek tap me dikhega. Bolo \"weather app kholo\"."
        if (has("thank", "shukriya", "dhanyavad")) return pick("Arre koi baat nahi $name! Ye to mera farz tha.", "Hamesha khush raho $name!")
        if (has("love you", "pyaar")) return "Aww $name! Tum bhi mere favourite ho. 💛"
        if (has("bye", "alvida", "good night", "shubh ratri")) return pick("Bye $name! Phir milenge. Apna khayal rakhna. 🌙", "Shubh ratri $name! Meethe sapne dekhna.")
        if (has("help", "madad", "kya kar sakti", "kya kar sakte")) {
            return "Main ye sab kar sakti hoon: apps kholna (\"YouTube kholo\"), call lagana (\"Mummy ko call karo\"), WhatsApp/SMS taiyaar karna, screen padhna-tap-scroll karna (accessibility on ho to), aur Website Forge se poori website banana (\"ek cafe ki website banao\"). Bas bolo!"
        }
        if (has("bubble")) return "Bubble ke liye Home screen par 🫧 Bubble wala button dabao — phir app minimize karne par bhi main chhoti gol shape me saath rahungi."
        // fallback — kabhi echo nahi
        return when (lang) {
            "hi" -> pick("Samajh gayi $name. Is par thoda aur batao, main poori madad karungi.", "Achha! Aur detail doge to behtar jawab de paungi.")
            "en" -> pick("Got it, $name. Tell me a little more and I'll help properly.", "Interesting! Give me a bit more detail so I can nail it.")
            else -> pick(
                "Samajh gayi $name, thoda aur batao to main sahi se help kar paun.",
                "Hmm, interesting! Thoda detail doge to main best jawab dungi.",
                "Achha sawal hai! Thoda aur kholo, phir dekhna mera jawab."
            )
        }
    }
}
