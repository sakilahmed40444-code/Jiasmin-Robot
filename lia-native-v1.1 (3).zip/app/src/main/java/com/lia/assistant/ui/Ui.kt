package com.lia.assistant.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextView
import com.google.android.material.card.MaterialCardView

object Ui {
    const val BG = "#06050E"
    const val SURFACE = "#17143A"
    const val RAISED = "#221E4D"
    const val ACCENT = "#FFB547"
    const val TEXT = "#EEE9FF"
    const val TEXT2 = "#A7A0CC"
    const val TEXT3 = "#6E6796"
    const val LAGOON = "#3FE0D0"
    const val ERROR = "#FF7A85"

    fun dp(c: Context, n: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, n.toFloat(), c.resources.displayMetrics).toInt()

    fun sp(c: Context, n: Int): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, n.toFloat(), c.resources.displayMetrics)

    fun col(s: String) = Color.parseColor(s)

    fun scrollCol(c: Context): ScrollView {
        val sv = ScrollView(c)
        sv.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        sv.isFillViewport = true
        sv.setBackgroundColor(col(BG))
        return sv
    }

    fun colLayout(c: Context, pad: Int = 16): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        val p = dp(c, pad)
        l.setPadding(p, p, p, dp(c, 90))
        l.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        return l
    }

    fun tv(c: Context, text: String, size: Int = 15, color: String = TEXT, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = text; t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size.toFloat())
        t.setTextColor(col(color))
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    fun title(c: Context, text: String): TextView {
        val t = tv(c, text, 28, TEXT, true)
        t.setPadding(0, dp(c, 8), 0, dp(c, 4))
        return t
    }

    fun sub(c: Context, text: String): TextView {
        val t = tv(c, text, 14, TEXT2)
        t.setPadding(0, 0, 0, dp(c, 12))
        return t
    }

    fun sec(c: Context, text: String): TextView {
        val t = tv(c, text.uppercase(), 12, TEXT3, true)
        t.setPadding(0, dp(c, 16), 0, dp(c, 8))
        return t
    }

    fun card(c: Context): MaterialCardView {
        val m = MaterialCardView(c)
        m.setCardBackgroundColor(col(SURFACE))
        m.strokeColor = col("#2A2560"); m.strokeWidth = dp(c, 1)
        m.radius = dp(c, 20).toFloat()
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.bottomMargin = dp(c, 10)
        m.layoutParams = p
        m.setContentPadding(dp(c, 16), dp(c, 16), dp(c, 16), dp(c, 16))
        return m
    }

    fun btn(c: Context, text: String, primary: Boolean = true, onClick: () -> Unit): Button {
        val b = Button(c, null, android.R.attr.buttonStyle)
        b.text = text
        b.setTextColor(col(if (primary) "#221100" else TEXT))
        b.setBackgroundColor(col(if (primary) ACCENT else RAISED))
        b.isAllCaps = false
        b.textSize = 15f
        b.setTypeface(b.typeface, Typeface.BOLD)
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.rightMargin = dp(c, 8); p.bottomMargin = dp(c, 8)
        b.layoutParams = p
        b.minHeight = dp(c, 48)
        b.setOnClickListener { onClick() }
        return b
    }

    fun input(c: Context, hint: String, password: Boolean = false): EditText {
        val e = EditText(c)
        e.hint = hint; e.setHintTextColor(col(TEXT3))
        e.setTextColor(col(TEXT))
        e.setBackgroundColor(col(RAISED))
        e.setPadding(dp(c, 14), dp(c, 13), dp(c, 14), dp(c, 13))
        if (password) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        e.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        return e
    }

    fun row(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        l.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        l.setPadding(0, dp(c, 10), 0, dp(c, 10))
        return l
    }

    fun space(c: Context, h: Int = 8): Space {
        val s = Space(c)
        s.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, h))
        return s
    }

    fun seek(c: Context, max: Int, prog: Int, onChange: (Int) -> Unit): SeekBar {
        val s = SeekBar(c)
        s.max = max; s.progress = prog
        s.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { if (u) onChange(p) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        return s
    }
}
