package com.lia.assistant.call

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Notification theke call dhoro/kato — background-safe (FGS start nahi). */
class CallActionReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        val appCtx = ctx.applicationContext
        when (intent.action) {
            ACTION_ACCEPT -> TelecomHelper.acceptCall(appCtx)
            ACTION_REJECT -> {
                TelecomHelper.rejectCall(appCtx)
                try {
                    val nm = appCtx.getSystemService(Context.NOTIFICATION_SERVICE)
                        as android.app.NotificationManager
                    nm.cancel(CallReceiver.CALL_NOTIF_ID)
                } catch (_: Exception) { }
            }
        }
    }

    companion object {
        const val ACTION_ACCEPT = "com.lia.assistant.CALL_ACCEPT"
        const val ACTION_REJECT = "com.lia.assistant.CALL_REJECT"
    }
}
