package com.lia.assistant.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment

/** Avatar tab — orb style + profile picture. */
class AvatarFragment : Fragment() {
    private fun act() = activity as MainActivity
    private var orb: BubbleView? = null

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val root = ScrollView(ctx).apply { setBackgroundColor(Ui.col(Ui.BG)) }
        val col = Ui.colLayout(ctx)
        root.addView(col)

        col.addView(Ui.tv(ctx, "👤 Avatar", 24, Ui.TEXT, true).apply { gravity = Gravity.CENTER })
        col.addView(Ui.tv(ctx, "Priya ka look chuno", 13, Ui.TEXT2).apply { gravity = Gravity.CENTER })
        col.addView(sp(12))

        orb = BubbleView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 150), Ui.dp(ctx, 150)).apply { gravity = Gravity.CENTER }
            state = BubbleView.State.IDLE
        }
        col.addView(orb)
        col.addView(sp(12))

        col.addView(Ui.tv(ctx, "ORB STYLE", 13, Ui.TEXT2, true))
        val styles = listOf("💗 Pink Neon", "💜 Purple Glow", "💙 Blue Lagoon", "🔥 Fire", "🌊 Aqua")
        val rg = RadioGroup(ctx)
        val cur = act().prefs.avatarStyle
        styles.forEachIndexed { i, name ->
            val rb = RadioButton(ctx).apply {
                text = name; textSize = 15f; setTextColor(Ui.col(Ui.TEXT))
                isChecked = (i == cur)
                setOnCheckedChangeListener { _, on ->
                    if (on) { act().prefs.avatarStyle = i; applyStyle(i); act().toast("Style: $name") }
                }
            }
            rg.addView(rb)
        }
        col.addView(rg)
        col.addView(sp(12))

        col.addView(Ui.tv(ctx, "PROFILE PICTURE", 13, Ui.TEXT2, true))
        col.addView(Ui.btn(ctx, "🖼️ Gallery se chuno", false) { pickImage() })
        col.addView(sp(24))

        applyStyle(cur)
        return root
    }

    private fun applyStyle(i: Int) {
        orb?.state = when (i) {
            1 -> BubbleView.State.THINKING
            2 -> BubbleView.State.LISTENING
            3 -> BubbleView.State.SPEAKING
            4 -> BubbleView.State.ERROR
            else -> BubbleView.State.IDLE
        }
    }

    private fun pickImage() {
        try {
            val i = Intent(Intent.ACTION_PICK).apply { type = "image/*" }
            startActivityForResult(i, 77)
        } catch (_: Exception) { act().toast("Gallery nahi khul rahi") }
    }

    @Deprecated("deprecated")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 77 && res == Activity.RESULT_OK) {
            val uri: Uri? = d?.data
            if (uri != null) {
                try {
                    requireContext().contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) { }
                act().prefs.profilePic = uri.toString()
                act().toast("Profile picture set! 🖼️")
            }
        }
    }

    private fun sp(dp: Int): View {
        val v = View(requireContext())
        v.layoutParams = LinearLayout.LayoutParams(1, Ui.dp(requireContext(), dp))
        return v
    }
}
