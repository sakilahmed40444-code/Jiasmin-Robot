# Myraa Assistant — APK Project

এটা Myraa voice-to-voice AI assistant-এর Android-ready React + Capacitor project।

## গুরুত্বপূর্ণ

Google-এর বর্তমান Gemini documentation অনুযায়ী `gemini-3.8-live` হলো low-latency voice agent-এর default Live API model এবং model ID হলো `gemini-3.8-live`.

এই project-এ default model:
`gemini-3.8-live`

Voice model selector-এ:
- Gemini 3.8 Live
- Gemini 3.8 Live Extended Thinking
- Gemini 3.1 Flash Live

দেওয়া আছে।

## APK বানানোর সবচেয়ে সহজ পদ্ধতি

### পদ্ধতি ১ — Android Studio

1. ZIP extract করুন
2. PC-তে Node.js + Android Studio install করুন
3. Project folder-এ terminal খুলুন
4. চালান:

```bash
npm install
npm run android:add
npx cap open android
```

5. Android Studio খুললে Gradle Sync শেষ হতে দিন
6. তারপর:

`Build > Build App Bundle(s) / APK(s) > Build APK(s)`

Debug APK সাধারণত:
`android/app/build/outputs/apk/debug/app-debug.apk`

### পদ্ধতি ২ — GitHub Actions

এই ZIP GitHub repository-তে upload করুন।

`.github/workflows/build-apk.yml` automatic Android build চালাবে।

Actions শেষ হলে artifact থেকে APK download করা যাবে।

## Gemini API key

App চালু করে:

Settings > Gemini API key

এ আপনার নিজের Gemini API key বসাবেন।

এই version personal testing-এর জন্য direct API key ব্যবহার করে।

Public production app-এ permanent API key APK-এর ভিতরে রাখা নিরাপদ নয়। Production-এর জন্য ephemeral-token backend ব্যবহার করা উচিত।

## Android permission

Myraa microphone ব্যবহার করে। Capacitor Android build-এ microphone permission দরকার।

## Model

বর্তমান official Gemini docs অনুযায়ী:

`gemini-3.8-live`

Live API-এর default low-latency voice model।

Gemini Live API:
- Input: PCM16, 16 kHz
- Output: PCM16, 24 kHz
- Real-time audio streaming
- Interruptions / barge-in
- Function calling
- Audio transcription support

## যদি API error আসে

Settings-এ API key ঠিক আছে কি না দেখুন।

তারপর selected model পরিবর্তন করে আবার connect করুন।

Model IDগুলো `src/config.ts`-এ এক জায়গায় রাখা হয়েছে।
