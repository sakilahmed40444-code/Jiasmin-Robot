#!/usr/bin/env bash
set -e
npm install
npm run android:add
cd android
./gradlew assembleDebug
echo ""
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
