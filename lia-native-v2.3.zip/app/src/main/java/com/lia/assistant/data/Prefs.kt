package com.lia.assistant.data

import android.content.Context
import android.content.SharedPreferences

/** Sab settings sirf phone me — koi server nahi. */
class Prefs(ctx: Context) {
    private val sp: SharedPreferences =
        ctx.getSharedPreferences("lia_prefs", Context.MODE_PRIVATE)

    var name: String
        get() = sp.getString("name", "dost") ?: "dost"
        set(v) = sp.edit().putString("name", v).apply()

    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(v) = sp.edit().putString("apiKey", v).apply()

    var model: String
        get() = sp.getString("model", "gemini-2.0-flash") ?: "gemini-2.0-flash"
        set(v) = sp.edit().putString("model", v).apply()

    var persona: String
        get() = sp.getString("persona", "normal") ?: "normal"
        set(v) = sp.edit().putString("persona", v).apply()

    /** auto / hi / hing / en */
    var langMode: String
        get() = sp.getString("langMode", "bn") ?: "bn"
        set(v) = sp.edit().putString("langMode", v).apply()

    var speechRate: Float
        get() = sp.getFloat("speechRate", 1.0f)
        set(v) = sp.edit().putFloat("speechRate", v).apply()

    var bubbleOn: Boolean
        get() = sp.getBoolean("bubbleOn", true)
        set(v) = sp.edit().putBoolean("bubbleOn", v).apply()

    // ---- v1.1: Zara-style functions ----
    var wakeWord: String
        get() = sp.getString("wakeWord", "hello lia") ?: "hello lia"
        set(v) = sp.edit().putString("wakeWord", v).apply()

    var dismissWord: String
        get() = sp.getString("dismissWord", "bye bye") ?: "bye bye"
        set(v) = sp.edit().putString("dismissWord", v).apply()

    var wakeMode: Boolean
        get() = sp.getBoolean("wakeMode", false)
        set(v) = sp.edit().putBoolean("wakeMode", v).apply()

    var wakeTimeoutSec: Int
        get() = sp.getInt("wakeTimeoutSec", 30)
        set(v) = sp.edit().putInt("wakeTimeoutSec", v).apply()

    /** TTS voice ka naam ("" = default) */
    var ttsVoiceName: String
        get() = sp.getString("ttsVoiceName", "") ?: ""
        set(v) = sp.edit().putString("ttsVoiceName", v).apply()

    /** Custom personality instruction */
    var customPersona: String
        get() = sp.getString("customPersona", "") ?: ""
        set(v) = sp.edit().putString("customPersona", v).apply()

    var openRouterKey: String
        get() = sp.getString("openRouterKey", "") ?: ""
        set(v) = sp.edit().putString("openRouterKey", v).apply()

    var openRouterModel: String
        get() = sp.getString("openRouterModel", "meta-llama/llama-3.1-8b-instruct:free")
            ?: "meta-llama/llama-3.1-8b-instruct:free"
        set(v) = sp.edit().putString("openRouterModel", v).apply()

    var serpKey: String
        get() = sp.getString("serpKey", "") ?: ""
        set(v) = sp.edit().putString("serpKey", v).apply()

    // ---- v2.0: Priya Assistant ----
    var loveMode: Boolean
        get() = sp.getBoolean("loveMode", false)
        set(v) = sp.edit().putBoolean("loveMode", v).apply()

    var coins: Int
        get() = sp.getInt("coins", 100)
        set(v) = sp.edit().putInt("coins", v).apply()

    var lastCoinDay: String
        get() = sp.getString("lastCoinDay", "") ?: ""
        set(v) = sp.edit().putString("lastCoinDay", v).apply()

    /** Gemini TTS voice: Kore, Aoede... ("" = Android TTS) */
    var geminiVoice: String
        get() = sp.getString("geminiVoice", "Kore") ?: "Kore"
        set(v) = sp.edit().putString("geminiVoice", v).apply()

    var email: String
        get() = sp.getString("email", "") ?: ""
        set(v) = sp.edit().putString("email", v).apply()

    var profilePic: String
        get() = sp.getString("profilePic", "") ?: ""
        set(v) = sp.edit().putString("profilePic", v).apply()

    var avatarStyle: Int
        get() = sp.getInt("avatarStyle", 0)
        set(v) = sp.edit().putInt("avatarStyle", v).apply()

    var screenCapGranted: Boolean
        get() = sp.getBoolean("screenCapGranted", false)
        set(v) = sp.edit().putBoolean("screenCapGranted", v).apply()
}
