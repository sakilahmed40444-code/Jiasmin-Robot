package com.lia.assistant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.lia.assistant.R
import com.lia.assistant.action.ActionExecutor
import com.lia.assistant.brain.ConversationMemory
import com.lia.assistant.brain.LiaResponder
import com.lia.assistant.data.Prefs
import com.lia.assistant.service.BubbleService

class MainActivity : AppCompatActivity() {

    companion object {
        const val TAB_HOME = 0
        const val TAB_VOICE = 1
        const val TAB_FORGE = 2
        const val TAB_CHAT = 3
        const val TAB_SETUP = 4
        const val TAB_SETTINGS = 5
    }

    val prefs by lazy { Prefs(this) }
    val mem = ConversationMemory()
    val responder by lazy { LiaResponder(this, prefs, mem) }

    private lateinit var container: FrameLayout
    private lateinit var nav: BottomNavigationView
    private var current = -1
    private val frags = arrayOfNulls<Fragment>(6)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        responder.executor.forgeOpener = object : ActionExecutor.ForgeOpener {
            override fun openForge(subject: String) = runOnUiThread { openForge(subject) }
        }

        container = FrameLayout(this).apply { id = View.generateViewId() }
        nav = BottomNavigationView(this)
        val menu = nav.menu
        menu.add(0, TAB_HOME, 0, "Home").setIcon(android.R.drawable.ic_menu_view)
        menu.add(0, TAB_VOICE, 1, "Voice").setIcon(android.R.drawable.ic_btn_speak_now)
        menu.add(0, TAB_FORGE, 2, "Forge").setIcon(android.R.drawable.ic_menu_compass)
        menu.add(0, TAB_CHAT, 3, "Chat").setIcon(android.R.drawable.ic_menu_send)
        menu.add(0, TAB_SETUP, 4, "Setup").setIcon(android.R.drawable.ic_menu_manage)
        menu.add(0, TAB_SETTINGS, 5, "Settings").setIcon(android.R.drawable.ic_menu_preferences)
        nav.setBackgroundColor(Ui.col(Ui.SURFACE))
        nav.itemTextColor = android.content.res.ColorStateList.valueOf(Ui.col(Ui.TEXT2))
        nav.setOnItemSelectedListener { go(it.itemId); true }

        val lin = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        val cp = android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        container.layoutParams = cp
        lin.addView(container)
        lin.addView(nav, android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT))
        setContentView(lin)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }

        // bubble restore
        if (prefs.bubbleOn && Settings.canDrawOverlays(this)) BubbleService.start(this)

        go(intent.getIntExtra("tab", TAB_HOME))
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.hasExtra("tab")) go(intent.getIntExtra("tab", TAB_VOICE))
    }

    fun go(tab: Int) {
        if (tab == current && frags[tab] != null) return
        current = tab
        nav.selectedItemId = tab
        var f = frags[tab]
        if (f == null) {
            f = when (tab) {
                TAB_HOME -> HomeFragment()
                TAB_VOICE -> VoiceFragment()
                TAB_FORGE -> ForgeFragment()
                TAB_CHAT -> ChatFragment()
                TAB_SETUP -> SetupFragment()
                else -> SettingsFragment()
            }
            frags[tab] = f
        }
        supportFragmentManager.beginTransaction().replace(container.id, f!!).commit()
    }

    fun openForge(subject: String) {
        go(TAB_FORGE)
        (frags[TAB_FORGE] as? ForgeFragment)?.startForge(subject)
    }

    fun sendChatText(t: String) {
        go(TAB_CHAT)
        container.postDelayed({ (frags[TAB_CHAT] as? ChatFragment)?.receiveText(t) }, 300)
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
