package com.myra.assistant.ui

import android.Manifest
import android.animation.ValueAnimator
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.EditText
import android.widget.TextView
import androidx.core.app.NotificationManagerCompat
import com.myra.assistant.ai.State
import com.myra.assistant.service.AccessibilityHelperService
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

object C {
    const val bg = 0xFF050505.toInt(); const val red = 0xFFFF1744.toInt(); const val purple = 0xFFD500F9.toInt()
    const val card = 0xFF111111.toInt(); const val text = 0xFFEEEEEE.toInt(); const val hint = 0xFF777777.toInt()
    const val ok = 0xFF00E676.toInt(); const val user = 0xFF3A0A12.toInt(); const val myra = 0xFF1B1B1B.toInt(); const val cyan = 0xFF40C4FF.toInt()
}

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
/** Rounded gradient bar (pink-purple) for bottom nav */
fun Context.gradientRound(r: Int = 24) = android.graphics.drawable.GradientDrawable(
    android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
    intArrayOf(0xFF6A1B9A.toInt(), 0xFFAD1457.toInt(), 0xFF6A1B9A.toInt())
).apply { cornerRadius = r * resources.displayMetrics.density }

fun Context.round(color: Int, r: Int = 16, stroke: Int = 0) = android.graphics.drawable.GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
}
fun Context.tv(t: String, size: Float = 14f, color: Int = C.text, bold: Boolean = false) = TextView(this).apply {
    text = t; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
}
fun Context.btn(t: String, onClick: () -> Unit) = TextView(this).apply {
    text = t; textSize = 13f; setTextColor(C.text); gravity = Gravity.CENTER
    setPadding(dp(14), dp(9), dp(14), dp(9)); background = round(C.card, 12, C.red); setOnClickListener { onClick() }
}
fun Context.edit(hint: String, value: String = "", password: Boolean = false) = EditText(this).apply {
    setHint(hint); setText(value); setTextColor(C.text); setHintTextColor(C.hint); textSize = 14f
    background = round(C.card, 12, 0xFF333333.toInt()); setPadding(dp(12), dp(10), dp(12), dp(10))
    if (password) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
}

class OrbView(c: Context) : View(c) {
    var state = State.IDLE
    var amp = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedFraction; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        if (width <= 0 || height <= 0) return  // zero-size -> RadialGradient would crash
        val cx = width / 2f; val cy = height / 2f
        // Multi-colour by state: listening = red+yellow, speaking = pink+purple, thinking = blue+cyan
        val (c1, c2) = when (state) {
            State.RECORDING, State.LISTENING -> 0xFFFF1744.toInt() to 0xFFFFD600.toInt()  // red + yellow
            State.SPEAKING -> 0xFFE040FB.toInt() to 0xFF7C4DFF.toInt()  // pink + purple
            State.THINKING -> 0xFF40C4FF.toInt() to 0xFF00B0FF.toInt()  // blue + cyan
            State.IDLE -> 0xFFE040FB.toInt() to 0xFF7C4DFF.toInt()  // pink + purple (beautiful default)
        }
        // Big by default, grows bigger with speech amplitude (loud=big, quiet=small)
        val pulse = 1.15f + 0.05f * sin(t * 2 * Math.PI).toFloat() + amp * 0.6f
        val r = min(width, height) / 2f * 0.5f * pulse
        // outer glow
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r * 1.8f, (c1 and 0x00FFFFFF) or 0x88000000.toInt(), 0, Shader.TileMode.CLAMP); cv.drawCircle(cx, cy, r * 1.8f, p)
        // main sphere
        p.shader = RadialGradient(cx - r * .3f, cy - r * .3f, r * 1.2f, c1, c2, Shader.TileMode.CLAMP); cv.drawCircle(cx, cy, r, p)
        p.shader = null
        // network dots on sphere (like reference image)
        p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt(); p.alpha = 180
        for (i in 0 until 16) {
            val a = (t * 360f + i * 22.5f) * Math.PI / 180f
            val rr = r * (0.55f + 0.35f * sin(i * 1.7f).toFloat())
            cv.drawCircle((cx + cos(a) * rr).toFloat(), (cy + sin(a) * rr * 0.8f).toFloat(), 3f, p)
        }
        p.alpha = 255
        // Saturn ring (rotates)
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = c1; p.alpha = 200
        cv.save(); cv.rotate(t * 360f, cx, cy)
        val rw = r * 1.7f; val rh = r * 0.55f
        cv.drawOval(cx - rw, cy - rh, cx + rw, cy + rh, p)
        p.alpha = 120; p.strokeWidth = 2f
        cv.drawOval(cx - rw * 1.12f, cy - rh * 1.12f, cx + rw * 1.12f, cy + rh * 1.12f, p)
        cv.restore()
        // rotating arcs
        p.strokeWidth = 3f; p.alpha = 220; p.color = c2
        for (i in 1..2) {
            val rr = r * (1.25f + i * 0.18f)
            val rot = t * 360f * (if (i % 2 == 0) -1 else 1)
            cv.drawArc(cx - rr, cy - rr, cx + rr, cy + rr, rot, 110f, false, p)
            cv.drawArc(cx - rr, cy - rr, cx + rr, cy + rr, rot + 180f, 110f, false, p)
        }
        // highlight
        p.style = Paint.Style.FILL; p.alpha = 255
        p.shader = RadialGradient(cx - r * .35f, cy - r * .35f, r * .5f, 0x66FFFFFF, 0, Shader.TileMode.CLAMP); cv.drawCircle(cx - r * .3f, cy - r * .3f, r * .5f, p); p.shader = null
    }
}

object FileSaver {
    fun ext(lang: String) = when (lang.lowercase()) {
        "kotlin", "kt" -> "kt"; "python", "py" -> "py"; "javascript", "js" -> "js"; "typescript", "ts" -> "ts"; "java" -> "java"
        "html" -> "html"; "css" -> "css"; "json" -> "json"; "xml" -> "xml"; "bash", "sh", "shell" -> "sh"; "c" -> "c"
        "cpp", "c++" -> "cpp"; "csharp", "c#" -> "cs"; "go" -> "go"; "rust" -> "rs"; "php" -> "php"; "sql" -> "sql"
        "swift" -> "swift"; "dart" -> "dart"; "yaml", "yml" -> "yml"; "markdown", "md" -> "md"; else -> "txt"
    }

    /** Saves to Downloads/MYRA (API 29+) or app Documents folder. Returns a readable location. */
    fun save(ctx: Context, name: String, mime: String, bytes: ByteArray): String {
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MYRA")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw IllegalStateException("cannot create file")
            ctx.contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
            return "Downloads/MYRA/$name"
        }
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "MYRA").apply { mkdirs() }
        File(dir, name).writeBytes(bytes); return File(dir, name).absolutePath
    }

    fun pdf(text: String): ByteArray {
        val doc = PdfDocument()
        val paint = Paint().apply { typeface = Typeface.MONOSPACE; textSize = 9f; color = Color.BLACK }
        val lines = text.replace("\t", "    ").lines().flatMap { l -> if (l.isEmpty()) listOf("") else l.chunked(88) }
        val perPage = 63; var i = 0; var page = 1
        while (i < lines.size || page == 1) {
            val pg = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, page).create())
            var y = 50f
            for (k in i until min(i + perPage, lines.size)) { pg.canvas.drawText(lines[k], 40f, y, paint); y += 12f }
            doc.finishPage(pg); i += perPage; page++
            if (lines.isEmpty()) break
        }
        val out = ByteArrayOutputStream(); doc.writeTo(out); doc.close(); return out.toByteArray()
    }
}

object Perms {
    fun runtime(): Array<String> = buildList {
        add(Manifest.permission.RECORD_AUDIO); add(Manifest.permission.READ_CONTACTS); add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.READ_PHONE_STATE); add(Manifest.permission.ANSWER_PHONE_CALLS)
        add(Manifest.permission.READ_CALENDAR); add(Manifest.permission.WRITE_CALENDAR)
        add(Manifest.permission.ACCESS_COARSE_LOCATION); add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
    }.toTypedArray()

    fun missing(c: Context) = runtime().filter { c.checkSelfPermission(it) != android.content.pm.PackageManager.PERMISSION_GRANTED }.toTypedArray()

    class Special(val label: String, val granted: (Context) -> Boolean, val intent: (Context) -> Intent)
    private fun pkg(c: Context) = Uri.parse("package:${c.packageName}")
    val special = listOf(
        Special("Accessibility (screen control)", { AccessibilityHelperService.isEnabled(it) }, { Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS) }),
        Special("Notification access", { NotificationManagerCompat.getEnabledListenerPackages(it).contains(it.packageName) }, { Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }),
        Special("Display over other apps", { Settings.canDrawOverlays(it) }, { Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg(it)) }),
        Special("Modify system settings (brightness)", { Settings.System.canWrite(it) }, { Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg(it)) }),
        Special("Do Not Disturb access", { (it.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted }, { Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) }),
        Special("Ignore battery optimization", { (it.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(it.packageName) }, { Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg(it)) })
    )
}
