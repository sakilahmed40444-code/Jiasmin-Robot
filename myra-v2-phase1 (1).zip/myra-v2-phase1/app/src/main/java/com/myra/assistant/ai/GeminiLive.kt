package com.myra.assistant.ai

import android.util.Base64
import com.myra.assistant.data.Prefs
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject

/**
 * Gemini Live API — real-time voice conversation via WebSocket.
 * Mic (16kHz PCM) -> WebSocket -> Gemini -> 24kHz PCM audio -> Speaker.
 * Mic muted while MYRA speaks (echo prevention). Transcripts captured.
 */
class GeminiLive(private val ctx: android.content.Context, private val ui: PipelineUi) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var ws: WebSocket? = null
    private var audioEngine = AudioEngine().also { it.onAmp = { a -> ui.onAmplitude(a) } }
    private var micRecord: android.media.AudioRecord? = null
    @Volatile private var running = false
    @Volatile private var speaking = false  // MYRA speaking -> mute mic
    @Volatile var onTranscript: ((String, Boolean) -> Unit)? = null  // (text, isUser)

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(0, java.util.concurrent.TimeUnit.SECONDS)  // WebSocket: no timeout
        .build()

    fun start() {
        val key = Prefs.geminiKey
        if (key.isBlank() || !Prefs.geminiKeyOn) {
            ui.onError("Gemini key set koro (Live Voice-এর জন্য)")
            return
        }
        if (running) return
        running = true
        ui.onState(State.LISTENING)

        val model = "gemini-2.5-flash-preview-native-audio-dialog"  // Live model
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=$key"
        val req = Request.Builder().url(url).build()

        ws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) {
                // Setup: AUDIO response, selected voice (default Aoede)
                val voice = Prefs.voice.ifBlank { "Aoede" }
                val setup = JSONObject()
                    .put("setup", JSONObject()
                        .put("model", "models/$model")
                        .put("generation_config", JSONObject()
                            .put("response_modalities", org.json.JSONArray().put("AUDIO"))
                            .put("speech_config", JSONObject()
                                .put("voice_config", JSONObject()
                                    .put("prebuilt_voice_config", JSONObject().put("voice_name", voice)))))
                        .put("system_instruction", JSONObject()
                            .put("parts", org.json.JSONArray().put(JSONObject()
                                .put("text", "You are MYRA, a friendly AI companion. Speak naturally in Bangla.")))))
                w.send(setup.toString())
                startMic(w)
                // 14. Start-up greeting (spoken via Live)
                scope.launch {
                    delay(1000)
                    if (running) {
                        val name = Prefs.addressMe.ifBlank { "সবুজ জান" }
                        // Send text to get spoken greeting
                        val greet = JSONObject()
                            .put("client_content", JSONObject()
                                .put("turns", org.json.JSONArray().put(JSONObject()
                                    .put("role", "user")
                                    .put("parts", org.json.JSONArray().put(JSONObject()
                                        .put("text", "Say hello to $name in Bangla, ask how they are.")))))
                                .put("turn_complete", true))
                        try { w.send(greet.toString()) } catch (_: Exception) {}
                    }
                }
            }

            override fun onMessage(w: WebSocket, text: String) {
                try {
                    val msg = JSONObject(text)
                    // Server content: audio data
                    val sc = msg.optJSONObject("serverContent")
                    if (sc != null) {
                        // Audio chunks
                        val mc = sc.optJSONObject("modelTurn")?.optJSONArray("parts")
                        if (mc != null) {
                            for (i in 0 until mc.length()) {
                                val inline = mc.optJSONObject(i)?.optJSONObject("inlineData")
                                val b64 = inline?.optString("data")
                                val mime = inline?.optString("mimeType", "")
                                if (!b64.isNullOrEmpty() && mime.contains("audio")) {
                                    val pcm = Base64.decode(b64, Base64.DEFAULT)
                                    if (pcm.size > 100) {
                                        speaking = true
                                        scope.launch {
                                            audioEngine.begin()
                                            audioEngine.write(pcm)  // 24kHz PCM
                                            audioEngine.drain()
                                            speaking = false
                                        }
                                    }
                                }
                            }
                        }
                        // Transcripts
                        val it = sc.optJSONObject("inputTranscription")?.optString("text")
                        if (!it.isNullOrEmpty()) onTranscript?.invoke(it, true)
                        val ot = sc.optJSONObject("outputTranscription")?.optString("text")
                        if (!ot.isNullOrEmpty()) {
                            onTranscript?.invoke(ot, false)
                            ui.onCaption(ot)
                        }
                        // Turn complete
                        if (sc.optBoolean("turnComplete", false)) {
                            speaking = false
                        }
                    }
                } catch (_: Exception) {}
            }

            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) {
                if (!running) return
                // 13. Auto-reconnect (max 3 tries)
                scope.launch {
                    var tries = 0
                    while (running && tries < 3) {
                        tries++
                        delay(2000)
                        if (!running) break
                        ui.onState(State.THINKING)
                        // Reconnect by restarting
                        stop()
                        delay(500)
                        if (running) break  // was stopped intentionally
                        start()
                        break
                    }
                    if (running && tries >= 3) {
                        ui.onError("Live connection failed: ${t.message}")
                        stop()
                    }
                }
            }

            override fun onClosed(w: WebSocket, code: Int, reason: String) {
                stop()
            }
        })
    }

    private fun startMic(w: WebSocket) {
        scope.launch {
            val minBuf = android.media.AudioRecord.getMinBufferSize(
                16000, android.media.AudioFormat.CHANNEL_IN_MONO,
                android.media.AudioFormat.ENCODING_PCM_16BIT)
            micRecord = try {
                android.media.AudioRecord(
                    android.media.MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    16000, android.media.AudioFormat.CHANNEL_IN_MONO,
                    android.media.AudioFormat.ENCODING_PCM_16BIT, minBuf * 4)
            } catch (_: Exception) { null }
            val rec = micRecord ?: return@launch
            if (rec.state != android.media.AudioRecord.STATE_INITIALIZED) return@launch
            rec.startRecording()
            val buf = ShortArray(1024)
            val byteBuf = java.nio.ByteBuffer.allocate(2048)
            while (running) {
                // Mute mic while MYRA speaks (echo prevention)
                if (speaking) {
                    delay(50); continue
                }
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) {
                    byteBuf.clear()
                    byteBuf.order(java.nio.ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until n) byteBuf.putShort(buf[i])
                    val bytes = ByteArray(n * 2)
                    System.arraycopy(byteBuf.array(), 0, bytes, 0, n * 2)
                    val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    val msg = JSONObject()
                        .put("realtime_input", JSONObject()
                            .put("audio", JSONObject()
                                .put("data", b64)
                                .put("mime_type", "audio/pcm;rate=16000")))
                    try { w.send(msg.toString()) } catch (_: Exception) { break }
                    // Amplitude for ball animation
                    var sum = 0.0
                    for (i in 0 until n) sum += (buf[i] * buf[i]).toDouble()
                    val amp = (kotlin.math.sqrt(sum / n) / 10000.0).toFloat().coerceIn(0f, 1f)
                    ui.onAmplitude(amp)
                }
            }
            try { rec.stop(); rec.release() } catch (_: Exception) {}
        }
    }

    fun stop() {
        running = false
        speaking = false
        try { ws?.close(1000, "done") } catch (_: Exception) {}
        ws = null
        try { micRecord?.stop(); micRecord?.release() } catch (_: Exception) {}
        micRecord = null
        scope.coroutineContext.cancelChildren()
        ui.onState(State.IDLE)
    }

    val isRunning get() = running
}
