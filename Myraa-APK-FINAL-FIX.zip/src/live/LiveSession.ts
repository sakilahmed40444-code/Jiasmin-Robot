import { GoogleGenAI, Modality } from "@google/genai";
import { MYRAA_SYSTEM_INSTRUCTION, VoiceModelId } from "../config";
import { ToolManager, TOOL_DECLARATIONS } from "../tools/ToolManager";

type LiveCallbacks = {
  onOpen?: () => void;
  onAudio?: (base64Pcm24: string) => void;
  onInterrupted?: () => void;
  onTurnComplete?: () => void;
  onInputTranscript?: (text: string) => void;
  onOutputTranscript?: (text: string) => void;
  onError?: (message: string) => void;
  onClose?: () => void;
};

export class LiveSession {
  private session: any = null;
  private apiKey: string;
  private model: VoiceModelId;
  private callbacks: LiveCallbacks;
  private tools = new ToolManager();
  private toolCallPending = false;

  constructor(apiKey: string, model: VoiceModelId, callbacks: LiveCallbacks) {
    this.apiKey = apiKey;
    this.model = model;
    this.callbacks = callbacks;
  }

  async connect() {
    if (!this.apiKey) throw new Error("Gemini API key is missing.");

    const ai = new GoogleGenAI({ apiKey: this.apiKey });
    const modelConfig: Record<string, unknown> = {
      responseModalities: [Modality.AUDIO],
      systemInstruction: MYRAA_SYSTEM_INSTRUCTION,
      inputAudioTranscription: {},
      outputAudioTranscription: {},
      tools: [{ functionDeclarations: TOOL_DECLARATIONS }]
    };

    if (this.model === "gemini-3.8-live-extended-thinking") {
      modelConfig.thinkingConfig = {
        thinkingLevel: "low"
      };
    }

    this.session = await ai.live.connect({
      model: this.model,
      config: modelConfig,
      callbacks: {
        onopen: () => this.callbacks.onOpen?.(),
        onmessage: (message: any) => this.handleMessage(message),
        onerror: (error: any) => {
          this.callbacks.onError?.(error?.message || "Live session error");
        },
        onclose: () => this.callbacks.onClose?.()
      }
    });
  }

  sendPcm16k(pcm: Uint8Array) {
    if (!this.session || this.toolCallPending) return;
    const base64 = this.bytesToBase64(pcm);
    this.session.sendRealtimeInput({
      audio: {
        data: base64,
        mimeType: "audio/pcm;rate=16000"
      }
    });
  }

  stopAudioStream() {
    if (!this.session || this.toolCallPending) return;
    try {
      this.session.sendRealtimeInput({ audioStreamEnd: true });
    } catch {}
  }

  close() {
    try { this.session?.close(); } catch {}
    this.session = null;
  }

  private async handleMessage(message: any) {
    const content = message?.serverContent;

    if (content?.modelTurn?.parts) {
      for (const part of content.modelTurn.parts) {
        const audio = part?.inlineData?.data;
        if (audio) this.callbacks.onAudio?.(audio);
      }
    }

    if (content?.inputTranscription?.text) {
      this.callbacks.onInputTranscript?.(content.inputTranscription.text);
    }

    if (content?.outputTranscription?.text) {
      this.callbacks.onOutputTranscript?.(content.outputTranscription.text);
    }

    if (content?.interrupted) {
      this.callbacks.onInterrupted?.();
    }

    const toolCall = message?.toolCall;
    if (toolCall?.functionCalls?.length) {
      await this.handleToolCalls(toolCall.functionCalls);
    }

    if (content?.turnComplete) {
      this.callbacks.onTurnComplete?.();
    }
  }

  private async handleToolCalls(calls: Array<any>) {
    this.toolCallPending = true;
    try {
      const functionResponses = [];
      for (const fc of calls) {
        const result = await this.tools.execute({
          id: fc.id,
          name: fc.name,
          args: fc.args ?? {}
        });
        functionResponses.push({
          id: fc.id,
          name: fc.name,
          response: result
        });
      }

      await this.session?.sendToolResponse({ functionResponses });
    } catch (error) {
      this.callbacks.onError?.(
        error instanceof Error ? error.message : "Tool execution failed."
      );
    } finally {
      this.toolCallPending = false;
    }
  }

  private bytesToBase64(bytes: Uint8Array): string {
    let binary = "";
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
    }
    return btoa(binary);
  }
}