package com.myra.assistant.ui

import android.Manifest
import android.app.Dialog
import android.media.projection.MediaProjectionManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.Window
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.lifecycleScope
import com.myra.assistant.ai.BrainClient
import com.myra.assistant.ai.Prompt
import com.myra.assistant.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** New pink-purple theme for settings. */
private object T {
    const val bg = 0xFF0D0A14.toInt(); const val card = 0xFF1A1428.toInt()
    const val card2 = 0xFF241B38.toInt(); const val pink = 0xFFFF3D7F.toInt()
    const val purple = 0xFF9D4EDD.toInt(); const val text = 0xFFF5F0FF.toInt()
    const val hint = 0xFF8E8A9E.toInt(); const val green = 0xFF22C55E.toInt()
    const val blue = 0xFF40A9FF.toInt()
}

class SettingsActivity : AppCompatActivity() {

    private val tabs = listOf("ACCOUNT", "PERMS", "CONTROLS", "API")
    private var tab = 0
    private lateinit var tabRow: LinearLayout
    private lateinit var content: LinearLayout

    private val voices = listOf("Achernar","Algenib","Algieba","Alnilam","Aoede","Autonoe","Callirrhoe","Charon","Despina","Enceladus","Erinome","Fenrir","Gacrux","Iapetus","Kore","Laomedeia","Leda","Orus","Puck","Pulcherrima","Rasalgethi","Sadachbia","Sadalbari","Sadaltager","Sulafat","Umbriel","Vindemiatrix","Zephyr","Zubenelgenubi")
    private val langs = listOf("AUTO" to "Auto", "BENGALI" to "Bengali", "HINGLISH" to "Hinglish", "HINDI" to "Hindi", "ENGLISH" to "English")
    private val brainProviders = listOf("OPENROUTER" to "OpenRouter key diye")

    private val pickAvatar = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            Prefs.avatarUri = uri.toString()
            toast("Avatar set ✅"); draw()
        }
    }
    private var lastPermReq: String? = null
    private val reqPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val perm = lastPermReq
        if (!ok && perm != null && !shouldShowRequestPermissionRationale(perm)) {
            // permanently denied — system dialog won't show again, open app settings instead
            toast("Settings theke permission dao")
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        draw()
    }

    /** Ask a runtime permission; never a dead tap — opens app settings if already granted or permanently denied. */
    private fun askPerm(perm: String) {
        if (granted(perm)) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        } else {
            lastPermReq = perm
            reqPerm.launch(perm)
        }
    }
    private val screenCapReq = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) { Prefs.screenCapGranted = true; toast("Screen capture granted ✅") }
        draw()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // beautiful gradient background (not video)
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF1A0A2E.toInt(), 0xFF2D1B4E.toInt(), 0xFF4A148C.toInt())
            )
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(14), dp(16), dp(10)) }
        head.addView(tv("←", 24f, T.text, true).apply { setPadding(dp(8), dp(8), dp(16), dp(8)); setOnClickListener { finish() } })
        head.addView(tv("Settings", 24f, T.text, true))
        root.addView(head)
        tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), 0, dp(4), dp(4)) }
        root.addView(tabRow)
        val sv = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(90)) }
        sv.addView(content)
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        draw()
    }

    override fun onResume() { super.onResume(); if (::content.isInitialized) draw() }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    // ---------------- shell ----------------
    private fun draw() { drawTabs(); drawContent() }

    private fun drawTabs() {
        tabRow.removeAllViews()
        tabs.forEachIndexed { i, name ->
            val sel = i == tab
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); gravity = Gravity.CENTER }
            col.addView(tv(name, 13f, if (sel) T.pink else T.hint, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(8)) })
            col.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(3)); setBackgroundColor(if (sel) T.pink else Color.TRANSPARENT) })
            col.setOnClickListener { tab = i; draw() }
            tabRow.addView(col)
        }
    }

    private fun drawContent() {
        content.removeAllViews()
        when (tab) {
            0 -> drawAccount()
            1 -> drawPerms()
            2 -> drawControls()
            3 -> drawApi()
        }
    }

    private fun add(v: View, bottom: Int = 10) {
        v.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 0, 0, dp(bottom)) }
        content.addView(v)
    }

    private fun section(t: String) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(14), dp(4), dp(8)) }
        r.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(4), dp(18)); setBackgroundColor(T.pink) })
        r.addView(tv("  " + t.uppercase(), 13f, T.hint, true))
        add(r, 2)
    }

    /** Card row: icon + title + subtitle + value + chevron. */
    private fun cardRow(icon: String, title: String, sub: String, value: String, onClick: () -> Unit): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = round(T.card, 20); setPadding(dp(14), dp(14), dp(14), dp(14)); isClickable = true
        }
        val ic = tv(icon, 22f).apply { background = round(T.card2, 14); setPadding(dp(10), dp(8), dp(10), dp(8)) }
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); setPadding(dp(12), 0, dp(8), 0) }
        mid.addView(tv(title, 16f, T.text, true))
        if (sub.isNotEmpty()) mid.addView(tv(sub, 12f, T.hint))
        card.addView(ic); card.addView(mid)
        if (value.isNotEmpty()) card.addView(tv(value, 13f, T.hint).apply { setPadding(0, 0, dp(4), 0) })
        card.addView(tv("›", 24f, T.hint))
        card.setOnClickListener { onClick() }
        return card
    }

    private fun badge(granted: Boolean): TextView = tv(if (granted) "Granted" else "Action Required", 12f, if (granted) T.green else T.pink, true).apply {
        setPadding(dp(12), dp(6), dp(12), dp(6))
    }

    // ---------------- ACCOUNT ----------------
    private fun drawAccount() {
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = round(T.card, 24); setPadding(dp(18), dp(18), dp(18), dp(18)) }
        val img = ImageView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(72), dp(72)) }
        img.clipToOutline = true
        img.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
        }
        loadAvatar(img)
        img.setOnClickListener { pickAvatar.launch("image/*") }
        head.addView(img)
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); setPadding(dp(16), 0, 0, 0) }
        val nameRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        nameRow.addView(tv(Prefs.userName.ifBlank { "তোমার নাম" }, 20f, T.text, true))
        nameRow.addView(tv("  ✓", 16f, T.blue, true))
        mid.addView(nameRow)
        mid.addView(tv(Prefs.userEmail.ifBlank { "email add koro" }, 13f, T.hint).apply { setPadding(0, dp(4), 0, 0) })
        head.addView(mid)
        add(head, 14)

        section("❤️ AI COMPANION ❤️")
        add(statusRow("👥", "Mem", "Memory connected"))
        add(statusRow("⭐", "Soul", "Personality connected"))
        add(statusRow("▶", "Data", "Data connected"))
        add(statusRow("📊", "Stats", "Stats connected"))
        add(cardRow("👤", "Name", "Change your name", Prefs.userName) {
            textDialog("Name", Prefs.userName, "তোমার নাম") { Prefs.userName = it; draw() }
        })
        add(cardRow("✉️", "Email", "Change your email", Prefs.userEmail) {
            textDialog("Email", Prefs.userEmail, "tomar@email.com") { Prefs.userEmail = it; draw() }
        })
        add(cardRow("🖼️", "Profile Picture", "Change your avatar", "") { pickAvatar.launch("image/*") })
        val perName = personaName()
        add(cardRow("🤖", "App Name", "MYRA-r naam change koro", Prefs.appName) {
            textDialog("App Name", Prefs.appName, "MYRA") { Prefs.appName = it.ifBlank { "MYRA" }; toast("নাম: " + Prefs.appName); draw() }
        })
        add(cardRow("💌", "Amake ki bole dakbe", "MYRA tomake ki naam-e dakbe", Prefs.addressMe) {
            textDialog("Dak naam", Prefs.addressMe, "সবুজ জান") { Prefs.addressMe = it.ifBlank { "সবুজ জান" }; toast("ডাক: " + Prefs.addressMe); draw() }
        })
        add(cardRow("🎭", "Personality", "Choose MYRA's personality", perName) { personaDialog() })
        add(cardRow("🎙️", "Voice", "Choose MYRA's voice", Prefs.voice) { voiceSheet() })
        val langName = langs.firstOrNull { it.first == Prefs.language }?.second ?: "Auto"
        add(cardRow("🌐", "Language", "Change app language", langName) {
            listDialog("Language", langs.map { it.second }, langs.indexOfFirst { it.first == Prefs.language }.coerceAtLeast(0)) { i ->
                Prefs.language = langs[i].first; toast("Language: " + langs[i].second); draw()
            }
        })
        add(cardRow("💬", "Help & Support", "", "") { helpDialog() })
        add(cardRow("🛡️", "Privacy Policy", "", "") {
            infoDialog("Privacy Policy", "তোমার key আর settings শুধু তোমার ফোনে থাকে (encrypted)।\n\nVoice processing-এর জন্য audio AI server-এ যায় (তোমার key দিয়ে)।\n\nআমরা কোনো data সংগ্রহ করি না।")
        })
        add(cardRow("📄", "Terms of Service", "", "") {
            infoDialog("Terms of Service", "MYRA personal use-এর জন্য।\n\nAPI key-এর খরচ তোমার (Gemini/OpenRouter-এর নিয়ম অনুযায়ী)।\n\nPhone control feature ব্যবহারের দায়িত্ব তোমার।")
        })
    }

    private fun loadAvatar(img: ImageView) {
        val u = Prefs.avatarUri
        if (u.isNotEmpty()) { try { img.setImageURI(Uri.parse(u)); return } catch (_: Exception) {} }
        img.setImageResource(android.R.drawable.ic_menu_gallery)
    }

    private fun personaName(): String {
        val v = Prefs.personality
        if (v.isBlank()) return "GirlFriend"
        v.toIntOrNull()?.let { return oldPersonaName(it) }
        return v
    }

    private fun oldPersonaName(i: Int) = when (i) {
        3 -> "Teacher"; 4 -> "Boss"; 1 -> "MT Assistant"; 2 -> "MT Assistant"; 5 -> "Hyper Energetic"
        else -> "GirlFriend"
    }

    // ---------------- PERMS (Full Control Permission) ----------------
    private fun drawPerms() {
        add(tv("🛡️ Full Control Permission", 18f, T.text, true).apply { setPadding(dp(4), dp(4), dp(4), dp(2)) }, 2)
        add(tv("Phone-er full control-এর জন্য permission দাও", 12f, T.hint).apply { setPadding(dp(4), 0, dp(4), dp(6)) }, 8)

        section("System")
        add(permCard("🤖", "Assistant", "Set MYRA as your default voice assistant.", isAssistantDefault()) {
            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
        })
        add(permCard("🎙️", "Microphone", "Voice input, commands, and real-time speech.", granted(Manifest.permission.RECORD_AUDIO)) {
            askPerm(Manifest.permission.RECORD_AUDIO)
        })
        add(permCard("🖥️", "Display Over Other Apps", "Show floating MYRA button and overlay UI.", Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        add(permCard("🔔", "Post Notifications", "Send alerts, reminders and status updates.", NotificationManagerCompat.from(this).areNotificationsEnabled()) {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        })

        section("Device")
        add(permCard("📍", "Precise Location", "Accurate location for weather and navigation.", granted(Manifest.permission.ACCESS_FINE_LOCATION)) {
            askPerm(Manifest.permission.ACCESS_FINE_LOCATION)
        })

        section("Media")
        add(permCard("📸", "Screen Capture", "Capture screen for visual context awareness.", Prefs.screenCapGranted) {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenCapReq.launch(mpm.createScreenCaptureIntent())
        })
        add(permCard("📷", "Camera", "Use camera for visual commands and scanning.", granted(Manifest.permission.CAMERA)) {
            askPerm(Manifest.permission.CAMERA)
        })

        section("Accessibility")
        Perms.special.forEach { s ->
            add(permCard("⚙️", s.label, "System settings থেকে চালু করো।", s.granted(this)) {
                startActivity(s.intent(this))
            }, 6)
        }
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun isAssistantDefault(): Boolean {
        val v = Settings.Secure.getString(contentResolver, "voice_interaction_service") ?: ""
        return v.contains(packageName)
    }

    private fun statusRow(icon: String, title: String, desc: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = round(T.card, 20); setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        val ic = tv(icon, 28f).apply {
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
            background = round(T.card2, 26); gravity = Gravity.CENTER
        }
        val mid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f); setPadding(dp(14), 0, dp(8), 0)
        }
        mid.addView(tv(title, 18f, T.text, true))
        mid.addView(tv(desc, 13f, T.hint))
        row.addView(ic); row.addView(mid)
        val dot = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(14), dp(14))
            background = round(0xFF4CAF50.toInt(), 7, 0)
        }
        row.addView(dot)
        row.addView(tv("  ›", 22f, T.hint))
        return row
    }

    private fun permCard(icon: String, title: String, desc: String, ok: Boolean, onTap: () -> Unit): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = round(T.card, 20); setPadding(dp(14), dp(14), dp(14), dp(14)); isClickable = true
        }
        val ic = tv(icon, 24f).apply {
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
            background = round(T.card2, 28); gravity = Gravity.CENTER
        }
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); setPadding(dp(12), 0, dp(8), 0) }
        mid.addView(tv(title, 16f, T.text, true))
        mid.addView(tv(desc, 12f, T.hint).apply { setPadding(0, dp(2), 0, 0) })
        card.addView(ic); card.addView(mid)
        val right = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        right.addView(badge(ok))
        right.addView(tv(if (ok) "  ✓" else "  ›", 20f, if (ok) T.green else T.hint, true))
        card.addView(right)
        card.setOnClickListener { onTap() }
        return card
    }

    // ---------------- CONTROLS ----------------
    private fun sliderDialog(title: String, cur: Float, minV: Float, maxV: Float, onSet: (Float) -> Unit) {
        val lay = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        val valTv = tv("%.1fx".format(cur), 18f, T.text, true).apply { setPadding(dp(20), dp(10), dp(20), 0) }
        val sb = android.widget.SeekBar(this).apply {
            this.max = 100
            this.progress = ((cur - minV) / (maxV - minV) * 100).toInt().coerceIn(0, 100)
            setPadding(dp(20), 0, dp(20), dp(10))
        }
        lay.addView(valTv); lay.addView(sb)
        sb.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: android.widget.SeekBar?, p: Int, u: Boolean) {
                valTv.text = "%.1fx".format(minV + (maxV - minV) * p / 100f)
            }
            override fun onStartTrackingTouch(s: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(s: android.widget.SeekBar?) {}
        })
        val dlgView: android.view.View = lay
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle(title).setView(dlgView)
            .setPositiveButton("OK") { _, _ -> onSet(minV + (maxV - minV) * sb.progress / 100f) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun drawControls() {
        section("Conversation")
        add(switchCard("Kotha bolar majhe thamano (barge-in)", "MYRA bolte thakle tumi kotha bollei thambe", Prefs.bargeIn) { Prefs.bargeIn = it })
        add(cardRow("⏱️", "Chup thakar somoy", "Kotokhon chup thakle MYRA bolbe — nije likho", "${Prefs.silenceMs} ms") {
            val e = edit("milliseconds (200-3000)", Prefs.silenceMs.toString()).apply {
                setTextColor(T.text); setHintTextColor(T.hint); inputType = InputType.TYPE_CLASS_NUMBER
            }
            AlertDialog.Builder(this).setTitle("Chup thakar somoy").setView(e.apply { setPadding(dp(20), dp(10), dp(20), dp(10)) })
                .setPositiveButton("OK") { _, _ ->
                    val v = e.text.toString().trim().toIntOrNull()?.coerceIn(200, 3000)
                    if (v != null) { Prefs.silenceMs = v; toast("$v ms set"); draw() } else toast("200-3000 er moddhe likho")
                }
                .setNegativeButton("Cancel", null).show()
        })
        add(switchCard("⚡ Fast Reply", "ON thakle kotha sesh howar 1 sec-e reply", Prefs.fastReply) { Prefs.fastReply = it })
        add(switchCard("Kaaj korar age confirm", "Phone control-এর আগে jigges korbe", Prefs.confirm) { Prefs.confirm = it })
        add(switchCard("Web search (Gemini)", "Gemini key diye web theke fresh info", Prefs.webSearchGemini) { Prefs.webSearchGemini = it })
        add(switchCard("Web search (OpenRouter)", "OpenRouter diye web theke fresh info", Prefs.webSearch) { Prefs.webSearch = it })
        add(switchCard("Code mode", "Code likhe dite parle file banabe", Prefs.codeMode) { Prefs.codeMode = it })
        add(switchCard("🎤 Voice Input", "ON thakle mic diye kotha bolle MYRA shunbe (real-time speech)", Prefs.voiceInputOn) { Prefs.voiceInputOn = it })

        section("Voice Commands")
        add(cardRow("🎙️", "Wake Word", "Bolle MYRA activate hobe", Prefs.wakeWord) {
            textDialog("Wake Word", Prefs.wakeWord, "Wake word likho") { Prefs.wakeWord = it; draw() }
        })
        add(cardRow("⏹️", "Dismiss Word", "Bolle MYRA thambe", Prefs.dismissWord) {
            textDialog("Dismiss Word", Prefs.dismissWord, "Dismiss word likho") { Prefs.dismissWord = it; draw() }
        })
        add(cardRow("⏱️", "Auto Timeout", "Kotha na bolle auto stop", "${Prefs.autoTimeoutSec} sec") {
            val opts = arrayOf("5 sec", "10 sec", "15 sec", "30 sec", "60 sec")
            val cur = when (Prefs.autoTimeoutSec) { 5 -> 0; 15 -> 2; 30 -> 3; 60 -> 4; else -> 1 }
            listDialog("Auto Timeout", opts.toList(), cur) { i ->
                Prefs.autoTimeoutSec = when (i) { 0 -> 5; 2 -> 15; 3 -> 30; 4 -> 60; else -> 10 }
                draw()
            }
        })
        // Human-like voice models via OpenRouter
        add(cardRow("🎙️", "Voice Model", "Natural voice বাছো", Prefs.orTtsModel) {
            val models = arrayOf(
                "google/gemini-3.8-flash-tts",  // 🥈 Gemini TTS
                "google/gemini-3.8-flash-lite-tts",
                "elevenlabs/eleven-v3",  // 🥇 ElevenLabs
                "elevenlabs/eleven-v4",
                "microsoft/mai-voice-2.1",  // 🥉 MAI-Voice
                "xai/grok-voice-tts-1.0",
                "minimax/speech-2.8-hd",
                "mistral/voxtral-mini-tts",
                "openai/gpt-audio"
            )
            val cur = models.indexOf(Prefs.orTtsModel).coerceAtLeast(0)
            androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Voice Model 🥇ElevenLabs 🥈Gemini 🥉MAI-Voice")
                .setSingleChoiceItems(models, cur) { d, w -> Prefs.orTtsModel = models[w]; draw(); d.dismiss() }
                .setNegativeButton("Cancel", null).show()
        })
        add(cardRow("🎚️", "Speech Rate", "Voice-er goti — kom/beshi koro", "${"%.1f".format(Prefs.speechRate)}x") {
            sliderDialog("Speech Rate", Prefs.speechRate, 0.5f, 2.0f) { Prefs.speechRate = it; draw() }
        })
        add(cardRow("🎵", "Pitch", "Voice-er sur — kom/beshi koro", "${"%.1f".format(Prefs.pitch)}x") {
            sliderDialog("Pitch", Prefs.pitch, 0.5f, 2.0f) { Prefs.pitch = it; draw() }
        })
        add(switchCard("🟢 Floating Ball", "App minimize korleo home screen-e ball thakbe", Prefs.floatingBall) {
            Prefs.floatingBall = it
            val i = android.content.Intent(this, com.myra.assistant.FloatingBallService::class.java)
            if (it) {
                if (android.provider.Settings.canDrawOverlays(this)) {
                    if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                    toast("Ball চালু 🟢")
                } else {
                    toast("Age 'Display Over Other Apps' dao (PERMS tab)"); Prefs.floatingBall = false; draw()
                }
            } else { stopService(i); toast("Ball বন্ধ") }
        })

        section("Memory")
        add(switchCard("Memory mone rakhbe", "Kotha mone rekhe pore use korbe", Prefs.memoryOn) { Prefs.memoryOn = it })
        add(cardRow("💾", "My Memory", "MYRA ja mone rekheche dekho/mucho", "") { memoryDialog() })

        section("Prime Contacts")
        add(cardRow("⭐", "Prime Contacts", "Kacher manushder list", "") { primeDialog() })
    }

    private fun switchCard(title: String, sub: String, v: Boolean, on: (Boolean) -> Unit): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = round(T.card, 20); setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
        mid.addView(tv(title, 15f, T.text, true))
        mid.addView(tv(sub, 12f, T.hint))
        card.addView(mid)
        val sw = Switch(this).apply { isChecked = v }
        sw.setOnCheckedChangeListener { _, c -> on(c) }
        card.addView(sw)
        return card
    }

    // ---------------- API ----------------
    private fun drawApi() {
        section("API Keys")
        add(tv("Key শুধু তুমি SAVE চাপলে save/change হবে।", 12f, T.hint).apply { setPadding(dp(4), 0, dp(4), dp(4)) }, 6)
        // Gemini Live needs Gemini key (re-added 2026-10-16)
        val gOk = Prefs.geminiKey.isNotBlank()
        val gSub = (if (gOk) "✅ Connected" else "Not set") + (if (Prefs.geminiKeyOn) " • ON 🔛" else " • OFF ⏸")
        add(cardRow("🔷", "Gemini AI Key (Live Voice)", gSub, if (gOk) "✅" else "") {
            keyDialog("gemini", "Gemini AI Key", "https://aistudio.google.com/app/apikey", Prefs.geminiKey, Prefs.geminiKeyOn,
                onToggle = { on ->
                    Prefs.geminiKeyOn = on
                    toast(if (on) "Gemini ON 🔛" else "Gemini OFF ⏸")
                    draw()
                },
                onSave = { Prefs.geminiKey = it; draw() })
        })
        val oOk = Prefs.apiKey.isNotBlank()
        val oSub = (if (oOk) "✅ Connected" else "Not set") + (if (Prefs.openRouterKeyOn) " • ON 🔛" else " • OFF ⏸")
        add(cardRow("🟣", "OpenRouter AI Key", oSub, if (oOk) "✅" else "") {
            keyDialog("openrouter", "OpenRouter AI Key", "https://openrouter.ai/workspaces/default/keys", Prefs.apiKey, Prefs.openRouterKeyOn,
                onToggle = { on ->
                    Prefs.openRouterKeyOn = on
                    toast(if (on) "OpenRouter ON 🔛" else "OpenRouter OFF ⏸")
                    draw()
                },
                onSave = { Prefs.apiKey = it; draw() })
        })

        section("Brain")
        val bp = brainProviders.indexOfFirst { it.first == Prefs.brainProvider }.coerceAtLeast(0)
        add(cardRow("🧠", "Brain Provider", "Kon key diye brain cholbe", brainProviders[bp].second) {
            listDialog("Brain Provider", brainProviders.map { it.second }, bp) { i ->
                Prefs.brainProvider = brainProviders[i].first; draw()
            }
        })
        add(cardRow("🔷", "Gemini Model", "Main: gemini-2.5-flash", Prefs.geminiModel.ifBlank { "gemini-2.5-flash" }) {
            // Chat models only (TTS models give 400 on chat endpoint)
            val models = arrayOf("google/gemini-3.8-flash", "google/gemini-2.5-flash", "google/gemini-1.5-pro")
            val cur = models.indexOf(Prefs.geminiModel).coerceAtLeast(0)
            androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Gemini Model (main: gemini-2.5-flash)")
                .setSingleChoiceItems(models, cur) { d, w -> Prefs.geminiModel = models[w]; draw(); d.dismiss() }
                .setNegativeButton("Cancel", null).show()
        })
        val presets = listOf("google/gemini-3.8-flash", "google/gemini-3.7-flash")
        add(cardRow("🟣", "OpenRouter Model", "OpenRouter key-র model", Prefs.brainModel.ifBlank { presets[0] }) {
            val items = presets + "✏️ Custom slug…"
            listDialog("OpenRouter Model", items, presets.indexOf(Prefs.brainModel).coerceAtLeast(0)) { i ->
                if (i < presets.size) { Prefs.brainModel = presets[i]; draw() }
                else textDialog("Custom Model Slug", Prefs.brainModel, "org/model") { Prefs.brainModel = it.ifBlank { presets[0] }; draw() }
            }
        })
        val levels = listOf("low", "medium", "high")
        add(cardRow("🎚️", "Thinking Level", "Koto govir chinta korbe", Prefs.thinking) {
            listDialog("Thinking Level", levels, levels.indexOf(Prefs.thinking).coerceAtLeast(0)) { i ->
                Prefs.thinking = levels[i]; draw()
            }
        })
    }

    // ---------------- dialogs ----------------
    private fun textDialog(title: String, value: String, hint: String, onSave: (String) -> Unit) {
        val e = edit(hint, value).apply { setTextColor(T.text); setHintTextColor(T.hint) }
        AlertDialog.Builder(this).setTitle(title).setView(e.wrapPad())
            .setPositiveButton("Save") { _, _ -> onSave(e.text.toString().trim()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun helpDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(10)) }
        box.addView(tv("🎙 কথা বলো — MYRA শুনে উত্তর দেবে।\n\n⚙ Settings থেকে key, voice, personality বদলাও।\n\n🔑 Brain-এর জন্য Gemini বা OpenRouter key লাগবে।\n\n❓ সমস্যা হলে key-র Test button চাপো।", 14f, T.text))
        box.addView(tv("\n👨‍💻 Developer", 14f, T.text, true).apply { setPadding(0, dp(12), 0, 0) })
        val tg = tv("", 14f, T.pink).apply {
            text = android.text.Html.fromHtml("<a href=\"https://t.me/Mdsobusmiya6\">✈️ Telegram: @Mdsobusmiya6</a>", 0)
            movementMethod = android.text.method.LinkMovementMethod.getInstance()
        }
        box.addView(tg)
        box.addView(tv("📧 Gmail: Mdsobusmiya11@gmail.com", 14f, T.text))
        box.addView(tv("📍 সিরাজগঞ্জ, রায়গঞ্জ, সলংগা", 14f, T.text))
        AlertDialog.Builder(this).setTitle("Help & Support").setView(box)
            .setPositiveButton("OK", null).show()
    }

    private fun infoDialog(title: String, msg: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(msg)
            .setPositiveButton("OK", null).show()
    }

    private fun View.wrapPad(): View = LinearLayout(context).apply { setPadding(dp(20), dp(10), dp(20), dp(10)); addView(this@wrapPad) }

    private fun listDialog(title: String, items: List<String>, selected: Int, onPick: (Int) -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(box) }
        items.forEachIndexed { i, label ->
            val sel = i == selected
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(12)) }
            row.addView(tv(if (sel) "◉" else "○", 20f, if (sel) T.pink else T.hint).apply { setPadding(0, 0, dp(12), 0) })
            row.addView(tv(label, 15f, T.text))
            row.setOnClickListener { onPick(i) }
            box.addView(row)
        }
        AlertDialog.Builder(this).setTitle(title).setView(sv)
            .setNegativeButton("Cancel", null).show()
    }

    private fun keyDialog(kind: String, title: String, getUrl: String, current: String, isOn: Boolean,
                       onToggle: (Boolean) -> Unit, onSave: (String) -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(10)) }
        // ON/OFF switch
        val swRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        swRow.addView(tv("Key চালু", 14f, T.text),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this).apply {
            setChecked(isOn)
            setOnCheckedChangeListener { _, on -> onToggle(on) }
        }
        swRow.addView(sw)
        box.addView(swRow)
        // key field + eye toggle
        val fieldRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, 0) }
        val e = edit("API key", current, password = true).apply { setTextColor(T.text); setHintTextColor(T.hint) }
        fieldRow.addView(e, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        var showing = false
        val eye = tv("👁", 22f).apply {
            setPadding(dp(10), dp(6), dp(4), dp(6))
            setOnClickListener {
                showing = !showing
                e.inputType = if (showing) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                e.setSelection(e.text.length)
                text = if (showing) "🙈" else "👁"
            }
        }
        fieldRow.addView(eye)
        box.addView(fieldRow)
        // get + test
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
        val get = btn("🔗 Get key") { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(getUrl))) }
        val test = btn("🧪 Test") { testKeyNow(kind, e.text.toString().trim()) }
        row.addView(get, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(test, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(row)
        box.addView(tv("SAVE চাপলে key test হবে — ঠিক হলে save, ভুল হলে save হবে না। খালি রাখলে key মুছে যাবে।", 11f, T.hint).apply { setPadding(0, dp(6), 0, 0) })
        val d = AlertDialog.Builder(this).setTitle(title).setView(box)
            .setPositiveButton("💾 SAVE KEY", null)
            .setNegativeButton("Cancel", null).show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val k = e.text.toString().trim()
            // No validation — save whatever he enters (his rule 2026-10-16)
            onSave(k); Prefs.needGreet = true
            toast(if (k.isEmpty()) "Key cleared 🗑" else "Key saved ✅")
            d.dismiss()
        }
    }

    private fun testKeyErr(kind: String, key: String): String? {
        val b = if (kind == "gemini")
            BrainClient(BrainClient.GEM_BASE, key, Prefs.geminiModel.ifBlank { "gemini-2.5-flash" }, false)
        else BrainClient(BrainClient.OR_BASE, key, Prefs.brainModel.ifBlank { "google/gemini-3.8-flash" }, true)
        return b.test()
    }

    private fun testKeyNow(kind: String, key: String) {
        if (key.isBlank()) { toast("Age key boshao"); return }
        toast("Testing…")
        lifecycleScope.launch {
            val err = withContext(Dispatchers.IO) { testKeyErr(kind, key) }
            toast(if (err == null) "Key thik ✅ Connected" else "❌ $err")
        }
    }

    // ---------------- personality ----------------
    private fun personaDialog() {
        val all = Prompt.allPersonas()
        val cur = personaName()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(box) }
        all.forEach { p ->
            val sel = p.name == cur
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(12)) }
            row.addView(tv(if (sel) "◉" else "○", 20f, if (sel) T.pink else T.hint).apply { setPadding(0, 0, dp(12), 0) })
            row.addView(tv(p.name, 15f, T.text))
            row.setOnClickListener { Prefs.personality = p.name; toast("Personality: " + p.name); draw() }
            box.addView(row)
        }
        val manage = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(14), dp(20), dp(14)) }
        manage.addView(tv("⚙️", 20f).apply { setPadding(0, 0, dp(12), 0) })
        manage.addView(tv("Manage Custom Personalities", 15f, T.purple, true))
        manage.setOnClickListener { customPersonaManager() }
        box.addView(manage)
        AlertDialog.Builder(this).setTitle("Choose Personality").setView(sv)
            .setNegativeButton("Cancel", null).show()
    }

    private fun customPersonaManager() {
        val customs = Prompt.customPersonas().toMutableList()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(box) }
        fun refresh() {
            box.removeAllViews()
            if (customs.isEmpty()) box.addView(tv("Kono custom personality nei. Niche + chaple banao.", 13f, T.hint).apply { setPadding(dp(20), dp(16), dp(20), dp(16)) })
            customs.forEachIndexed { i, p ->
                val row = LinearLayout(this@SettingsActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(12)) }
                row.addView(tv(p.name, 15f, T.text).apply { layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) })
                val ed = tv("✏️", 18f).apply { setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { customPersonaEditor(p.name, p.prompt) { n, pr -> customs[i] = Prompt.Persona(n, pr); saveCustoms(customs); refresh() } } }
                val del = tv("🗑️", 18f).apply { setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { customs.removeAt(i); saveCustoms(customs); refresh() } }
                row.addView(ed); row.addView(del)
                box.addView(row)
            }
        }
        refresh()
        val d = AlertDialog.Builder(this).setTitle("Custom Personalities").setView(sv)
            .setPositiveButton("＋ Add", null)
            .setNegativeButton("Done", null).show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            customPersonaEditor("", "") { n, pr -> customs.add(Prompt.Persona(n, pr)); saveCustoms(customs); refresh() }
        }
    }

    private fun saveCustoms(list: List<Prompt.Persona>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("name", it.name).put("prompt", it.prompt)) }
        Prefs.customPersonas = arr.toString()
        draw()
    }

    private fun customPersonaEditor(name: String, prompt: String, onSave: (String, String) -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(10)) }
        val ne = edit("Personality name", name).apply { setTextColor(T.text); setHintTextColor(T.hint) }
        val pe = edit("Kemon behave korbe (English/Bangla)", prompt).apply {
            setTextColor(T.text); setHintTextColor(T.hint); minLines = 3
        }
        box.addView(ne); box.addView(pe)
        AlertDialog.Builder(this).setTitle(if (name.isEmpty()) "New Personality" else "Edit Personality").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val n = ne.text.toString().trim()
                val pr = pe.text.toString().trim()
                if (n.isBlank() || pr.isBlank()) { toast("Name + prompt dutoi lagbe"); return@setPositiveButton }
                onSave(n, pr); toast("Saved ✅")
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------------- voice bottom sheet ----------------
    private fun voiceSheet() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(T.card, 28); setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("🎙️", 24f).apply { background = round(T.card2, 14); setPadding(dp(10), dp(8), dp(10), dp(8)) })
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        ht.addView(tv("Choose Voice", 20f, T.text, true))
        ht.addView(tv("Select MYRA's speaking voice", 13f, T.hint))
        head.addView(ht)
        sheet.addView(head)
        sheet.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply { setMargins(0, dp(12), 0, dp(8)) }; setBackgroundColor(0xFF2A2138.toInt()) })

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(box); layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(380)) }
        voices.forEach { v ->
            val sel = v == Prefs.voice
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(10), dp(8), dp(10)) }
            row.addView(tv("🎙️", 20f, if (sel) T.pink else T.hint).apply { background = round(T.card2, 12); setPadding(dp(8), dp(6), dp(8), dp(6)) })
            row.addView(tv(v, 16f, if (sel) T.pink else T.text, sel).apply { layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); setPadding(dp(14), 0, 0, 0) })
            if (sel) row.addView(tv("🌸", 20f))
            row.setOnClickListener { Prefs.voice = v; toast("Voice: $v ✅"); d.dismiss(); draw() }
            box.addView(row)
        }
        sheet.addView(sv)
        d.setContentView(sheet)
        d.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }
        d.show()
    }

    // ---------------- memory & primes ----------------
    private fun memoryDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(box) }
        fun refresh() {
            box.removeAllViews()
            val cur = Prefs.memoryAll()
            if (cur.isEmpty()) box.addView(tv("Kichu mone nei ekhono.", 13f, T.hint).apply { setPadding(dp(20), dp(16), dp(20), dp(16)) })
            cur.forEach { (k, v) ->
                val row = LinearLayout(this@SettingsActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(10)) }
                row.addView(tv("• " + k + ": " + v, 14f, T.text).apply { layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) })
                row.addView(tv("\uD83D\uDDD1️", 18f).apply { setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { Prefs.forget(k); refresh() } })
                box.addView(row)
            }
        }
        refresh()
        val d = AlertDialog.Builder(this).setTitle("\uD83D\uDCBE My Memory").setView(sv)
            .setPositiveButton("＋ Add", null)
            .setNeutralButton("Clear all", null)
            .setNegativeButton("Done", null).show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val bx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(10)) }
            val ke = edit("mone rakhar bishoy (jemon: amar priyo rong)", "").apply { setTextColor(T.text); setHintTextColor(T.hint) }
            val ve = edit("uttor (jemon: neel)", "").apply { setTextColor(T.text); setHintTextColor(T.hint) }
            bx.addView(ke); bx.addView(ve)
            AlertDialog.Builder(this).setTitle("New Memory").setView(bx)
                .setPositiveButton("Save") { _, _ ->
                    val k = ke.text.toString().trim(); val v = ve.text.toString().trim()
                    if (k.isNotBlank() && v.isNotBlank()) { Prefs.remember(k, v); refresh() }
                }
                .setNegativeButton("Cancel", null).show()
        }
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { Prefs.clearMemory(); refresh() }
    }

    private fun primeDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(box) }
        fun refresh() {
            box.removeAllViews()
            val cur = Prefs.primes()
            if (cur.isEmpty()) box.addView(tv("Kono prime contact nei.", 13f, T.hint).apply { setPadding(dp(20), dp(16), dp(20), dp(16)) })
            cur.forEach { c ->
                val row = LinearLayout(this@SettingsActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(10)) }
                row.addView(tv("⭐ " + c.first + " — " + c.second, 14f, T.text).apply { layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) })
                row.addView(tv("\uD83D\uDDD1️", 18f).apply { setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { Prefs.savePrimes(Prefs.primes().filterNot { it.second == c.second }); refresh() } })
                box.addView(row)
            }
        }
        refresh()
        val d = AlertDialog.Builder(this).setTitle("⭐ Prime Contacts").setView(sv)
            .setPositiveButton("＋ Add", null)
            .setNegativeButton("Done", null).show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val bx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(10)) }
            val ne = edit("Name", "").apply { setTextColor(T.text); setHintTextColor(T.hint) }
            val pe = edit("Phone", "").apply { setTextColor(T.text); setHintTextColor(T.hint) }
            bx.addView(ne); bx.addView(pe)
            AlertDialog.Builder(this).setTitle("Add Contact").setView(bx)
                .setPositiveButton("Save") { _, _ ->
                    val n = ne.text.toString().trim(); val ph = pe.text.toString().trim()
                    if (n.isNotBlank() && ph.isNotBlank()) {
                        Prefs.savePrimes(Prefs.primes() + (n to ph)); refresh()
                    }
                }
                .setNegativeButton("Cancel", null).show()
        }
    }
}
