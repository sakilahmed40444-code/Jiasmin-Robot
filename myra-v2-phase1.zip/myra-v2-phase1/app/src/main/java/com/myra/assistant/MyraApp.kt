package com.myra.assistant

import android.app.Application
import com.myra.assistant.data.Prefs
import org.json.JSONObject

class MyraApp : Application() {
    override fun onCreate() { super.onCreate(); Prefs.init(this) }
}

/** Null-safe string read (org.json returns "null" for JSON null). */
fun JSONObject.s(k: String): String = if (isNull(k)) "" else optString(k, "")
