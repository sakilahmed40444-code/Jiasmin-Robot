package com.lia.assistant.ui

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.lia.assistant.R
import com.lia.assistant.brain.Persona
import com.lia.assistant.data.MemStore
import com.lia.assistant.voice.VoiceEngine

/** Priya Assistant Settings — ACCOUNT | PERMS | CONTROLS | API */
class SettingsFragment : Fragment() {
    private fun act() = activity as MainActivity

    private lateinit var tabRow: LinearLayout
    private lateinit var content: FrameLayout
    private val tabBtns = mutableListOf<Button>()
    private var curTab = 0
    private val TABS = listOf("ACCOUNT", "PERMS", "CONTROLS", "API")

    // account labels
    private var personaTv: TextView? = null
    private var voiceTv: TextView? = null
    private var langTv: TextView? = null
    private var nameTv: TextView? = null
    private var emailTv: TextView? = null
    private var avatarIv: ImageView? = null
    // perms (naya Zara-style tab khud render karta hai)
    private var permStatusTv: TextView? = null
    // memories
    private var memList: LinearLayout? = null
    private var memSearch: EditText? = null

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.col(Ui.BG))
        }
        // header
        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 12), Ui.dp(ctx, 8), Ui.dp(ctx, 4))
        }
        val back = Button(ctx, null, android.R.attr.buttonStyle).apply {
            text = "←"; textSize = 22f; setTextColor(Ui.col(Ui.TEXT))
            setOnClickListener { act().go(MainActivity.TAB_HOME) }
        }
        head.addView(back)
        head.addView(Ui.tv(ctx, "Settings", 24, Ui.TEXT, true))
        root.addView(head)

        // tabs
        tabRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in TABS.indices) {
            val b = Button(ctx, null, android.R.attr.buttonStyle).apply {
                text = TABS[i]; textSize = 13f; isAllCaps = false
                setTypeface(typeface, Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { showTab(i) }
            }
            tabBtns.add(b); tabRow.addView(b)
        }
        root.addView(tabRow)

        content = FrameLayout(ctx).apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(content)

        showTab(curTab)
        return root
    }

    private fun showTab(i: Int) {
        curTab = i
        for (j in tabBtns.indices) {
            val sel = (j == i)
            tabBtns[j].setTextColor(Ui.col(if (sel) Ui.ACCENT else Ui.TEXT3))
            tabBtns[j].setBackgroundColor(Ui.col(if (sel) "#2A1245" else Ui.BG))
        }
        val ctx = requireContext()
        val v = ScrollView(ctx).apply { addView(when (i) {
            0 -> accountView(ctx)
            1 -> permsView(ctx)
            2 -> controlsView(ctx)
            else -> apiView(ctx)
        }) }
        content.removeAllViews()
        content.addView(v)
    }

    // ================= ACCOUNT =================
    private fun accountView(ctx: android.content.Context): View {
        val col = Ui.colLayout(ctx)
        val p = act().prefs

        // profile header
        val ph = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Ui.dp(ctx, 8), 0, Ui.dp(ctx, 8))
        }
        avatarIv = ImageView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 64), Ui.dp(ctx, 64))
        }
        loadAvatar()
        ph.addView(avatarIv)
        val nm = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(ctx, 12), 0, 0, 0)
        }
        nameTv = Ui.tv(ctx, p.name.ifBlank { "Sobuj" }, 20, Ui.TEXT, true)
        emailTv = Ui.tv(ctx, p.email.ifBlank { "email set nahi" }, 13, Ui.TEXT2)
        nm.addView(nameTv); nm.addView(emailTv)
        ph.addView(nm)
        col.addView(ph)
        col.addView(sp(ctx, 8))

        col.addView(acctRow(ctx, "👤 Name", p.name.ifBlank { "Sobuj" }) { editText("Name", p.name.ifBlank { "Sobuj" }) { v -> p.name = v; nameTv?.text = v } })
        col.addView(acctRow(ctx, "📧 Email", p.email.ifBlank { "set karo" }) { editText("Email", p.email) { v -> p.email = v; emailTv?.text = v.ifBlank { "email set nahi" } } })
        col.addView(acctRow(ctx, "🖼️ Profile Picture", "Gallery se chuno") { pickImage() })
        personaTv = Ui.tv(ctx, "", 14, Ui.TEXT2)
        col.addView(acctRow(ctx, "🎭 Personality", "", personaTv) { pickPersona() })
        voiceTv = Ui.tv(ctx, "", 14, Ui.TEXT2)
        col.addView(acctRow(ctx, "🔊 Voice", "", voiceTv) { pickGeminiVoice() })
        langTv = Ui.tv(ctx, "", 14, Ui.TEXT2)
        col.addView(acctRow(ctx, "🌐 Language", "", langTv) { pickLang() })
        col.addView(acctRow(ctx, "❓ Help & Support", "") {
            pinkDlg().apply {
            setTitle("Help & Support")
            setMessage("Priya Assistant — voice-first AI companion.\n\n• Neeche ❤️ dabao aur bolo\n• \"youtube kholo\" — app kholo\n• \"yaad rakho...\" — memory save\n• Website Forge se bolke website banao\n\nKoi dikkat? Screenshot bhej do! 💗")
            setButton(android.app.AlertDialog.BUTTON_POSITIVE, "OK") { _, _ -> }
        }.show()
        })
        col.addView(acctRow(ctx, "🔒 Privacy Policy", "") {
            pinkDlg().apply {
            setTitle("Privacy Policy")
            setMessage("Tumhara data sirf tumhare phone me rehta hai.\nAPI keys, naam, memories — kuch bhi hamare server par nahi jata.\nGemini/OpenRouter/Serp ko sirf wahi text jata hai jo tum bhejti ho.")
            setButton(android.app.AlertDialog.BUTTON_POSITIVE, "OK") { _, _ -> }
        }.show()
        })
        col.addView(acctRow(ctx, "📜 Terms of Service", "") {
            pinkDlg().apply {
            setTitle("Terms of Service")
            setMessage("Priya Assistant jaise hai waise di gayi hai.\nVoice features ke liye internet chahiye.\nGalat istemal ki zimmedari user ki hogi.")
            setButton(android.app.AlertDialog.BUTTON_POSITIVE, "OK") { _, _ -> }
        }.show()
        })
        col.addView(sp(ctx, 12))
        val out = Ui.btn(ctx, "LOG OUT", false) {
            p.name = ""; p.email = ""; p.profilePic = ""
            nameTv?.text = "Sobuj"; emailTv?.text = "email set nahi"; loadAvatar()
            act().toast("Logged out")
        }
        out.setTextColor(Ui.col(Ui.ERROR))
        col.addView(out)
        col.addView(sp(ctx, 24))

        refreshAccountLabels()
        return col
    }

    private fun acctRow(ctx: android.content.Context, title: String, value: String, valueTv: TextView? = null, onClick: (() -> Unit)? = null): View {
        val r = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.col(Ui.SURFACE))
            val pad = Ui.dp(ctx, 12)
            setPadding(pad, pad, pad, pad)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = Ui.dp(ctx, 6)
            layoutParams = lp
            if (onClick != null) setOnClickListener { onClick() }
        }
        val t = Ui.tv(ctx, title, 15, Ui.TEXT, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        r.addView(t)
        if (valueTv != null) r.addView(valueTv) else r.addView(Ui.tv(ctx, value, 14, Ui.TEXT2))
        r.addView(Ui.tv(ctx, "›", 18, Ui.TEXT3))
        return r
    }

    /** Dialog wala input — kala background, safed lekha, taaki dikhe. */
    private fun darkInput(ctx: android.content.Context): EditText {
        return EditText(ctx).apply {
            setHintTextColor(Ui.col(Ui.TEXT3)); setTextColor(Ui.col(Ui.TEXT))
            setBackgroundColor(Ui.col(Ui.RAISED))
            val pad = Ui.dp(ctx, 14); setPadding(pad, pad, pad, pad)
        }
    }

    private fun editText(title: String, cur: String, onSave: (String) -> Unit) {
        val ctx = requireContext()
        val et = darkInput(ctx).apply { setText(cur) }
        val wrap = LinearLayout(ctx).apply {
            val pad = Ui.dp(ctx, 16); setPadding(pad, 0, pad, 0); addView(et)
        }
        val d = pinkDlg()
        d.setTitle(title); d.setView(wrap)
        d.setButton(android.app.AlertDialog.BUTTON_POSITIVE, "Save") { _, _ ->
            onSave(et.text.toString().trim()); refreshAccountLabels()
            announce("$title বদলে দিলাম ✅")
        }
        d.setButton(android.app.AlertDialog.BUTTON_NEGATIVE, "Cancel") { _, _ -> }
        d.show()
    }

    private fun loadAvatar() {
        val iv = avatarIv ?: return
        val pic = act().prefs.profilePic
        try {
            if (pic.isNotBlank()) iv.setImageURI(Uri.parse(pic))
            else iv.setImageResource(R.mipmap.ic_launcher)
        } catch (_: Exception) {
            try { iv.setImageResource(R.mipmap.ic_launcher) } catch (_: Exception) { }
        }
    }

    private fun pickImage() {
        try {
            val i = Intent(Intent.ACTION_PICK).apply { type = "image/*" }
            startActivityForResult(i, 77)
        } catch (_: Exception) { act().toast("Gallery nahi khul rahi") }
    }

    private fun refreshAccountLabels() {
        val p = act().prefs
        val per = Persona.byKey(p.persona)
        personaTv?.text = "${per.icon} ${per.title}"
        voiceTv?.text = when {
            p.geminiVoice.isNotBlank() && p.apiKey.isNotBlank() -> "🌐 ${p.geminiVoice} (Gemini)"
            p.ttsVoiceName.isNotBlank() -> "📱 ${p.ttsVoiceName.take(24)}"
            else -> "🇧🇩 Bangla default"
        }
        langTv?.text = when (p.langMode) { "bn" -> "🇧🇩 Bangla"; "en" -> "🇬🇧 English"; else -> "🔀 Auto" }
    }

    private fun pickPersona() {
        val ctx = requireContext()
        val items = Persona.values().map { "${it.icon} ${it.title} — ${it.desc}" }.toTypedArray()
        val cur = Persona.values().indexOf(Persona.byKey(act().prefs.persona))
        val dlg = AlertDialog.Builder(ctx).setTitle("🎭 Personality chuno")
            .setSingleChoiceItems(items, cur) { d, w ->
                act().prefs.persona = Persona.values()[w].key
                act().mem.clear()
                refreshAccountLabels()
                (d as? android.app.Dialog)?.dismiss()
                announce("Personality বদলে দিলাম — এখন ${Persona.values()[w].title} 💗")
            }.show()
        try { dlg.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Ui.col("#3D0F38"))) }
        catch (_: Exception) { }
    }


    /** Pink dialog — sada background noy. */
    private fun pinkDlg(): android.app.AlertDialog {
        val d = android.app.AlertDialog.Builder(requireContext()).create()
        d.setOnShowListener {
            try { d.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Ui.col("#3D0F38"))) }
            catch (_: Exception) { }
        }
        return d
    }

    /** Setting change hole Priya Bangla-e bole janabe. */
    private fun announce(msg: String) {
        act().toast(msg)
        Thread {
            try {
                val c = requireContext().applicationContext
                val e = com.lia.assistant.voice.VoiceEngine(c)
                e.setLang("bn", act().prefs.speechRate)
                e.speak(msg)
            } catch (_: Exception) { }
        }.start()
    }

    private fun pickLang() {
        val ctx = requireContext()
        val items = arrayOf("🇧🇩 Bangla (বাংলা)", "🇬🇧 English", "🔀 Auto")
        val vals = arrayOf("bn", "en", "auto")
        // purani Hindi setting ho to Bangla kar do
        if (act().prefs.langMode == "hi" || act().prefs.langMode == "hing") act().prefs.langMode = "bn"
        val cur = vals.indexOf(act().prefs.langMode).coerceAtLeast(0)
        val dlg = AlertDialog.Builder(ctx).setTitle("Bhasha chuno")
            .setSingleChoiceItems(items, cur) { d, w ->
                act().prefs.langMode = vals[w]
                refreshAccountLabels(); (d as? android.app.Dialog)?.dismiss()
                announce("ভাষা বদলে দিলাম — এখন ${items[w]} 💗")
            }.show()
        try { dlg.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Ui.col("#3D0F38"))) }
        catch (_: Exception) { }
    }

    /** Zara-style Choose Voice — jo API key lagi hai usi ki voices, selected pink ✓. */
    /** Zara-style Choose Voice — 14 voices, tap = shuno + select. */
    private fun pickGeminiVoice() {
        val ctx = requireContext()
        val p = act().prefs
        activity?.runOnUiThread {
            val geminiVoices = listOf("Achernar","Aoede","Autonoe","Callirrhoe","Despina","Erinome","Gacrux","Kore","Laomedeia","Leda","Pulcherrima","Sulafat","Vindemiatrix","Zephyr")
            val cur = p.geminiVoice.takeIf { it.isNotBlank() } ?: "Kore"

            val dlg = pinkDlg()
            val root = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Ui.col("#3D0F38"))
                val pp = Ui.dp(ctx, 16); setPadding(pp, pp, pp, pp)
            }
            val hrow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            hrow.addView(Ui.tv(ctx, "🔊 ", 26, Ui.TEXT))
            val htxt = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            htxt.addView(Ui.tv(ctx, "Choose Voice", 20, Ui.TEXT, true))
            htxt.addView(Ui.tv(ctx, "Tap koro — shune nao, select ho jayega", 13, Ui.TEXT2))
            hrow.addView(htxt)
            root.addView(hrow)
            root.addView(sp(ctx, 8))

            val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            val sv = ScrollView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 380))
                addView(list)
            }
            root.addView(sv)

            fun voiceRow(name: String, selected: Boolean) {
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    val pp2 = Ui.dp(ctx, 10); setPadding(pp2, pp2, pp2, pp2)
                }
                val icon = TextView(ctx).apply {
                    text = "🔈"; textSize = 20f; gravity = Gravity.CENTER
                    val d = android.graphics.drawable.GradientDrawable().apply {
                        shape = android.graphics.drawable.GradientDrawable.OVAL
                        setStroke(Ui.dp(ctx, 2), Ui.col(if (selected) Ui.ACCENT else Ui.TEXT3))
                        setColor(Ui.col(Ui.RAISED))
                    }
                    background = d
                    val sz = Ui.dp(ctx, 44)
                    layoutParams = LinearLayout.LayoutParams(sz, sz)
                }
                row.addView(icon)
                val mid = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    setPadding(Ui.dp(ctx, 12), 0, 0, 0)
                }
                mid.addView(Ui.tv(ctx, name, 16, if (selected) Ui.ACCENT else Ui.TEXT, selected))
                mid.addView(Ui.tv(ctx, "tap → preview", 11, Ui.TEXT2))
                row.addView(mid)
                if (selected) row.addView(Ui.tv(ctx, "🌸", 20, Ui.TEXT))
                row.setOnClickListener {
                    p.geminiVoice = name; p.ttsVoiceName = ""
                    previewVoice(name)
                    announce("Voice বদলে দিলাম — এখন $name বলবে 💗")
                    dlg.dismiss(); refreshAccountLabels()
                }
                list.addView(row)
            }
            for (v in geminiVoices) voiceRow(v, cur == v)
            dlg.setView(root)
            dlg.show()
        }
    }

    /** Voice preview — sample shunao oi voice me. */
    private fun previewVoice(name: String) {
        Thread {
            try {
                val c = requireContext().applicationContext
                val p = act().prefs
                val e = com.lia.assistant.voice.VoiceEngine(c)
                e.geminiVoice = name
                e.geminiKey = p.apiKey.takeIf { it.isNotBlank() }
                e.setLang("bn", p.speechRate)
                e.speak("আসসালামু আলাইকুম! আমি প্রিয়া। আমি $name — কেমন লাগলো আমার গলা?")
            } catch (_: Exception) { }
        }.start()
    }

    // ================= PERMS (Zara style — saare permissions) =================
    private val REQ_ASSISTANT = 60
    private val REQ_SCREEN_CAP = 61
    private val REQ_RUNTIME_PERMS = 62

    private data class PermDef(
        val icon: String, val title: String, val desc: String,
        val granted: () -> Boolean, val onTap: () -> Unit,
        val extraBtn: (android.content.Context) -> View? = { null }
    )

    private fun permsView(ctx: android.content.Context): View {
        val col = Ui.colLayout(ctx)

        // ---- status header ----
        val defs = permDefs(ctx)
        val granted = defs.count { it.granted() }
        val total = defs.size
        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.col(Ui.SURFACE))
            val p = Ui.dp(ctx, 14); setPadding(p, p, p, p)
        }
        val hrow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val htxt = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        htxt.addView(Ui.tv(ctx, "Permission Status", 20, Ui.TEXT, true))
        htxt.addView(Ui.tv(ctx,
            if (granted == total) "Sab permissions mil gayi! 🎉" else "${total - granted} permission(s) missing — some features may not work",
            13, Ui.TEXT2))
        hrow.addView(htxt)
        // circular count
        val circ = TextView(ctx).apply {
            text = "$granted/$total\nGranted"; gravity = Gravity.CENTER; textSize = 14f
            setTypeface(typeface, Typeface.BOLD); setTextColor(Ui.col(Ui.TEXT))
            val d = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setStroke(Ui.dp(ctx, 3), Ui.col(if (granted == total) Ui.NEON_GREEN else Ui.ACCENT))
                setColor(Ui.col(Ui.RAISED))
            }
            background = d
            val s = Ui.dp(ctx, 84)
            layoutParams = LinearLayout.LayoutParams(s, s)
        }
        hrow.addView(circ)
        head.addView(hrow)
        head.addView(sp(ctx, 10))
        head.addView(Ui.btn(ctx, "GRANT ALL PERMISSIONS", true) { grantAllPerms(ctx) })
        col.addView(head)
        col.addView(sp(ctx, 12))
        col.addView(Ui.tv(ctx, "REQUIRED PERMISSIONS", 13, Ui.TEXT2, true))
        col.addView(sp(ctx, 6))

        // ---- sections ----
        val sections = listOf(
            "CORE" to listOf("Default Assistant", "Microphone", "Accessibility"),
            "SYSTEM" to listOf("Display Over Other Apps", "Post Notifications"),
            "DEVICE" to listOf("Precise Location"),
            "MEDIA" to listOf("Screen Capture", "Camera")
        )
        val byTitle = defs.associateBy { it.title }
        for ((sec, titles) in sections) {
            // section label with pink bar
            val lab = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val bar = View(ctx).apply {
                setBackgroundColor(Ui.col(Ui.ACCENT))
                layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 4), Ui.dp(ctx, 18)).apply { rightMargin = Ui.dp(ctx, 8) }
            }
            lab.addView(bar)
            lab.addView(Ui.tv(ctx, sec, 13, Ui.TEXT2, true))
            val llp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            llp.topMargin = Ui.dp(ctx, 10); llp.bottomMargin = Ui.dp(ctx, 4)
            lab.layoutParams = llp
            col.addView(lab)
            for (t in titles) byTitle[t]?.let { col.addView(permRow(ctx, it)) }
        }
        col.addView(sp(ctx, 24))
        return col
    }

    private fun permDefs(ctx: android.content.Context): List<PermDef> {
        fun hasPerm(p: String) = androidx.core.content.ContextCompat.checkSelfPermission(ctx, p) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        return listOf(
            PermDef("🤖", "Default Assistant", "Set Priya as your default voice assistant.",
                granted = { isAssistantDefault(ctx) },
                onTap = { requestAssistantRole() }),
            PermDef("🎙️", "Microphone", "Voice input, commands, and real-time speech.",
                granted = { hasPerm(Manifest.permission.RECORD_AUDIO) },
                onTap = { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_RUNTIME_PERMS) }),
            PermDef("♿", "Accessibility", "Screen dekhna, tap, scroll, type — full phone control.",
                granted = { com.lia.assistant.service.LiaAccessibilityService.isEnabled(ctx) },
                onTap = { showRestrictedHelp() }),
            PermDef("⌨️", "Keyboard (Type)", "Kahin bhi likhna — type commands ke liye.",
                granted = { com.lia.assistant.service.LiaAccessibilityService.isEnabled(ctx) },
                onTap = { showRestrictedHelp() }),
            PermDef("🫧", "Display Over Other Apps", "Show floating Priya button and overlay UI.",
                granted = { android.provider.Settings.canDrawOverlays(ctx) },
                onTap = { startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:${ctx.packageName}"))) }),
            PermDef("🔔", "Post Notifications", "Send alerts, reminders and status updates.",
                granted = { androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled() },
                onTap = {
                    val i = Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    i.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    startActivity(i)
                }),
            PermDef("📍", "Precise Location", "Accurate location for weather and navigation.",
                granted = { hasPerm(Manifest.permission.ACCESS_FINE_LOCATION) || hasPerm(Manifest.permission.ACCESS_COARSE_LOCATION) },
                onTap = { requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION), REQ_RUNTIME_PERMS) }),
            PermDef("📸", "Screen Capture", "Capture screen for visual context awareness.",
                granted = { act().prefs.screenCapGranted },
                onTap = { requestScreenCapture() },
                extraBtn = { c ->
                    Ui.btn(c, "⟳ RESTART", false) { requestScreenCapture() }.apply {
                        textSize = 11f
                    }
                }),
            PermDef("📷", "Camera", "Use camera for visual commands and scanning.",
                granted = { hasPerm(Manifest.permission.CAMERA) },
                onTap = { requestPermissions(arrayOf(Manifest.permission.CAMERA), REQ_RUNTIME_PERMS) })
        )
    }

    private fun permRow(ctx: android.content.Context, def: PermDef): View {
        val granted = def.granted()
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.col(Ui.SURFACE))
            val p = Ui.dp(ctx, 12); setPadding(p, p, p, p)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = Ui.dp(ctx, 8); layoutParams = lp
            setOnClickListener { def.onTap() }
        }
        // circular icon
        val icon = TextView(ctx).apply {
            text = def.icon; textSize = 22f; gravity = Gravity.CENTER
            val d = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setStroke(Ui.dp(ctx, 2), Ui.col(Ui.ACCENT))
                setColor(Ui.col(Ui.RAISED))
            }
            background = d
            val s = Ui.dp(ctx, 52)
            layoutParams = LinearLayout.LayoutParams(s, s)
        }
        row.addView(icon)
        val mid = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(Ui.dp(ctx, 12), 0, Ui.dp(ctx, 8), 0)
        }
        mid.addView(Ui.tv(ctx, def.title, 16, Ui.TEXT, true))
        mid.addView(Ui.tv(ctx, def.desc, 12, Ui.TEXT2))
        row.addView(mid)
        // status pill
        val pill = TextView(ctx).apply {
            text = if (granted) "Granted" else "Action Required"
            textSize = 11f; setTypeface(typeface, Typeface.BOLD)
            setTextColor(Ui.col(if (granted) Ui.NEON_GREEN else Ui.ACCENT))
            val d = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = Ui.dp(ctx, 14).toFloat()
                setStroke(Ui.dp(ctx, 2), Ui.col(if (granted) Ui.NEON_GREEN else Ui.ACCENT))
            }
            background = d
            val pp = Ui.dp(ctx, 8)
            setPadding(pp * 2, pp, pp * 2, pp)
        }
        row.addView(pill)
        row.addView(Ui.tv(ctx, if (granted) "  ✓" else "  ›", 16,
            if (granted) Ui.NEON_GREEN else Ui.TEXT3, true))
        def.extraBtn(ctx)?.let {
            row.addView(it)
        }
        return row
    }

    private fun isAssistantDefault(ctx: android.content.Context): Boolean {
        return try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val rm = ctx.getSystemService(android.app.role.RoleManager::class.java)
                rm?.isRoleHeld(android.app.role.RoleManager.ROLE_ASSISTANT) == true
            } else false
        } catch (_: Exception) { false }
    }

    private fun requestAssistantRole() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val rm = requireContext().getSystemService(android.app.role.RoleManager::class.java)
                val intent = rm?.createRequestRoleIntent(android.app.role.RoleManager.ROLE_ASSISTANT)
                if (intent != null) { startActivityForResult(intent, REQ_ASSISTANT); return }
            }
            startActivity(Intent(android.provider.Settings.ACTION_VOICE_INPUT_SETTINGS))
        } catch (_: Exception) { act().toast("Settings me manually karo") }
    }

    private fun requestScreenCapture() {
        try {
            val mm = requireContext().getSystemService(android.content.Context.MEDIA_PROJECTION_SERVICE)
                    as android.media.projection.MediaProjectionManager
            startActivityForResult(mm.createScreenCaptureIntent(), REQ_SCREEN_CAP)
        } catch (_: Exception) { act().toast("Screen capture available nahi") }
    }

    /**
     * Android 13+ : Play Store ke bahar se install hui app ka Accessibility
     * "restricted settings" me block hota hai ("App was denied access").
     * Pehle App Info → ⋮ → Allow restricted settings karna padta hai.
     */
    private fun showRestrictedHelp() {
        val ctx = requireContext()
        val msg = "⚠️ \"App was denied access\" aaye to ghabrao mat — ye Android ka rule hai:\n\n" +
                "Play Store ke bahar se install hui app ke liye pehle ek switch on karna padta hai:\n\n" +
                "1️⃣ Neeche [App Info] dabao\n" +
                "2️⃣ Upar ⋮ (teen dot) dabao\n" +
                "3️⃣ \"Allow restricted settings\" → Allow karo\n" +
                "4️⃣ Wapas aao → [Accessibility] dabao → Priya Assistant ON karo ✅\n\n" +
                "Ye ek hi baar karna hai."
        val rd = pinkDlg()
        rd.setTitle("♿ Accessibility ON kaise karein")
        rd.setMessage(msg)
        rd.setButton(android.app.AlertDialog.BUTTON_POSITIVE, "App Info kholo") { _, _ ->
            try {
                startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    android.net.Uri.parse("package:${ctx.packageName}")))
            } catch (_: Exception) { act().toast("Settings me manually kholo") }
        }
        rd.setButton(android.app.AlertDialog.BUTTON_NEUTRAL, "Accessibility kholo") { _, _ ->
            try {
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (_: Exception) { act().toast("Settings me manually kholo") }
        }
        rd.setButton(android.app.AlertDialog.BUTTON_NEGATIVE, "Band karo") { _, _ -> }
        rd.show()
    }

    private fun grantAllPerms(ctx: android.content.Context) {
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (android.os.Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), REQ_RUNTIME_PERMS)
        act().toast("Baki rows par tap karke system settings me allow karo 👇")
    }

    @Deprecated("deprecated")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 77 && res == Activity.RESULT_OK) {
            val uri: android.net.Uri? = d?.data
            if (uri != null) {
                try { requireContext().contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
                act().prefs.profilePic = uri.toString()
                loadAvatar()
                act().toast("Profile picture set! 🖼️")
            }
        } else if (rc == REQ_SCREEN_CAP && res == Activity.RESULT_OK) {
            act().prefs.screenCapGranted = true
            com.lia.assistant.vision.ScreenVision.saveGrant(res, d)
            act().toast("Screen capture granted ✅")
            announce("Screen দেখার permission পেয়ে গেছি — এখন তুমি যা দেখাবে তা বুঝবো 👀")
            showTab(1)
        } else if (rc == REQ_ASSISTANT) {
            showTab(1)
        }
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (rc == REQ_RUNTIME_PERMS) showTab(1) // refresh statuses
    }

    private fun updatePermStatus() {
        // (purana — ab permsView khud count dikhata hai)
    }

    // ================= CONTROLS (Memories) =================
    private fun controlsView(ctx: android.content.Context): View {
        val col = Ui.colLayout(ctx)
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.tv(ctx, "My Memories", 22, Ui.TEXT, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        head.addView(Ui.btn(ctx, "+ ADD", true) { addMemory() })
        col.addView(head)
        memSearch = EditText(ctx).apply {
            hint = "Search memories..."
            setHintTextColor(Ui.col(Ui.TEXT3)); setTextColor(Ui.col(Ui.TEXT))
            setBackgroundColor(Ui.col(Ui.RAISED))
            val pad = Ui.dp(ctx, 12); setPadding(pad, pad, pad, pad)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) { renderMems() }
                override fun afterTextChanged(a: android.text.Editable?) {}
            })
        }
        col.addView(memSearch)
        col.addView(sp(ctx, 8))
        memList = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(memList)
        col.addView(sp(ctx, 24))
        renderMems()
        return col
    }

    private fun renderMems() {
        val ctx = context ?: return
        val ml = memList ?: return
        ml.removeAllViews()
        val q = memSearch?.text?.toString()?.lowercase()?.trim() ?: ""
        val mems = MemStore.list(ctx).filter { q.isEmpty() || it.lowercase().contains(q) }
        if (mems.isEmpty()) {
            ml.addView(Ui.tv(ctx, "🧠", 44, Ui.TEXT3).apply { gravity = Gravity.CENTER })
            ml.addView(Ui.tv(ctx, "No memories yet", 18, Ui.TEXT, true).apply { gravity = Gravity.CENTER })
            ml.addView(Ui.tv(ctx, "Tap + Add — Priya will remember it for you", 13, Ui.TEXT3).apply { gravity = Gravity.CENTER })
            return
        }
        for (m in mems) {
            val r = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(Ui.col(Ui.SURFACE))
                val pad = Ui.dp(ctx, 10); setPadding(pad, pad, pad, pad)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.topMargin = Ui.dp(ctx, 6); layoutParams = lp
            }
            val t = Ui.tv(ctx, "• $m", 14, Ui.TEXT).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val del = Button(ctx, null, android.R.attr.buttonStyle).apply {
                text = "❌"; setOnClickListener { MemStore.remove(ctx, m); renderMems(); act().toast("Delete ho gaya") }
            }
            r.addView(t); r.addView(del)
            ml.addView(r)
        }
    }

    private fun addMemory() {
        val ctx = requireContext()
        val et = darkInput(ctx).apply { hint = "e.g. Mera birthday 5 January hai" }
        val wrap = LinearLayout(ctx).apply {
            val pad = Ui.dp(ctx, 16); setPadding(pad, 0, pad, 0); addView(et)
        }
        val d = pinkDlg()
        d.setTitle("🧠 Yaad rakho"); d.setView(wrap)
        d.setButton(android.app.AlertDialog.BUTTON_POSITIVE, "Save") { _, _ ->
            val t = et.text.toString().trim()
            if (t.isNotBlank()) { MemStore.add(ctx, t); renderMems(); announce("মনে রেখে দিলাম ✅") }
        }
        d.setButton(android.app.AlertDialog.BUTTON_NEGATIVE, "Cancel") { _, _ -> }
        d.show()
    }

    // ================= API =================
    private fun apiView(ctx: android.content.Context): View {
        val col = Ui.colLayout(ctx)
        col.addView(Ui.tv(ctx, "CONNECTED APIS", 13, Ui.TEXT2, true))
        col.addView(sp(ctx, 6))
        col.addView(apiCard(ctx, "Gemini API", "Manage your Gemini API key", "apiKey"))
        col.addView(apiCard(ctx, "Serp API", "Manage your Serp API key (web search)", "serpKey"))
        col.addView(apiCard(ctx, "OpenRouter API", "Manage your OpenRouter API key (backup brain)", "openRouterKey"))
        col.addView(sp(ctx, 8))
        col.addView(Ui.tv(ctx, "Gemini key free me: aistudio.google.com → Get API Key 🔑", 12, Ui.TEXT3))
        col.addView(sp(ctx, 24))
        return col
    }

    private fun apiCard(ctx: android.content.Context, title: String, desc: String, key: String): View {
        val p = act().prefs
        val cur = when (key) { "apiKey" -> p.apiKey; "serpKey" -> p.serpKey; else -> p.openRouterKey }
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.col(Ui.SURFACE))
            val pad = Ui.dp(ctx, 12); setPadding(pad, pad, pad, pad)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = Ui.dp(ctx, 8); layoutParams = lp
        }
        val top = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Ui.tv(ctx, "🌐", 26, Ui.ACCENT))
        val tt = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(Ui.dp(ctx, 10), 0, 0, 0)
        }
        tt.addView(Ui.tv(ctx, title, 17, Ui.TEXT, true))
        tt.addView(Ui.tv(ctx, desc, 12, Ui.TEXT2))
        top.addView(tt)
        val badge = Ui.tv(ctx, if (cur.isNotBlank()) "Active" else "Not set", 12,
            if (cur.isNotBlank()) Ui.NEON_GREEN else Ui.TEXT3, true)
        top.addView(badge)
        card.addView(top)
        val bot = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val masked = if (cur.length > 6) cur.take(4) + "••••••••••••" else "••••••••"
        bot.addView(Ui.tv(ctx, masked, 14, Ui.TEXT2).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        bot.addView(Ui.btn(ctx, "CHANGE", false) { editApiKey(title, key) })
        card.addView(bot)
        return card
    }

    private fun editApiKey(title: String, key: String) {
        val ctx = requireContext()
        val p = act().prefs
        val cur = when (key) { "apiKey" -> p.apiKey; "serpKey" -> p.serpKey; else -> p.openRouterKey }
        val et = darkInput(ctx).apply {
            setText(cur)
            hint = "API key paste karo"
        }
        val wrap = LinearLayout(ctx).apply {
            val pad = Ui.dp(ctx, 16); setPadding(pad, 0, pad, 0); addView(et)
        }
        val dlg = pinkDlg()
        dlg.setTitle("🔑 $title")
        dlg.setView(wrap)
        dlg.setButton(android.app.AlertDialog.BUTTON_POSITIVE, "Save") { _, _ ->
            val v = et.text.toString().trim()
            when (key) { "apiKey" -> p.apiKey = v; "serpKey" -> p.serpKey = v; else -> p.openRouterKey = v }
            showTab(3)
            if (v.isBlank()) { announce("API key মুছে দিলাম"); return@setButton }
            act().toast("Key check korchi… 🔍")
            validateApiKey(key, v)
        }
        dlg.setButton(android.app.AlertDialog.BUTTON_NEGATIVE, "Cancel") { _, _ -> }
        dlg.show()
    }

    /** Key asol me kaam karti hai ya nahi — test call karke batao. */
    private fun validateApiKey(key: String, v: String) {
        Thread {
            val ok = try {
                when (key) {
                    "apiKey" -> {
                        val c = java.net.URL("https://generativelanguage.googleapis.com/v1beta/models?key=$v")
                            .openConnection() as java.net.HttpURLConnection
                        c.connectTimeout = 15000; c.readTimeout = 15000
                        c.responseCode == 200
                    }
                    "serpKey" -> {
                        val c = java.net.URL("https://serpapi.com/account?api_key=$v")
                            .openConnection() as java.net.HttpURLConnection
                        c.connectTimeout = 15000; c.readTimeout = 15000
                        c.responseCode == 200
                    }
                    else -> {
                        val c = java.net.URL("https://openrouter.ai/api/v1/models")
                            .openConnection() as java.net.HttpURLConnection
                        c.setRequestProperty("Authorization", "Bearer $v")
                        c.connectTimeout = 15000; c.readTimeout = 15000
                        c.responseCode == 200
                    }
                }
            } catch (_: Exception) { false }
            activity?.runOnUiThread {
                if (ok) announce("API key সঠিক আছে — connected হয়ে গেছে ✅")
                else announce("API key ভুল মনে হচ্ছে — আবার check করো ❌")
            }
        }.start()
    }

    private fun sp(ctx: android.content.Context, dp: Int): View {
        val v = View(ctx)
        v.layoutParams = LinearLayout.LayoutParams(1, Ui.dp(ctx, dp))
        return v
    }
}
