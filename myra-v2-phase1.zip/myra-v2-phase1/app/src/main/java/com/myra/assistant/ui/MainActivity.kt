package com.myra.assistant.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.myra.assistant.ai.PipelineUi
import com.myra.assistant.ai.State
import com.myra.assistant.ai.VoicePipeline
import com.myra.assistant.data.Prefs
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class MainActivity : AppCompatActivity(), PipelineUi {
    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var micBtn: TextView
    private lateinit var codeBtn: TextView
    private lateinit var redOverlay: View
    private lateinit var pipeline: VoicePipeline
    private var greeted = false

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { maybeStart() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = C.bg
        pipeline = VoicePipeline(applicationContext, this)
        buildUi()
        val missing = Perms.missing(this)
        if (missing.isNotEmpty()) permLauncher.launch(missing)
        showLastCrash()
    }

    /** If the app crashed last time, show the saved stack trace so it can be reported. */
    private fun showLastCrash() {
        try {
            val f = java.io.File(filesDir, "crash.txt")
            if (!f.exists()) return
            val trace = f.readText().take(3000)
            f.delete()
            val sv = ScrollView(this).apply {
                addView(tv(trace, 11f).apply { setPadding(dp(16), dp(12), dp(16), dp(12)) })
            }
            AlertDialog.Builder(this).setTitle("⚠ গতবার app crash করেছিল")
                .setMessage("এই কারণটা developer-কে পাঠাও:")
                .setView(sv)
                .setPositiveButton("OK", null).show()
        } catch (_: Exception) {}
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(C.bg) }
        redOverlay = View(this).apply { setBackgroundColor(C.red); alpha = 0f }
        root.addView(redOverlay, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(40), dp(14), dp(10)) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(tv("MYRA", 22f, C.red, true).apply { typeface = Typeface.create("sans-serif-black", Typeface.BOLD) })
        titleBox.addView(tv("AI COMPANION", 10f, C.hint).apply { typeface = Typeface.MONOSPACE })
        top.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        codeBtn = tv("</>", 16f, C.hint, true).apply { setPadding(dp(14), dp(8), dp(14), dp(8)); setOnClickListener { toggleCode() } }
        top.addView(codeBtn)
        top.addView(tv("⚙", 22f, 0xFF888888.toInt()).apply { setPadding(dp(14), dp(4), dp(8), dp(4)); setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) } })
        col.addView(top)

        orb = OrbView(this)
        col.addView(orb, LinearLayout.LayoutParams(-1, 0, 1f))
        status = tv("Tap korey bolo 💬", 13f, C.hint).apply { gravity = Gravity.CENTER }
        col.addView(status, LinearLayout.LayoutParams(-1, -2))

        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(chat) }
        col.addView(scroll, LinearLayout.LayoutParams(-1, dp(250)).apply { topMargin = dp(8) })

        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        input = edit("Type here... (code, question, command)").apply {
            imeOptions = EditorInfo.IME_ACTION_SEND; maxLines = 3
            setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_SEND) { send(); true } else false }
        }
        bottom.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(tv("➤", 22f, C.red).apply { setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { send() } })
        micBtn = tv("🎤", 26f).apply {
            gravity = Gravity.CENTER; background = round(C.card, 36, C.red)
            setOnClickListener { onMicTap() }
            setOnLongClickListener { pipeline.interrupt(); status.text = "Thamiye dilam"; true }
        }
        bottom.addView(micBtn, LinearLayout.LayoutParams(dp(60), dp(60)))
        col.addView(bottom, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        col.addView(tv("Long press mic = stop speaking", 10f, C.hint).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2))
        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        updateCodeBtn()
    }

    // ---------------- flow ----------------
    private fun maybeStart() {
        if (!Prefs.hasAnyKey()) { status.text = "Settings e API key boshao (Gemini / OpenRouter)"; startActivity(Intent(this, SettingsActivity::class.java)); return }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) { status.text = "Mic permission dao"; return }
        pipeline.muted = false; pipeline.start()
        if (!greeted) {
            greeted = true
            pipeline.say(greetFor())
        }
    }

    private fun greetFor(): String = when (Prefs.personality) {
        "GirlFriend" -> "ওই শোনো… বলো না, কী হয়েছে? ❤️"
        "Boss" -> "বলো, কী কাজ?"
        "Teacher" -> "বলো, আজ কী শিখবে?"
        "Soft Romantic Listener" -> "বলো… আমি শুনছি ❤️"
        "Hyper Energetic" -> "ইয়ো! বলো বলো!!"
        "Caring Neon AI" -> "হাই! আমি আছি তোমার পাশে ✨"
        "Mystical" -> "…বলো, রহস্য উন্মোচন করি 🔮"
        "Savage Girl" -> "হ্যাঁ বলো, তাড়াতাড়ি 😏"
        "Unknown" -> "বলো।"
        "Manipulative" -> "বলো… দেখি তোমাকে convince করতে পারি কিনা 😌"
        "MT Assistant" -> "বলো, কী help লাগবে?"
        else -> "বলো 🎙️"
    }

    private fun onMicTap() {
        if (!pipeline.listening) { maybeStart(); return }
        pipeline.muted = !pipeline.muted
        micBtn.text = if (pipeline.muted) "🔇" else "🎤"
        status.text = if (pipeline.muted) "Mute" else "Sun rahi hoon..."
    }

    private fun send() {
        try {
            val t = input.text.toString().trim(); if (t.isEmpty()) return
            input.setText(""); pipeline.sendText(t)
        } catch (e: Exception) {
            Toast.makeText(this, "Error: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleCode() { Prefs.codeMode = !Prefs.codeMode; updateCodeBtn(); Toast.makeText(this, if (Prefs.codeMode) "Code mode ON (high thinking, long output)" else "Code mode OFF", Toast.LENGTH_SHORT).show() }
    private fun updateCodeBtn() { codeBtn.setTextColor(if (Prefs.codeMode) C.ok else C.hint) }

    override fun onResume() { super.onResume(); if (Prefs.hasAnyKey() && Perms.missing(this).none { it.endsWith("RECORD_AUDIO") }) maybeStart() }
    override fun onPause() { super.onPause(); pipeline.stopListening() }
    override fun onDestroy() { pipeline.release(); super.onDestroy() }

    // ---------------- PipelineUi ----------------
    override fun onState(s: State) = runOnUiThread {
        orb.state = s
        status.text = when (s) { State.LISTENING -> "Sun rahi hoon..."; State.RECORDING -> "Shunchi..."; State.THINKING -> "Soch rahi hoon..."; State.SPEAKING -> "Bol rahi hoon..."; State.IDLE -> "Tap korey bolo 💬" }
        redOverlay.animate().alpha(if (s == State.IDLE) 0f else 0.08f).setDuration(if (s == State.IDLE) 500 else 300).start()
    }
    override fun onAmplitude(a: Float) { orb.amp = a }
    override fun onUserMessage(t: String) = runOnUiThread { bubble(t, true) }
    override fun onMyraMessage(t: String) = runOnUiThread { bubble(t, false) }
    override fun onError(msg: String) = runOnUiThread { bubble("⚠ $msg", false) }
    override fun onCode(lang: String, code: String) = runOnUiThread { codeCard(lang, code) }

    override suspend fun confirm(msg: String): Boolean = suspendCancellableCoroutine { cont ->
        runOnUiThread {
            val d = AlertDialog.Builder(this).setMessage(msg)
                .setPositiveButton("Haan") { _, _ -> if (cont.isActive) cont.resume(true) }
                .setNegativeButton("Nahi") { _, _ -> if (cont.isActive) cont.resume(false) }
                .setOnCancelListener { if (cont.isActive) cont.resume(false) }.create()
            d.show(); cont.invokeOnCancellation { runOnUiThread { d.dismiss() } }
        }
    }

    // ---------------- chat views ----------------
    private fun addToChat(v: View, gravity: Int) {
        chat.addView(v, LinearLayout.LayoutParams(-2, -2).apply { this.gravity = gravity; topMargin = dp(6) })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun bubble(t: String, user: Boolean) {
        val v = tv(t, 14f).apply {
            setPadding(dp(12), dp(8), dp(12), dp(8)); maxWidth = dp(290); setTextIsSelectable(true)
            background = if (user) round(C.user, 16, C.red) else round(C.myra, 16)
        }
        addToChat(v, if (user) Gravity.END else Gravity.START)
    }

    private fun codeCard(lang: String, code: String) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(0xFF0B0B0B.toInt(), 12, 0xFF2A2A2A.toInt()); setPadding(dp(10), dp(8), dp(10), dp(8)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("</> $lang  •  ${code.lines().size} lines", 12f, C.ok, true), LinearLayout.LayoutParams(0, -2, 1f))
        val name = edit("file name", "myra_code.${FileSaver.ext(lang)}").apply { textSize = 12f; setPadding(dp(8), dp(4), dp(8), dp(4)); setSingleLine() }
        head.addView(name, LinearLayout.LayoutParams(dp(150), -2))
        card.addView(head)
        val body = tv(code, 12f, 0xFFCFE8CF.toInt()).apply { typeface = Typeface.MONOSPACE; setTextIsSelectable(true); maxLines = 12; setPadding(0, dp(8), 0, dp(8)) }
        card.addView(body)
        val row = LinearLayout(this)
        fun fn() = name.text.toString().trim().ifBlank { "myra_code.${FileSaver.ext(lang)}" }
        fun saved(f: () -> String) { try { Toast.makeText(this, "Saved: ${f()}", Toast.LENGTH_LONG).show() } catch (e: Exception) { Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show() } }
        var expanded = false
        val buttons = listOf(
            "Expand" to { expanded = !expanded; body.maxLines = if (expanded) Int.MAX_VALUE else 12 },
            "Copy" to { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("code", code)); Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show() },
            "File" to { saved { FileSaver.save(this, fn(), "text/plain", code.toByteArray()) } },
            "TXT" to { saved { FileSaver.save(this, fn().substringBeforeLast('.') + ".txt", "text/plain", code.toByteArray()) } },
            "PDF" to { saved { FileSaver.save(this, fn().substringBeforeLast('.') + ".pdf", "application/pdf", FileSaver.pdf(code)) } },
            "Share" to { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, code), "Share code")) },
            "Fix" to { pipeline.sendText("Review this $lang code very carefully for syntax errors, bugs, missing imports and wrong API usage. Return the full corrected code in one block and say what you changed.\n```$lang\n$code\n```", "🔧 Review & fix code", true) }
        )
        buttons.forEachIndexed { i, (label, action) ->
            val b = tv(label, 12f, C.text, true).apply { setPadding(dp(10), dp(6), dp(10), dp(6)); background = round(C.card, 8, C.red); setOnClickListener {
                action(); if (label == "Expand") (this as TextView).text = if (expanded) "Collapse" else "Expand" } }
            row.addView(b, LinearLayout.LayoutParams(-2, -2).apply { if (i > 0) leftMargin = dp(6) })
        }
        card.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        chat.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }
}
