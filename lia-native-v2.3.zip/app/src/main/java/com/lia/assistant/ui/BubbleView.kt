package com.lia.assistant.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min

/** LIA ka gol orb — bubble me chhota, screens par bada. State ke hisaab se rang. */
class BubbleView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    enum class State(val c1: Int, val c2: Int) {
        IDLE(Color.parseColor("#FF6FAE"), Color.parseColor("#8B5CF6")),
        LISTENING(Color.parseColor("#3FE0D0"), Color.parseColor("#2AA8FF")),
        THINKING(Color.parseColor("#FFB547"), Color.parseColor("#FF6FAE")),
        SPEAKING(Color.parseColor("#FFB547"), Color.parseColor("#FF6FAE")),
        ERROR(Color.parseColor("#FF7A85"), Color.parseColor("#B03040"))
    }

    var state: State = State.IDLE
        set(v) { field = v; invalidate() }
    var amp: Float = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 4000; repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val base = min(width, height) * 0.30f
        val r = base * (1f + amp * 0.25f + 0.03f * kotlin.math.sin(t * 6.28f))

        // halo
        paint.shader = RadialGradient(cx, cy, r * 2f,
            intArrayOf(state.c1, Color.TRANSPARENT), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 2f, paint)
        paint.shader = null

        // core sphere
        paint.shader = RadialGradient(cx, cy, r,
            intArrayOf(Color.WHITE, state.c1, state.c2, Color.parseColor("#0A081E")),
            floatArrayOf(0f, 0.25f, 0.7f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, paint)
        paint.shader = null

        // swirl arcs
        paint.style = Paint.Style.STROKE; paint.strokeWidth = r * 0.09f
        for (i in 0..2) {
            paint.color = if (i % 2 == 0) state.c1 else state.c2
            paint.alpha = 70
            c.save(); c.translate(cx, cy); c.rotate(t * 360f * (0.4f + i * 0.25f) + i * 120f)
            c.drawArc(-r * 0.72f, -r * 0.38f, r * 0.72f, r * 0.38f, 0f, 250f, false, paint)
            c.restore()
        }
        paint.alpha = 255; paint.style = Paint.Style.FILL

        // rim
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 4f
        paint.color = state.c1; paint.alpha = 200
        c.drawCircle(cx, cy, r, paint)
        paint.style = Paint.Style.FILL; paint.alpha = 255

        // listening rings
        if (state == State.LISTENING) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f
            paint.color = state.c1
            for (i in 0..1) {
                val rr = r * (1.25f + ((t + i * 0.5f) % 1f) * 0.7f)
                paint.alpha = (140 * (1f - ((t + i * 0.5f) % 1f))).toInt()
                c.drawCircle(cx, cy, rr, paint)
            }
            paint.style = Paint.Style.FILL; paint.alpha = 255
        }
    }
}
