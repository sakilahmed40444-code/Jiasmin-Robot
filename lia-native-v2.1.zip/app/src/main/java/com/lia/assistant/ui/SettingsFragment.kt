package com.lia.assistant.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.lia.assistant.R
import com.lia.assistant.brain.Persona
import com.lia.assistant.data.MemStore
import com.lia.assistant.voice.VoiceEngine

/** Priya Assistant Settings — ACCOUNT | PERMS | CONTROLS | API */
class SettingsFragment : Fragment() {
    private fun act() = activity as MainActivity

    private lateinit var tabRow: LinearLayout
    private lateinit var content: FrameLayout
    private val tabBtns = mutableListOf<Button>()
    private var curTab = 0
    private val TABS = listOf("ACCOUNT", "PERMS", "CONTROLS", "API")

    // account labels
    private var personaTv: TextView? = null
    private var voiceTv: TextView? = null
    private var langTv: TextView? = null
    private var nameTv: TextView? = null
    private var emailTv: TextView? = null
    private var avatarIv: ImageView? = null
    // perms
    private var permStatusTv: TextView? = null
    // memories
    private var memList: LinearLayout? = null
    private var memSearch: EditText? = null

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.col(Ui.BG))
        }
        // header
        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 12), Ui.dp(ctx, 8), Ui.dp(ctx, 4))
        }
        val back = Button(ctx, null, android.R.attr.buttonStyle).apply {
            text = "←"; textSize = 22f; setTextColor(Ui.col(Ui.TEXT))
            setOnClickListener { act().go(MainActivity.TAB_HOME) }
        }
        head.addView(back)
        head.addView(Ui.tv(ctx, "Settings", 24, Ui.TEXT, true))
        root.addView(head)

        // tabs
        tabRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in TABS.indices) {
            val b = Button(ctx, null, android.R.attr.buttonStyle).apply {
                text = TABS[i]; textSize = 13f; isAllCaps = false
                setTypeface(typeface, Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { showTab(i) }
            }
            tabBtns.add(b); tabRow.addView(b)
        }
        root.addView(tabRow)

        content = FrameLayout(ctx).apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(content)

        showTab(curTab)
        return root
    }

    private fun showTab(i: Int) {
        curTab = i
        for (j in tabBtns.indices) {
            val sel = (j == i)
            tabBtns[j].setTextColor(Ui.col(if (sel) Ui.ACCENT else Ui.TEXT3))
            tabBtns[j].setBackgroundColor(Ui.col(if (sel) "#2A1245" else Ui.BG))
        }
        val ctx = requireContext()
        val v = ScrollView(ctx).apply { addView(when (i) {
            0 -> accountView(ctx)
            1 -> permsView(ctx)
            2 -> controlsView(ctx)
            else -> apiView(ctx)
        }) }
        content.removeAllViews()
        content.addView(v)
    }

    // ================= ACCOUNT =================
    private fun accountView(ctx: android.content.Context): View {
        val col = Ui.colLayout(ctx)
        val p = act().prefs

        // profile header
        val ph = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Ui.dp(ctx, 8), 0, Ui.dp(ctx, 8))
        }
        avatarIv = ImageView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 64), Ui.dp(ctx, 64))
        }
        loadAvatar()
        ph.addView(avatarIv)
        val nm = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(ctx, 12), 0, 0, 0)
        }
        nameTv = Ui.tv(ctx, p.name.ifBlank { "Sobuj" }, 20, Ui.TEXT, true)
        emailTv = Ui.tv(ctx, p.email.ifBlank { "email set nahi" }, 13, Ui.TEXT2)
        nm.addView(nameTv); nm.addView(emailTv)
        ph.addView(nm)
        col.addView(ph)
        col.addView(sp(ctx, 8))

        col.addView(acctRow(ctx, "👤 Name", p.name.ifBlank { "Sobuj" }) { editText("Name", p.name.ifBlank { "Sobuj" }) { v -> p.name = v; nameTv?.text = v } })
        col.addView(acctRow(ctx, "📧 Email", p.email.ifBlank { "set karo" }) { editText("Email", p.email) { v -> p.email = v; emailTv?.text = v.ifBlank { "email set nahi" } } })
        col.addView(acctRow(ctx, "🖼️ Profile Picture", "Gallery se chuno") { pickImage() })
        personaTv = Ui.tv(ctx, "", 14, Ui.TEXT2)
        col.addView(acctRow(ctx, "🎭 Personality", "", personaTv) { pickPersona() })
        voiceTv = Ui.tv(ctx, "", 14, Ui.TEXT2)
        col.addView(acctRow(ctx, "🔊 Voice", "", voiceTv) { pickGeminiVoice() })
        langTv = Ui.tv(ctx, "", 14, Ui.TEXT2)
        col.addView(acctRow(ctx, "🌐 Language", "", langTv) { pickLang() })
        col.addView(acctRow(ctx, "❓ Help & Support", "") {
            AlertDialog.Builder(ctx).setTitle("Help & Support")
                .setMessage("Priya Assistant — voice-first AI companion.\n\n• Neeche ❤️ dabao aur bolo\n• \"youtube kholo\" — app kholo\n• \"yaad rakho...\" — memory save\n• Website Forge se bolke website banao\n\nKoi dikkat? Screenshot bhej do! 💗")
                .setPositiveButton("OK", null).show()
        })
        col.addView(acctRow(ctx, "🔒 Privacy Policy", "") {
            AlertDialog.Builder(ctx).setTitle("Privacy Policy")
                .setMessage("Tumhara data sirf tumhare phone me rehta hai.\nAPI keys, naam, memories — kuch bhi hamare server par nahi jata.\nGemini/OpenRouter/Serp ko sirf wahi text jata hai jo tum bhejti ho.")
                .setPositiveButton("OK", null).show()
        })
        col.addView(acctRow(ctx, "📜 Terms of Service", "") {
            AlertDialog.Builder(ctx).setTitle("Terms of Service")
                .setMessage("Priya Assistant jaise hai waise di gayi hai.\nVoice features ke liye internet chahiye.\nGalat istemal ki zimmedari user ki hogi.")
                .setPositiveButton("OK", null).show()
        })
        col.addView(sp(ctx, 12))
        val out = Ui.btn(ctx, "LOG OUT", false) {
            p.name = ""; p.email = ""; p.profilePic = ""
            nameTv?.text = "Sobuj"; emailTv?.text = "email set nahi"; loadAvatar()
            act().toast("Logged out")
        }
        out.setTextColor(Ui.col(Ui.ERROR))
        col.addView(out)
        col.addView(sp(ctx, 24))

        refreshAccountLabels()
        return col
    }

    private fun acctRow(ctx: android.content.Context, title: String, value: String, valueTv: TextView? = null, onClick: (() -> Unit)? = null): View {
        val r = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.col(Ui.SURFACE))
            val pad = Ui.dp(ctx, 12)
            setPadding(pad, pad, pad, pad)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = Ui.dp(ctx, 6)
            layoutParams = lp
            if (onClick != null) setOnClickListener { onClick() }
        }
        val t = Ui.tv(ctx, title, 15, Ui.TEXT, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        r.addView(t)
        if (valueTv != null) r.addView(valueTv) else r.addView(Ui.tv(ctx, value, 14, Ui.TEXT2))
        r.addView(Ui.tv(ctx, "›", 18, Ui.TEXT3))
        return r
    }

    private fun editText(title: String, cur: String, onSave: (String) -> Unit) {
        val ctx = requireContext()
        val et = EditText(ctx).apply { setText(cur); setTextColor(Ui.col(Ui.TEXT)) }
        AlertDialog.Builder(ctx).setTitle(title).setView(et)
            .setPositiveButton("Save") { _, _ -> onSave(et.text.toString().trim()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun loadAvatar() {
        val iv = avatarIv ?: return
        val pic = act().prefs.profilePic
        try {
            if (pic.isNotBlank()) iv.setImageURI(Uri.parse(pic))
            else iv.setImageResource(R.mipmap.ic_launcher)
        } catch (_: Exception) {
            try { iv.setImageResource(R.mipmap.ic_launcher) } catch (_: Exception) { }
        }
    }

    private fun pickImage() {
        try {
            val i = Intent(Intent.ACTION_PICK).apply { type = "image/*" }
            startActivityForResult(i, 77)
        } catch (_: Exception) { act().toast("Gallery nahi khul rahi") }
    }

    @Deprecated("deprecated")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 77 && res == Activity.RESULT_OK) {
            val uri: Uri? = d?.data
            if (uri != null) {
                try { requireContext().contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
                act().prefs.profilePic = uri.toString()
                loadAvatar()
                act().toast("Profile picture set! 🖼️")
            }
        }
    }

    private fun refreshAccountLabels() {
        val p = act().prefs
        val per = Persona.byKey(p.persona)
        personaTv?.text = "${per.icon} ${per.title}"
        voiceTv?.text = when {
            p.geminiVoice.isNotBlank() -> "🌐 ${p.geminiVoice} (Gemini)"
            p.ttsVoiceName.isNotBlank() -> "📱 ${p.ttsVoiceName.take(24)}"
            else -> "🇧🇩 Bangla default"
        }
        langTv?.text = when (p.langMode) { "bn" -> "🇧🇩 Bangla"; "hi" -> "Hindi"; "hing" -> "Hinglish"; "en" -> "English"; else -> "Auto" }
    }

    private fun pickPersona() {
        val ctx = requireContext()
        val items = Persona.values().map { "${it.icon} ${it.title} — ${it.desc}" }.toTypedArray()
        val cur = Persona.values().indexOf(Persona.byKey(act().prefs.persona))
        AlertDialog.Builder(ctx).setTitle("🎭 Personality chuno")
            .setSingleChoiceItems(items, cur) { d, w ->
                act().prefs.persona = Persona.values()[w].key
                act().mem.clear()
                refreshAccountLabels()
                act().toast("Personality: ${Persona.values()[w].title}")
                d.dismiss()
            }.show()
    }

    private fun pickLang() {
        val ctx = requireContext()
        val items = arrayOf("🇧🇩 Bangla (বাংলা)", "🔀 Auto", "Hindi", "Hinglish", "English")
        val vals = arrayOf("bn", "auto", "hi", "hing", "en")
        val cur = vals.indexOf(act().prefs.langMode).coerceAtLeast(0)
        AlertDialog.Builder(ctx).setTitle("Bhasha chuno")
            .setSingleChoiceItems(items, cur) { d, w ->
                act().prefs.langMode = vals[w]
                refreshAccountLabels(); d.dismiss()
            }.show()
    }

    /** Sab voices — Android TTS (phone) + Gemini. Default: Bangla. */
    private fun pickGeminiVoice() {
        val ctx = requireContext()
        val p = act().prefs
        act().toast("Voices load ho rahi hain…")
        VoiceEngine.fetchVoiceNames(ctx) { androidVoices ->
            activity?.runOnUiThread {
                val geminiVoices = listOf("Achernar","Aoede","Autonoe","Callirrhoe","Despina","Erinome","Gacrux","Kore","Laomedeia","Leda","Pulcherrima","Sulafat","Vindemiatrix","Zephyr")
                val items = mutableListOf<String>()
                val isGemini = mutableListOf<Boolean>()
                val values = mutableListOf<String>()
                // default Bangla first
                items.add("🇧🇩 Default — Bangla (phone voice)"); isGemini.add(false); values.add("")
                for (v in androidVoices) { items.add("📱 $v"); isGemini.add(false); values.add(v) }
                for (v in geminiVoices) { items.add("🌐 $v (Gemini)"); isGemini.add(true); values.add(v) }
                val cur = when {
                    p.geminiVoice.isNotBlank() -> {
                        val i = geminiVoices.indexOf(p.geminiVoice)
                        if (i >= 0) 1 + androidVoices.size + i else 0
                    }
                    p.ttsVoiceName.isNotBlank() -> {
                        val i = androidVoices.indexOf(p.ttsVoiceName)
                        if (i >= 0) 1 + i else 0
                    }
                    else -> 0
                }
                AlertDialog.Builder(ctx).setTitle("🔊 Voice chuno")
                    .setSingleChoiceItems(items.toTypedArray(), cur.coerceAtLeast(0)) { d, w ->
                        if (isGemini[w]) {
                            p.geminiVoice = values[w]
                            p.ttsVoiceName = ""
                            act().toast("Voice: ${values[w]} 🎙️" + if (p.apiKey.isBlank()) "\n(API key lagao tab ye voice bolegi)" else "")
                        } else {
                            p.geminiVoice = ""
                            p.ttsVoiceName = values[w]
                            act().toast(if (values[w].isBlank()) "Bangla default voice ✅🇧🇩" else "Voice set ✅")
                        }
                        refreshAccountLabels()
                        d.dismiss()
                    }.show()
            }
        }
    }

    // ================= PERMS =================
    private fun permsView(ctx: android.content.Context): View {
        val col = Ui.colLayout(ctx)
        permStatusTv = Ui.tv(ctx, "", 15, Ui.TEXT, true).apply { gravity = Gravity.CENTER }
        col.addView(permStatusTv)
        col.addView(sp(ctx, 6))
        col.addView(Ui.btn(ctx, "🔐 GRANT ALL PERMISSIONS", true) {
            // SetupFragment ka grant-all reuse: child fragment me button hai
            act().toast("Neeche har row par tap karke allow karo 👇")
        })
        col.addView(sp(ctx, 8))
        val holder = FrameLayout(ctx).apply { id = View.generateViewId() }
        col.addView(holder)
        childFragmentManager.beginTransaction().replace(holder.id, SetupFragment()).commit()
        updatePermStatus()
        return col
    }

    private fun updatePermStatus() {
        // SetupFragment khud rows dikhata hai; yahan simple count
        permStatusTv?.text = "Neeche har permission ko ✅ karo"
    }

    // ================= CONTROLS (Memories) =================
    private fun controlsView(ctx: android.content.Context): View {
        val col = Ui.colLayout(ctx)
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.tv(ctx, "My Memories", 22, Ui.TEXT, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        head.addView(Ui.btn(ctx, "+ ADD", true) { addMemory() })
        col.addView(head)
        memSearch = EditText(ctx).apply {
            hint = "Search memories..."
            setHintTextColor(Ui.col(Ui.TEXT3)); setTextColor(Ui.col(Ui.TEXT))
            setBackgroundColor(Ui.col(Ui.RAISED))
            val pad = Ui.dp(ctx, 12); setPadding(pad, pad, pad, pad)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) { renderMems() }
                override fun afterTextChanged(a: android.text.Editable?) {}
            })
        }
        col.addView(memSearch)
        col.addView(sp(ctx, 8))
        memList = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(memList)
        col.addView(sp(ctx, 24))
        renderMems()
        return col
    }

    private fun renderMems() {
        val ctx = context ?: return
        val ml = memList ?: return
        ml.removeAllViews()
        val q = memSearch?.text?.toString()?.lowercase()?.trim() ?: ""
        val mems = MemStore.list(ctx).filter { q.isEmpty() || it.lowercase().contains(q) }
        if (mems.isEmpty()) {
            ml.addView(Ui.tv(ctx, "🧠", 44, Ui.TEXT3).apply { gravity = Gravity.CENTER })
            ml.addView(Ui.tv(ctx, "No memories yet", 18, Ui.TEXT, true).apply { gravity = Gravity.CENTER })
            ml.addView(Ui.tv(ctx, "Tap + Add — Priya will remember it for you", 13, Ui.TEXT3).apply { gravity = Gravity.CENTER })
            return
        }
        for (m in mems) {
            val r = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(Ui.col(Ui.SURFACE))
                val pad = Ui.dp(ctx, 10); setPadding(pad, pad, pad, pad)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.topMargin = Ui.dp(ctx, 6); layoutParams = lp
            }
            val t = Ui.tv(ctx, "• $m", 14, Ui.TEXT).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val del = Button(ctx, null, android.R.attr.buttonStyle).apply {
                text = "❌"; setOnClickListener { MemStore.remove(ctx, m); renderMems(); act().toast("Delete ho gaya") }
            }
            r.addView(t); r.addView(del)
            ml.addView(r)
        }
    }

    private fun addMemory() {
        val ctx = requireContext()
        val et = EditText(ctx).apply {
            hint = "e.g. Mera birthday 5 January hai"
            setHintTextColor(Ui.col(Ui.TEXT3)); setTextColor(Ui.col(Ui.TEXT))
            setPadding(40, 20, 40, 20)
        }
        AlertDialog.Builder(ctx).setTitle("🧠 Yaad rakho").setView(et)
            .setPositiveButton("Save") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotBlank()) { MemStore.add(ctx, t); renderMems(); act().toast("Yaad rakh liya ✅") }
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ================= API =================
    private fun apiView(ctx: android.content.Context): View {
        val col = Ui.colLayout(ctx)
        col.addView(Ui.tv(ctx, "CONNECTED APIS", 13, Ui.TEXT2, true))
        col.addView(sp(ctx, 6))
        col.addView(apiCard(ctx, "Gemini API", "Manage your Gemini API key", "apiKey"))
        col.addView(apiCard(ctx, "Serp API", "Manage your Serp API key (web search)", "serpKey"))
        col.addView(apiCard(ctx, "OpenRouter API", "Manage your OpenRouter API key (backup brain)", "openRouterKey"))
        col.addView(sp(ctx, 8))
        col.addView(Ui.tv(ctx, "Gemini key free me: aistudio.google.com → Get API Key 🔑", 12, Ui.TEXT3))
        col.addView(sp(ctx, 24))
        return col
    }

    private fun apiCard(ctx: android.content.Context, title: String, desc: String, key: String): View {
        val p = act().prefs
        val cur = when (key) { "apiKey" -> p.apiKey; "serpKey" -> p.serpKey; else -> p.openRouterKey }
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.col(Ui.SURFACE))
            val pad = Ui.dp(ctx, 12); setPadding(pad, pad, pad, pad)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = Ui.dp(ctx, 8); layoutParams = lp
        }
        val top = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Ui.tv(ctx, "🌐", 26, Ui.ACCENT))
        val tt = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(Ui.dp(ctx, 10), 0, 0, 0)
        }
        tt.addView(Ui.tv(ctx, title, 17, Ui.TEXT, true))
        tt.addView(Ui.tv(ctx, desc, 12, Ui.TEXT2))
        top.addView(tt)
        val badge = Ui.tv(ctx, if (cur.isNotBlank()) "Active" else "Not set", 12,
            if (cur.isNotBlank()) Ui.NEON_GREEN else Ui.TEXT3, true)
        top.addView(badge)
        card.addView(top)
        val bot = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val masked = if (cur.length > 6) cur.take(4) + "••••••••••••" else "••••••••"
        bot.addView(Ui.tv(ctx, masked, 14, Ui.TEXT2).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        bot.addView(Ui.btn(ctx, "CHANGE", false) { editApiKey(title, key) })
        card.addView(bot)
        return card
    }

    private fun editApiKey(title: String, key: String) {
        val ctx = requireContext()
        val p = act().prefs
        val cur = when (key) { "apiKey" -> p.apiKey; "serpKey" -> p.serpKey; else -> p.openRouterKey }
        val et = EditText(ctx).apply {
            setText(cur); setHintTextColor(Ui.col(Ui.TEXT3)); setTextColor(Ui.col(Ui.TEXT))
            hint = "API key paste karo"
        }
        AlertDialog.Builder(ctx).setTitle("🔑 $title").setView(et)
            .setPositiveButton("Save") { _, _ ->
                val v = et.text.toString().trim()
                when (key) { "apiKey" -> p.apiKey = v; "serpKey" -> p.serpKey = v; else -> p.openRouterKey = v }
                act().toast("Save ho gaya ✅")
                showTab(3)
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun sp(ctx: android.content.Context, dp: Int): View {
        val v = View(ctx)
        v.layoutParams = LinearLayout.LayoutParams(1, Ui.dp(ctx, dp))
        return v
    }
}
