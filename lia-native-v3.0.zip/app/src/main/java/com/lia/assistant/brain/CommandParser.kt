package com.lia.assistant.brain

/** Voice/text se nikle hue commands. */
sealed class Action {
    data class OpenApp(val appName: String) : Action()
    data class Call(val target: String) : Action()
    object EndCall : Action()
    data class YtSearch(val query: String) : Action()
    data class FbPost(val text: String) : Action()
    data class PythonCode(val query: String) : Action()
    object ShowCoding : Action()
    object ChromeForge : Action()
    data class Message(val app: String, val to: String, val msg: String) : Action()
    data class Forge(val subject: String) : Action()
    data class Tap(val target: String) : Action()
    data class Scroll(val down: Boolean) : Action()
    data class Type(val text: String) : Action()
    object ReadScreen : Action()
    object GoBack : Action()
    object GoHome : Action()
    object Time : Action()
    object Date : Action()
    object Joke : Action()
    object Help : Action()
    data class Honest(val reply: String) : Action()
    object Greet : Action()
    object MyName : Action()
    object Thanks : Action()
    object Bye : Action()
    data class Remember(val text: String) : Action()
}

object CommandParser {

    fun parse(raw: String): Action? {
        val t = raw.trim()
        val s = normalizeStt(t.lowercase())

        // ---- Website Forge ----
        if (isForgeIntent(s)) return Action.Forge(forgeSubject(t))

        // ---- Call: "mummy ko call karo", "call karo 98765...", "রহিমকে কল করো" ----
        if (s.contains("call") || s.contains("phone lagao") || s.contains("dial karo") ||
            s.contains("কল কর") || s.contains("ফোন কর")) {
            if (s.contains("record") || s.contains("রেকর্ড"))
                return Action.Honest("Call record karna Android me allowed nahi hai — system isko rokta hai, isliye main ye nahi kar sakti. 😔")
            val m1 = Regex("(?:call|phone|dial)\\s+(?:karo|kar do|lagao)?\\s*([a-zA-Z\\u0900-\\u097F ]*?)\\s*(\\+?[\\d][\\d\\s\\-()]{4,})?").find(s)
            val m2 = Regex("([a-zA-Z\\u0900-\\u097F ]+?)\\s*ko\\s+(?:call|phone)\\s*karo").find(s)
            val target = (m1?.groupValues?.getOrNull(2)?.takeIf { it.isNotBlank() }
                ?: m1?.groupValues?.getOrNull(1)
                ?: m2?.groupValues?.getOrNull(1) ?: "").trim()
            return Action.Call(target)
        }

        // ---- Message: "rahul ko whatsapp karo hello" ----
        if (s.contains("whatsapp") || (s.contains("sms") && s.contains("karo")) || s.contains("message karo") || s.contains("msg karo")) {
            val app = if (s.contains("whatsapp")) "whatsapp" else "sms"
            var to = ""
            var msg = ""
            val koM = Regex("([a-zA-Z\\u0900-\\u097F]+)\\s*ko\\s*(whatsapp|sms|message)").find(s)
            if (koM != null) {
                to = koM.groupValues[1]
                msg = s.substring(koM.range.last + 1).replace(Regex("^(karo|kar do|bhejo)\\s*"), "").trim()
            } else {
                msg = s.replace(Regex(".*?(whatsapp|sms|message|msg)\\s*(karo|kar do|bhejo)?\\s*"), "").trim()
            }
            return Action.Message(app, to, msg)
        }

        // ---- Screen control (accessibility) ----
        if (s.contains("screen padho") || s.contains("screen dekho") || s.contains("kya dikh raha") || s.contains("screen dikhao") ||
            s.contains("টেক্সট দেখাও") || s.contains("স্ক্রিন দেখাও"))
            return Action.ReadScreen
        val tapM = Regex("(.+?)\\s*(par|pe)\\s*(click|tap|dabao|daba do)").find(s)
            ?: Regex("(?:tap|click)\\s+(?:karo\\s+)?(.+)").find(s)
        if (tapM != null) {
            val target = (tapM.groupValues.getOrNull(1) ?: "").trim()
            if (target.length > 1) return Action.Tap(target)
        }
        if (s.contains("upar scroll") || s.contains("scroll up") || s.contains("upar karo")) return Action.Scroll(false)
        if (s.contains("neeche scroll") || s.contains("scroll down") || s.contains("neeche karo")) return Action.Scroll(true)
        val typeM = Regex("(?:type karo|likho|type)\\s+(.+)").find(s)
        if (typeM != null) return Action.Type(typeM.groupValues[1].trim())
        if (s.contains("wapas") || s.contains("peeche jao") || s == "back") return Action.GoBack
        if (s.contains("home jao") || s == "home") return Action.GoHome

        // ---- Python: "python likho ...", "python me code likho" ----
        if (s.contains("python") && Regex("likh|lekh|code|bana").containsMatchIn(s)) {
            val q = s.replace(Regex(".*?(python)\\s*"), "").replace(Regex("^(me|mein)\\s+"), "")
                .replace(Regex("\\s*(likho|likh do|lekh|likh|code likho)\\s*$"), "").trim()
            return Action.PythonCode(q.ifBlank { "ek kaam ka program" })
        }
        // ---- Coding dekhao: "coding kholo", "coding dekhao", "meri coding dikhao" ----
        if (Regex("(coding|code)\\s*(kholo|khol|dekhao|dikhao|dikha)").containsMatchIn(s) ||
            s.contains("কোডিং দেখাও") || s.contains("কোডিং খোলো"))
            return Action.ShowCoding
        // ---- Chrome + website: "chrome kholo website banao" ----
        if ((s.contains("chrome") || s.contains("ক্রোম")) &&
            Regex("website|web ?page|site|bana").containsMatchIn(s))
            return Action.ChromeForge

        // ---- YouTube search/play: "youtube par X search karo", "X gaana chalao", "ইউটিউবে X সার্চ কর" ----
        if (s.contains("youtube") || s.contains("ইউটিউব")) {
            val qm = Regex("(?:search karo|search kar|search|dhoondo|dhoondho|chalao|chala do|play karo|play|bajao|সার্চ কর|সার্চ|চালাও|বাজাও)\\s+(.+)").find(s)
                ?: Regex("(.+?)\\s+(?:search karo|search kar|search|chalao|play karo|play|সার্চ কর|সার্চ)").find(s)
            if (qm != null) {
                val q = qm.groupValues[1].trim().trimEnd('?', '!', '.')
                if (q.length > 1 && !q.contains("youtube") && !q.contains("ইউটিউব"))
                    return Action.YtSearch(q)
            }
        }
        // ---- Facebook post: "facebook par post karo <text>", "ফেসবুকে পোস্ট করো" ----
        if ((s.contains("facebook") || s.contains("ফেসবুক")) &&
            (s.contains("post karo") || s.contains("post kar") || s.contains("post koro") || s.contains("পোস্ট কর"))) {
            val pm = Regex("(?:post karo|post kar|post koro|পোস্ট করো|পোস্ট কর)\\s*(.*)").find(s)
            return Action.FbPost(pm?.groupValues?.getOrNull(1)?.trim() ?: "")
        }
        // ---- End call: "call kaat do", "কল কেটে দাও" ----
        if (Regex("call\\s+(ko\\s+)?(kaat|kat|kate|cut|end)\\s*(do|dao|karo)?").containsMatchIn(s) ||
            s.contains("কেটে দাও") || s.contains("কল কাটো") || s.contains("phone kaat"))
            return Action.EndCall

        // ---- Open app: "youtube kholo", "open chrome", "facebook open", "ইউটিউব খোলো", "ফেসবুকে ঢুকো" ----
        val openKw = listOf("khol do", "open karo", "launch karo", "start karo", "kholo", "khol", "open", "launch", "start",
            "খোলো", "খুলে দাও", "খুলো", "ঢুকো", "dhuko", "khol do")
        var appQuery: String? = null
        for (kw in openKw) {
            if (s.startsWith("$kw ")) { appQuery = s.removePrefix("$kw ").trim(); break }
            if (s.endsWith(" $kw")) { appQuery = s.removeSuffix(" $kw").trim(); break }
        }
        if (appQuery != null) {
            val clean = cleanAppQuery(appQuery)
            if (clean.length > 1 && !clean.contains("website")) return Action.OpenApp(clean)
        }

        // ---- Yaad rakho: "yaad rakho mera birthday 5 jan hai" ----
        val remM = Regex("(?:yaad rakho|yaad rakhna|remember)(?: that)?\\s+(.+)").find(s)
        if (remM != null) {
            val what = remM.groupValues[1].trim()
            if (what.length > 2) return Action.Remember(what)
        }

        // ---- Small talk ----
        if (t.matches(Regex("(?i)^(namaste|namaskar|salaam|assalam.*|hello|hi+|hey)\\b.*"))) return Action.Greet
        if (s.contains("tumhara naam") || s.contains("tera naam") || s.contains("your name") || s.contains("who are you") || s.contains("tum kaun")) return Action.MyName
        if (s.contains("time") || s.contains("samay") || s.contains("baj rahe") || s.contains("kitne baje")) return Action.Time
        if (s.contains("date") || s.contains("tarikh")) return Action.Date
        if (s.contains("joke") || s.contains("hasao") || s.contains("majedar")) return Action.Joke
        if (s.contains("help") || s.contains("madad") || s.contains("kya kar sakti") || s.contains("kya kar sakte")) return Action.Help
        if (s.contains("thank") || s.contains("shukriya") || s.contains("dhanyavad")) return Action.Thanks
        if (s.contains("bye") || s.contains("alvida") || s.contains("good night") || s.contains("shubh ratri")) return Action.Bye

        return null // → brain chat
    }

    fun isForgeIntent(s: String): Boolean {
        val hasSite = Regex("website|web ?page|landing ?page|site|वेबसाइट").containsMatchIn(s)
        val hasVerb = Regex("bana|banao|banado|banade|build|create|make|design|tayar").containsMatchIn(s)
        if (hasSite && hasVerb) return true
        // "coding likho", "code likh do"
        if (Regex("coding|\\bcode\\b|program").containsMatchIn(s) &&
            Regex("likh|lekh|bana|banao|create|write").containsMatchIn(s)) return true
        // "meri website ka ye change karo", "website update karo"
        if (hasSite && Regex("change|badal|palat|update|thik karo|naya karo").containsMatchIn(s)) return true
        return false
    }

    fun forgeSubject(t: String): String {
        var s = t.replace(Regex("^(lia[,.]?\\s*|please\\s*)", RegexOption.IGNORE_CASE), "").trim()
        s = s.replace(Regex("\\s*(bana|banao|banado|banade|build karo|build|create karo|create|make|design karo|design|taiyaar karo|please)\\s*$", RegexOption.IGNORE_CASE), "").trim()
        val m = Regex("(?:ek|a|an)\\s+(.+?)\\s+(?:ki|ka|ke)\\s+(?:animated\\s+)?(?:website|web ?page|site)", RegexOption.IGNORE_CASE).find(s)
            ?: Regex("(?:mera|meri|mere|my)\\s+(.+?)\\s+(?:website|web ?page|site)", RegexOption.IGNORE_CASE).find(s)
            ?: Regex("(.+?)\\s+(?:ki|ka|ke)\\s+(?:animated\\s+)?(?:website|web ?page|site)", RegexOption.IGNORE_CASE).find(s)
            ?: Regex("(?:website|web ?page|site)\\s+(?:for|of|about|on|par)\\s+(.+)", RegexOption.IGNORE_CASE).find(s)
        var subj = (m?.groupValues?.getOrNull(1) ?: s).replace(Regex("^(ek|a|an)\\s+", RegexOption.IGNORE_CASE), "").trim()
        subj = subj.replace(Regex("\\b(animated|website|web ?page|site)\\b", RegexOption.IGNORE_CASE), "").replace(Regex("\\s+"), " ").trim()
        return subj.ifEmpty { "tumhara business" }
    }

    /** STT ki galtiyan sudharo — manusher moto samjho. */
    private val STT_FIX = listOf(
        "ইউ টিউব" to "ইউটিউব", "you tube" to "youtube", "ইউটুব" to "ইউটিউব",
        "ফেস বুক" to "ফেসবুক", "face book" to "facebook",
        "হোয়াটসঅ্যাপ" to "whatsapp", "হোয়াটস আপ" to "whatsapp",
        "ক্রোম" to "chrome",
        "প্লে স্টোর" to "playstore",
        "জিমেইল" to "gmail",
        "ক্যামেরা" to "camera",
        "গ্যালারি" to "gallery",
        "সেটিং" to "settings",
        "খুলে দাও" to "খোলো"
    )

    fun normalizeStt(s: String): String {
        var r = " $s "
        for ((a, b) in STT_FIX) r = r.replace(a, b)
        return r.trim().replace(Regex("\\s+"), " ")
    }

    /** "শূন্য এক সাত" / "zero one seven" → "017" */
    fun wordsToDigits(s: String): String {
        val map = mapOf(
            "শূন্য" to "0", "জিরো" to "0", "zero" to "0",
            "এক" to "1", "one" to "1", "ওয়ান" to "1",
            "দুই" to "2", "two" to "2", "টু" to "2",
            "তিন" to "3", "three" to "3", "থ্রি" to "3",
            "চার" to "4", "four" to "4", "ফোর" to "4",
            "পাঁচ" to "5", "five" to "5", "ফাইভ" to "5",
            "ছয়" to "6", "six" to "6", "সিক্স" to "6",
            "সাত" to "7", "seven" to "7", "সেভেন" to "7",
            "আট" to "8", "eight" to "8", "এইট" to "8",
            "নয়" to "9", "nine" to "9", "নাইন" to "9"
        )
        val sb = StringBuilder()
        for (w in s.split(" ")) {
            map[w]?.let { sb.append(it) }
            if (w.all { it.isDigit() }) sb.append(w)
        }
        return sb.toString()
    }

    /** App naam se filler words hatao: "amar mobile facebook app" → "facebook" */
    private val APP_FILLERS = setOf(
        "amar", "amr", "mera", "mere", "meri", "mobile", "phone", "smartphone",
        "app", "apps", "application", "ko", "karo", "kro", "please", "pls",
        "ek", "zara", "wala", "wali", "wale", "the", "koi", "bhi", "mujhe", "muje", "mein", "me"
    )

    fun cleanAppQuery(q: String): String {
        return q.split(" ").filter { it.length > 1 && it !in APP_FILLERS }.joinToString(" ").trim()
    }
}
