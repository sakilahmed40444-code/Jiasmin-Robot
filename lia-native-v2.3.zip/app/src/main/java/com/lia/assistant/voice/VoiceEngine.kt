package com.lia.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Native STT (SpeechRecognizer) + TTS — phone ka apna engine, isliye
 * web wali "sunai deta hai, bolta nahi" dikkat yahan nahi hogi.
 */
class VoiceEngine(private val ctx: Context) {

    interface Cb {
        fun onListening()
        fun onPartial(text: String)
        fun onResult(text: String)
        fun onError(msg: String)
        fun onSpeakDone()
    }

    var cb: Cb? = null
    var muted = false
    /** Gemini TTS voice ("Kore"...) + key — dono set hon to Gemini bolegi, warna Android TTS. */
    var geminiVoice: String? = null
    var geminiKey: String? = null

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var sr: SpeechRecognizer? = null
    private var listening = false

    init {
        tts = TextToSpeech(ctx) { st ->
            ttsReady = st == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onError(id: String?) { cb?.onSpeakDone() }
                override fun onDone(id: String?) { cb?.onSpeakDone() }
            })
        }
    }

    /** lang: "hi" / "hing" / "en" / "bn" */
    fun setLang(lang: String, rate: Float) {
        val loc = when (lang) {
            "hi" -> Locale("hi", "IN")
            "bn" -> Locale("bn", "BD")
            "en" -> Locale.US
            else -> Locale("en", "IN")
        }
        try {
            val r = tts?.setLanguage(loc)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.US
            }
        } catch (_: Exception) {}
        tts?.setSpeechRate(rate)
    }

    fun speak(text: String) {
        if (muted || text.isBlank()) { cb?.onSpeakDone(); return }
        val gv = geminiVoice?.takeIf { it.isNotBlank() }
        val gk = geminiKey?.takeIf { it.isNotBlank() }
        if (gv != null && gk != null) {
            // Gemini TTS — Kore jaisi voice
            GeminiTts.speak(text, gv, gk) { cb?.onSpeakDone() }
            return
        }
        if (!ttsReady) {
            // TTS ready nahi — thoda ruk ke retry
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                if (ttsReady) speak(text) else cb?.onSpeakDone()
            }, 800)
            return
        }
        try {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lia_${System.currentTimeMillis()}")
        } catch (_: Exception) {
            cb?.onSpeakDone()
        }
    }

    fun isSpeaking(): Boolean = try { tts?.isSpeaking == true } catch (_: Exception) { false }

    /** Chuni hui TTS voice lagao (naam se). */
    fun setVoiceByName(name: String) {
        if (name.isBlank()) return
        try {
            tts?.voices?.find { it.name == name }?.let { tts?.voice = it }
        } catch (_: Exception) {}
    }

    companion object {
        /** Phone me available TTS voices ke naam — chooser dialog ke liye. */
        fun fetchVoiceNames(ctx: Context, cb: (List<String>) -> Unit) {
            try {
                var tts: TextToSpeech? = null
                tts = TextToSpeech(ctx) { st ->
                    try {
                        val names = if (st == TextToSpeech.SUCCESS)
                            tts?.voices?.map { it.name }?.sorted() ?: emptyList()
                        else emptyList()
                        cb(names)
                    } catch (_: Exception) { cb(emptyList()) }
                    try { tts?.shutdown() } catch (_: Exception) {}
                }
            } catch (_: Exception) { cb(emptyList()) }
        }
    }

    fun listen(lang: String) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            cb?.onError("Is phone me speech recognition nahi hai")
            return
        }
        stopListen()
        val localeTag = when (lang) {
            "hi" -> "hi-IN"
            "bn" -> "bn-BD"
            "en" -> "en-US"
            else -> "en-IN" // Hinglish ke liye en-IN best
        }
        sr = SpeechRecognizer.createSpeechRecognizer(ctx)
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { listening = true; cb?.onListening() }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false }
            override fun onError(e: Int) {
                listening = false
                val msg = when (e) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "no_match"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "timeout"
                    SpeechRecognizer.ERROR_NETWORK -> "net"
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "net_timeout"
                    SpeechRecognizer.ERROR_AUDIO -> "audio"
                    SpeechRecognizer.ERROR_SERVER -> "server"
                    SpeechRecognizer.ERROR_CLIENT -> "client"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "busy"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "no_perm"
                    else -> "err_$e"
                }
                cb?.onError(msg)
            }
            override fun onResults(r: Bundle?) {
                listening = false
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (t.isNotBlank()) cb?.onResult(t) else cb?.onError("no_match")
            }
            override fun onPartialResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (t.isNotBlank()) cb?.onPartial(t)
            }
            override fun onEvent(e: Int, p: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { sr?.startListening(intent) } catch (_: Exception) { cb?.onError("start_failed") }
    }

    fun stopListen() {
        listening = false
        try { sr?.cancel() } catch (_: Exception) {}
        try { sr?.destroy() } catch (_: Exception) {}
        sr = null
    }

    /** Push-to-talk: ungli uthate hi jo suna, uska result lao. */
    fun finishListen() {
        try { sr?.stopListening() } catch (_: Exception) {}
    }

    fun stopSpeak() { try { tts?.stop() } catch (_: Exception) {}; GeminiTts.stop() }

    fun destroy() {
        stopListen(); stopSpeak()
        try { tts?.shutdown() } catch (_: Exception) {}
        tts = null
    }
}
