package com.lia.assistant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.lia.assistant.service.LiaAccessibilityService

/**
 * Sab permission ek screen par — one-tap rows, live ✅/❌ status.
 * Sach: Accessibility aur Overlay Android TUMSE khud maangega —
 * koi app inhe khud on nahi kar sakti.
 */
class SetupFragment : Fragment() {
    private fun act() = activity as MainActivity
    private lateinit var list: LinearLayout

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val sv = Ui.scrollCol(ctx)
        val col = Ui.colLayout(ctx)
        sv.addView(col)
        col.addView(Ui.title(ctx, "Full Setup 🔐"))
        col.addView(Ui.sub(ctx, "LIA ko full control chahiye to ye sab on karo. Jo ❌ hai, us par tap karo — system settings khul jayegi."))
        val grantRow = Ui.row(ctx); grantRow.gravity = android.view.Gravity.CENTER_HORIZONTAL
        grantRow.addView(Ui.btn(ctx, "GRANT ALL PERMISSIONS") { grantAll() })
        col.addView(grantRow)
        val note = Ui.card(ctx)
        val nc = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        nc.addView(Ui.tv(ctx, "⚠️ Ek sach", 15, Ui.TEXT, true))
        nc.addView(Ui.tv(ctx, "Accessibility aur 'Draw over apps' Android tumse KHUD maangega — koi app inhe khud se on nahi kar sakti. Bas ek baar Allow dabana hai.", 13, Ui.TEXT2))
        note.addView(nc)
        col.addView(note)
        list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list)
        return sv
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val ctx = requireContext()
        list.removeAllViews()
        val pm = ctx.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager

        addRow("🎙️", "Microphone", "Voice sunne ke liye",
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
            "Allow karo") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 50)
        }
        addRow("🫧", "Draw over apps (Bubble)", "Minimize par gol bubble ke liye",
            Settings.canDrawOverlays(ctx), "Kholo") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
        }
        addRow("♿", "Accessibility (LIA Service)", "Screen dekhna, tap, scroll, type — full control",
            LiaAccessibilityService.isEnabled(ctx), "Kholo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        val battOk = if (Build.VERSION.SDK_INT >= 23) pm.isIgnoringBatteryOptimizations(ctx.packageName) else true
        addRow("🔋", "Battery optimization OFF", "Background me LIA na ruke",
            battOk, "Kholo") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
            } catch (_: Exception) { act().toast("Settings me manually off karo") }
        }
        val notifOk = NotificationManagerCompat.from(ctx).areNotificationsEnabled()
        addRow("🔔", "Notifications", "Website taiyaar hone par khabar",
            notifOk, "Kholo") {
            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            i.putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
            startActivity(i)
        }
        addRow("📞", "Phone & Contacts", "Direct call ke liye (optional)",
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED,
            "Allow karo") {
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS), 51)
        }
        addRow("📍", "Location", "Asli mausam ke liye",
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED,
            "Allow karo") {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 52)
        }
        addRow("🎤", "Default Assistant", "LIA ko default voice assistant banao (optional)",
            false, "Kholo") {
            try {
                startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            } catch (_: Exception) { act().toast("Settings me manually karo") }
        }
    }

    private fun grantAll() {
        // Jo runtime me maange ja sakte hain — ek saath maango
        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ), 60
        )
        act().toast("Ab Overlay aur Accessibility ke liye neeche rows se 'Kholo' dabao 👇")
    }

    private fun addRow(icon: String, title: String, sub: String, ok: Boolean, btnText: String, onTap: () -> Unit) {
        val ctx = requireContext()
        val card = Ui.card(ctx)
        val r = Ui.row(ctx)
        val ic = Ui.tv(ctx, icon, 24)
        ic.setPadding(0, 0, Ui.dp(ctx, 12), 0)
        val mid = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tr = Ui.row(ctx)
        tr.addView(Ui.tv(ctx, title, 15, Ui.TEXT, true))
        val st = TextView(ctx)
        st.text = if (ok) " ✅" else " ❌"
        st.textSize = 15f
        tr.addView(st)
        mid.addView(tr)
        mid.addView(Ui.tv(ctx, sub, 12, Ui.TEXT2))
        val b = Ui.btn(ctx, btnText, !ok) { onTap() }
        r.addView(ic); r.addView(mid); r.addView(b)
        card.addView(r)
        list.addView(card)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        render()
        if (r.firstOrNull() != PackageManager.PERMISSION_GRANTED) act().toast("Permission nahi mili 😔")
    }
}
