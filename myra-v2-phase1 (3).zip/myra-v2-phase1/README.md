# MYRA v2 (Phase 1) - Android Studio project
Open this folder in Android Studio (Hedgehog or newer, JDK 17) -> Sync -> Run.
1. Settings -> paste OpenRouter key (https://openrouter.ai/workspaces/default/keys) -> Test -> Save.
2. Settings -> Permissions: grant everything (Accessibility, Notification access, Write settings, DND...).
3. Pick TTS model/voice (Load available TTS models), personality, language.
Code box: ask for code (or turn on </> Code mode). Each code block has Copy / File / TXT / PDF / Share / Fix.
Saved files go to Downloads/MYRA.
Not compiled or tested in the build environment: first Gradle sync may show small errors; paste them to Claude to fix.
