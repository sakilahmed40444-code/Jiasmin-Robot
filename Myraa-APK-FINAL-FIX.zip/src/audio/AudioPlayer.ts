export class AudioPlayer {
  private context: AudioContext | null = null;
  private nextStartTime = 0;
  private sources = new Set<AudioBufferSourceNode>();
  private analyser: AnalyserNode | null = null;
  private gain: GainNode | null = null;
  private onLevel?: (level: number) => void;
  private raf = 0;

  constructor(onLevel?: (level: number) => void) {
    this.onLevel = onLevel;
  }

  async init() {
    if (!this.context) {
      this.context = new AudioContext({ sampleRate: 24000 });
      this.gain = this.context.createGain();
      this.analyser = this.context.createAnalyser();
      this.analyser.fftSize = 512;
      this.gain.connect(this.analyser);
      this.analyser.connect(this.context.destination);
      this.nextStartTime = this.context.currentTime;
      this.watchLevel();
    }
    if (this.context.state === "suspended") await this.context.resume();
  }

  private watchLevel() {
    const loop = () => {
      if (!this.analyser) return;
      const data = new Uint8Array(this.analyser.fftSize);
      this.analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (const value of data) {
        const normalized = (value - 128) / 128;
        sum += normalized * normalized;
      }
      const rms = Math.sqrt(sum / data.length);
      this.onLevel?.(Math.min(1, rms * 4));
      this.raf = requestAnimationFrame(loop);
    };
    loop();
  }

  async playBase64Pcm24(base64: string) {
    await this.init();
    const bytes = this.base64ToBytes(base64);
    const sampleCount = Math.floor(bytes.length / 2);
    const buffer = this.context!.createBuffer(1, sampleCount, 24000);
    const channel = buffer.getChannelData(0);
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    for (let i = 0; i < sampleCount; i++) {
      channel[i] = view.getInt16(i * 2, true) / 32768;
    }

    const source = this.context!.createBufferSource();
    source.buffer = buffer;
    source.connect(this.gain!);

    const now = this.context!.currentTime;
    const start = Math.max(now + 0.015, this.nextStartTime);
    source.start(start);
    this.nextStartTime = start + buffer.duration;
    this.sources.add(source);
    source.onended = () => this.sources.delete(source);
  }

  stop() {
    for (const source of this.sources) {
      try { source.stop(); } catch {}
    }
    this.sources.clear();
    if (this.context) this.nextStartTime = this.context.currentTime;
    this.onLevel?.(0);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    this.stop();
    this.context?.close();
    this.context = null;
  }

  private base64ToBytes(value: string): Uint8Array {
    const binary = atob(value);
    const out = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
    return out;
  }
}