package com.lia.assistant.vision

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import com.lia.assistant.data.Prefs
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Screen Capture permission ON ho to screenshot lekar vision se dekho.
 * "Tumi ja dekhabo ta bujhbo, ja korte bolbo korbo."
 */
object ScreenVision {

    @Volatile private var grantCode: Int = -1
    @Volatile private var grantData: Intent? = null

    fun saveGrant(resultCode: Int, data: Intent?) {
        grantCode = resultCode
        grantData = data
    }

    fun hasGrant(prefs: Prefs): Boolean =
        prefs.screenCapGranted && grantCode != -1 && grantData != null

    /** Screenshot lo aur vision se Bangla me batao kya dikh raha hai. */
    fun captureAndDescribe(ctx: Context, prefs: Prefs, cb: (String) -> Unit) {
        Thread {
            cb(describeSync(ctx, prefs))
        }.start()
    }

    /** Blocking version — background thread se call karo. */
    fun describeSync(ctx: Context, prefs: Prefs): String {
        return try {
            val png = capturePng(ctx) ?: return ""
            describe(ctx, prefs, png)
        } catch (_: Exception) { "" }
    }

    private fun capturePng(ctx: Context): ByteArray? {
        val code = grantCode
        val data = grantData ?: return null
        return try {
            val mpManager = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = mpManager.getMediaProjection(code, data)
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getMetrics(metrics)
            val w = metrics.widthPixels
            val h = metrics.heightPixels
            // chhota karo — tez upload
            val sw = 540
            val sh = (h * (sw.toFloat() / w)).toInt()
            val reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
            val vd = projection.createVirtualDisplay(
                "priya-cap", sw, sh, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, null
            )
            val latch = CountDownLatch(1)
            var out: ByteArray? = null
            reader.setOnImageAvailableListener({ r ->
                try {
                    val img = r.acquireLatestImage()
                    if (img != null) {
                        val plane = img.planes[0]
                        val buf = plane.buffer
                        val pixelStride = plane.pixelStride
                        val rowStride = plane.rowStride
                        val rowPadding = rowStride - pixelStride * sw
                        var bmp = Bitmap.createBitmap(sw + rowPadding / pixelStride, sh, Bitmap.Config.ARGB_8888)
                        bmp.copyPixelsFromBuffer(buf)
                        bmp = Bitmap.createBitmap(bmp, 0, 0, sw, sh)
                        val bos = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                        out = bos.toByteArray()
                        img.close()
                    }
                } catch (_: Exception) { }
                latch.countDown()
            }, Handler(Looper.getMainLooper()))
            latch.await(6, TimeUnit.SECONDS)
            try { vd.release() } catch (_: Exception) { }
            try { reader.close() } catch (_: Exception) { }
            try { projection.stop() } catch (_: Exception) { }
            out
        } catch (_: Exception) { null }
    }

    private fun describe(ctx: Context, prefs: Prefs, png: ByteArray): String {
        val b64 = android.util.Base64.encodeToString(png, android.util.Base64.NO_WRAP)
        val prompt = "Tumi phone er screen dekhcho. Bangla-e (2-3 line) bolo screen-e ki ki dekhte paccho — apps, text, buttons."
        // 1) Gemini vision
        if (prefs.apiKey.isNotBlank()) {
            try {
                val body = org.json.JSONObject().apply {
                    put("contents", org.json.JSONArray().put(org.json.JSONObject().put("parts",
                        org.json.JSONArray()
                            .put(org.json.JSONObject().put("text", prompt))
                            .put(org.json.JSONObject().put("inline_data",
                                org.json.JSONObject().put("mime_type", "image/jpeg")
                                    .put("data", b64))))))
                }.toString()
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${prefs.apiKey}")
                    .openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.setRequestProperty("Content-Type", "application/json")
                c.connectTimeout = 20000; c.readTimeout = 40000
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray()) }
                if (c.responseCode == 200) {
                    val r = c.inputStream.bufferedReader().readText()
                    val t = org.json.JSONObject(r).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                    if (t.isNotBlank()) return t.trim()
                }
            } catch (_: Exception) { }
        }
        // 2) OpenRouter vision
        if (prefs.openRouterKey.isNotBlank()) {
            try {
                val body = org.json.JSONObject().apply {
                    put("model", prefs.openRouterModel)
                    put("messages", org.json.JSONArray().put(org.json.JSONObject().apply {
                        put("role", "user")
                        put("content", org.json.JSONArray()
                            .put(org.json.JSONObject().put("type", "text").put("text", prompt))
                            .put(org.json.JSONObject().put("type", "image_url").put("image_url",
                                org.json.JSONObject().put("url", "data:image/jpeg;base64,$b64"))))
                    }))
                }.toString()
                val c = URL("https://openrouter.ai/api/v1/chat/completions")
                    .openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer ${prefs.openRouterKey}")
                c.connectTimeout = 20000; c.readTimeout = 40000
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray()) }
                if (c.responseCode == 200) {
                    val r = c.inputStream.bufferedReader().readText()
                    val t = org.json.JSONObject(r).getJSONArray("choices").getJSONObject(0)
                        .getJSONObject("message").getString("content")
                    if (t.isNotBlank()) return t.trim()
                }
            } catch (_: Exception) { }
        }
        return ""
    }
}
