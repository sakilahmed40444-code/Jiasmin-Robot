package com.lia.assistant.brain

/** Voice/text se nikle hue commands. */
sealed class Action {
    data class OpenApp(val appName: String) : Action()
    data class Call(val target: String) : Action()
    data class Message(val app: String, val to: String, val msg: String) : Action()
    data class Forge(val subject: String) : Action()
    data class Tap(val target: String) : Action()
    data class Scroll(val down: Boolean) : Action()
    data class Type(val text: String) : Action()
    object ReadScreen : Action()
    object GoBack : Action()
    object GoHome : Action()
    object Time : Action()
    object Date : Action()
    object Joke : Action()
    object Help : Action()
    object Greet : Action()
    object MyName : Action()
    object Thanks : Action()
    object Bye : Action()
    data class Remember(val text: String) : Action()
}

object CommandParser {

    fun parse(raw: String): Action? {
        val t = raw.trim()
        val s = t.lowercase()

        // ---- Website Forge ----
        if (isForgeIntent(s)) return Action.Forge(forgeSubject(t))

        // ---- Call: "mummy ko call karo", "call karo 98765..." ----
        if (s.contains("call") || s.contains("phone lagao") || s.contains("dial karo")) {
            val m1 = Regex("(?:call|phone|dial)\\s+(?:karo|kar do|lagao)?\\s*([a-zA-Z\\u0900-\\u097F ]*?)\\s*(\\+?[\\d][\\d\\s\\-()]{4,})?").find(s)
            val m2 = Regex("([a-zA-Z\\u0900-\\u097F ]+?)\\s*ko\\s+(?:call|phone)\\s*karo").find(s)
            val target = (m1?.groupValues?.getOrNull(2)?.takeIf { it.isNotBlank() }
                ?: m1?.groupValues?.getOrNull(1)
                ?: m2?.groupValues?.getOrNull(1) ?: "").trim()
            return Action.Call(target)
        }

        // ---- Message: "rahul ko whatsapp karo hello" ----
        if (s.contains("whatsapp") || (s.contains("sms") && s.contains("karo")) || s.contains("message karo") || s.contains("msg karo")) {
            val app = if (s.contains("whatsapp")) "whatsapp" else "sms"
            var to = ""
            var msg = ""
            val koM = Regex("([a-zA-Z\\u0900-\\u097F]+)\\s*ko\\s*(whatsapp|sms|message)").find(s)
            if (koM != null) {
                to = koM.groupValues[1]
                msg = s.substring(koM.range.last + 1).replace(Regex("^(karo|kar do|bhejo)\\s*"), "").trim()
            } else {
                msg = s.replace(Regex(".*?(whatsapp|sms|message|msg)\\s*(karo|kar do|bhejo)?\\s*"), "").trim()
            }
            return Action.Message(app, to, msg)
        }

        // ---- Screen control (accessibility) ----
        if (s.contains("screen padho") || s.contains("screen dekho") || s.contains("kya dikh raha") || s.contains("screen dikhao"))
            return Action.ReadScreen
        val tapM = Regex("(.+?)\\s*(par|pe)\\s*(click|tap|dabao|daba do)").find(s)
            ?: Regex("(?:tap|click)\\s+(?:karo\\s+)?(.+)").find(s)
        if (tapM != null) {
            val target = (tapM.groupValues.getOrNull(1) ?: "").trim()
            if (target.length > 1) return Action.Tap(target)
        }
        if (s.contains("upar scroll") || s.contains("scroll up") || s.contains("upar karo")) return Action.Scroll(false)
        if (s.contains("neeche scroll") || s.contains("scroll down") || s.contains("neeche karo")) return Action.Scroll(true)
        val typeM = Regex("(?:type karo|likho|type)\\s+(.+)").find(s)
        if (typeM != null) return Action.Type(typeM.groupValues[1].trim())
        if (s.contains("wapas") || s.contains("peeche jao") || s == "back") return Action.GoBack
        if (s.contains("home jao") || s == "home") return Action.GoHome

        // ---- Open app: "youtube kholo", "open chrome", "facebook open", "amar mobile facebook app kholo" ----
        val openKw = listOf("khol do", "open karo", "launch karo", "start karo", "kholo", "khol", "open", "launch", "start")
        var appQuery: String? = null
        for (kw in openKw) {
            if (s.startsWith("$kw ")) { appQuery = s.removePrefix("$kw ").trim(); break }
            if (s.endsWith(" $kw")) { appQuery = s.removeSuffix(" $kw").trim(); break }
        }
        if (appQuery != null) {
            val clean = cleanAppQuery(appQuery)
            if (clean.length > 1 && !clean.contains("website")) return Action.OpenApp(clean)
        }

        // ---- Yaad rakho: "yaad rakho mera birthday 5 jan hai" ----
        val remM = Regex("(?:yaad rakho|yaad rakhna|remember)(?: that)?\\s+(.+)").find(s)
        if (remM != null) {
            val what = remM.groupValues[1].trim()
            if (what.length > 2) return Action.Remember(what)
        }

        // ---- Small talk ----
        if (t.matches(Regex("(?i)^(namaste|namaskar|salaam|assalam.*|hello|hi+|hey)\\b.*"))) return Action.Greet
        if (s.contains("tumhara naam") || s.contains("tera naam") || s.contains("your name") || s.contains("who are you") || s.contains("tum kaun")) return Action.MyName
        if (s.contains("time") || s.contains("samay") || s.contains("baj rahe") || s.contains("kitne baje")) return Action.Time
        if (s.contains("date") || s.contains("tarikh")) return Action.Date
        if (s.contains("joke") || s.contains("hasao") || s.contains("majedar")) return Action.Joke
        if (s.contains("help") || s.contains("madad") || s.contains("kya kar sakti") || s.contains("kya kar sakte")) return Action.Help
        if (s.contains("thank") || s.contains("shukriya") || s.contains("dhanyavad")) return Action.Thanks
        if (s.contains("bye") || s.contains("alvida") || s.contains("good night") || s.contains("shubh ratri")) return Action.Bye

        return null // → brain chat
    }

    fun isForgeIntent(s: String): Boolean {
        val hasSite = Regex("website|web ?page|landing ?page|site|वेबसाइट").containsMatchIn(s)
        val hasVerb = Regex("bana|banao|banado|banade|build|create|make|design|tayar").containsMatchIn(s)
        return hasSite && hasVerb
    }

    fun forgeSubject(t: String): String {
        var s = t.replace(Regex("^(lia[,.]?\\s*|please\\s*)", RegexOption.IGNORE_CASE), "").trim()
        s = s.replace(Regex("\\s*(bana|banao|banado|banade|build karo|build|create karo|create|make|design karo|design|taiyaar karo|please)\\s*$", RegexOption.IGNORE_CASE), "").trim()
        val m = Regex("(?:ek|a|an)\\s+(.+?)\\s+(?:ki|ka|ke)\\s+(?:animated\\s+)?(?:website|web ?page|site)", RegexOption.IGNORE_CASE).find(s)
            ?: Regex("(?:mera|meri|mere|my)\\s+(.+?)\\s+(?:website|web ?page|site)", RegexOption.IGNORE_CASE).find(s)
            ?: Regex("(.+?)\\s+(?:ki|ka|ke)\\s+(?:animated\\s+)?(?:website|web ?page|site)", RegexOption.IGNORE_CASE).find(s)
            ?: Regex("(?:website|web ?page|site)\\s+(?:for|of|about|on|par)\\s+(.+)", RegexOption.IGNORE_CASE).find(s)
        var subj = (m?.groupValues?.getOrNull(1) ?: s).replace(Regex("^(ek|a|an)\\s+", RegexOption.IGNORE_CASE), "").trim()
        subj = subj.replace(Regex("\\b(animated|website|web ?page|site)\\b", RegexOption.IGNORE_CASE), "").replace(Regex("\\s+"), " ").trim()
        return subj.ifEmpty { "tumhara business" }
    }

    /** App naam se filler words hatao: "amar mobile facebook app" → "facebook" */
    private val APP_FILLERS = setOf(
        "amar", "amr", "mera", "mere", "meri", "mobile", "phone", "smartphone",
        "app", "apps", "application", "ko", "karo", "kro", "please", "pls",
        "ek", "zara", "wala", "wali", "wale", "the", "koi", "bhi", "mujhe", "muje", "mein", "me"
    )

    fun cleanAppQuery(q: String): String {
        return q.split(" ").filter { it.length > 1 && it !in APP_FILLERS }.joinToString(" ").trim()
    }
}
