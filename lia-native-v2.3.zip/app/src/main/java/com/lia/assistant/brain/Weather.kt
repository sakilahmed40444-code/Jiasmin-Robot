package com.lia.assistant.brain

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Open-Meteo — bina key ke asli mausam. */
object Weather {
    @Throws(Exception::class)
    fun current(lat: Double, lon: Double): String {
        val url = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code,wind_speed_10m,relative_humidity_2m"
        )
        val c = url.openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 25000
            val txt = c.inputStream.bufferedReader().readText()
            val cur = JSONObject(txt).getJSONObject("current")
            val t = cur.getDouble("temperature_2m")
            val code = cur.getInt("weather_code")
            val wind = cur.optDouble("wind_speed_10m", 0.0)
            return "%.1f°C, %s. Hawa %.0f km/h.".format(t, describe(code), wind)
        } finally {
            c.disconnect()
        }
    }

    private fun describe(code: Int): String = when (code) {
        0 -> "bilkul saaf aasmaan"
        1 -> "halke baadal"
        2 -> "aanshik baadal"
        3 -> "ghane baadal"
        45, 48 -> "kohra"
        51, 53, 55 -> "halki boonda-baandi"
        61, 63, 65 -> "baarish"
        71, 73, 75, 77 -> "barfbaari"
        80, 81, 82 -> "tez baarish"
        95 -> "aandhi-toofaan"
        96, 99 -> "ole ke saath toofaan"
        else -> "mili-juli sthiti"
    }
}
