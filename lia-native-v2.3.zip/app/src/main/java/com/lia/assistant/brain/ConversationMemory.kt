package com.lia.assistant.brain

/** Last 12 turns, memory me hi — spec step 03. */
class ConversationMemory {
    private val turns = ArrayDeque<Pair<Boolean, String>>() // true=user

    @Synchronized
    fun addUser(t: String) = add(true, t)

    @Synchronized
    fun addAssistant(t: String) = add(false, t)

    private fun add(user: Boolean, t: String) {
        turns.addLast(user to t)
        while (turns.size > 12) turns.removeFirst()
    }

    @Synchronized
    fun recap(): String {
        val sb = StringBuilder()
        for ((u, t) in turns) {
            val line = (if (u) "User: " else "You: ") + t.take(200) + "\n"
            if (sb.length + line.length > 1600) break
            sb.append(line)
        }
        return sb.toString().trim()
    }

    @Synchronized
    fun history(): List<Pair<Boolean, String>> = turns.toList()

    @Synchronized
    fun clear() = turns.clear()
}
