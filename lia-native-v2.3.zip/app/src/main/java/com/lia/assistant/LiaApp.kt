package com.lia.assistant

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.util.Date

class LiaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        // Crash ki wajah file me save karo — taaki user use bhej sake (koi PC/adb nahi hai)
        val defHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                var cause = e.cause
                val chain = StringBuilder()
                while (cause != null) {
                    chain.append("\nCaused by: ").append(cause.toString())
                    cause = cause.cause
                    if (chain.length > 2000) break
                }
                File(filesDir, "crash.log").writeText(
                    "Time: ${Date()}\nThread: ${t.name}\n\n${sw}\n$chain".take(12000)
                )
            } catch (_: Exception) { }
            defHandler?.uncaughtException(t, e)
        }
    }

    companion object {
        lateinit var instance: LiaApp
            private set
    }
}
