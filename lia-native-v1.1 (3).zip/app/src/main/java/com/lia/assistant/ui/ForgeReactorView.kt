package com.lia.assistant.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Website Forge ka 3D reactor — asli stream se chalta hai. */
class ForgeReactorView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    var stage: Int = 0
        set(v) { field = v.coerceIn(0, 6); invalidate() }
    var shock: Float = 0f
    var failed: Boolean = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val handler = Handler(Looper.getMainLooper())
    private val glyphs = charArrayOf('{', '}', '<', '>', '/', '=', ';', '(', ')', '0', '1', '#', '$', '*', '%')
    private data class P(var a: Double, var r: Double, var sp: Double, var g: Char, var sz: Float)
    private val parts = mutableListOf<P>()
    private var running = false

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            t += 0.016f
            for (p in parts) {
                p.a += 0.02 * p.sp * (1 + stage * 0.25)
                p.r -= 0.008 * (1 + stage * 0.3)
                if (p.r < 0.7) { p.r = 2.4; p.a = Math.random() * 7 }
            }
            if (shock > 0) shock = (shock - 0.03f).coerceAtLeast(0f)
            invalidate()
            handler.postDelayed(this, 16)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (parts.isEmpty()) {
            repeat(60) {
                parts.add(P(Math.random() * 7, 1.6 + Math.random() * 1.6,
                    0.5 + Math.random(), glyphs[it % glyphs.size], 26f + Math.random().toFloat() * 22f))
            }
        }
        running = true
        handler.post(loop)
    }

    override fun onDetachedFromWindow() {
        running = false
        handler.removeCallbacks(loop)
        super.onDetachedFromWindow()
    }

    fun burst() { shock = 1f }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w == 0f) return
        val cx = w / 2f; val cy = h * 0.40f
        val R = min(w, h) * 0.15f * (1 + shock * 0.5f)
        val accent = Color.parseColor("#FFB547")
        val lagoon = Color.parseColor("#3FE0D0")

        // bg stars
        paint.color = Color.argb(90, 180, 170, 255)
        for (i in 0 until 36) {
            c.drawCircle(((i * 97.3f) % w), ((i * 57.7f) % h), 2f, paint)
        }

        // glyph particles
        paint.textSize = 30f
        for (p in parts) {
            val gx = cx + cos(p.a).toFloat() * R * p.r.toFloat() * 2.4f
            val gy = cy + sin(p.a).toFloat() * R * p.r.toFloat() * 1.4f
            paint.color = lagoon
            paint.alpha = (60 + 100 * (1 - p.r / 2.6)).toInt().coerceIn(0, 200)
            c.drawText(p.g.toString(), gx, gy, paint)
        }
        paint.alpha = 255

        // data beams
        for (i in 0 until 5) {
            val ba = t * 3 + i * 1.256
            val bx = cx + cos(ba).toFloat() * R * 4f
            val by = cy + sin(ba).toFloat() * R * 2.6f
            paint.color = accent; paint.alpha = 120; paint.strokeWidth = 4f
            c.drawLine(bx, by, cx, cy, paint)
        }
        paint.alpha = 255

        // reactor core
        val heat = 0.35f + stage * 0.1f
        paint.shader = RadialGradient(cx, cy, R * 0.1f, cx, cy, R * 1.9f,
            intArrayOf(Color.WHITE, Color.argb((heat * 255).toInt(), 255, 181, 71),
                Color.argb(128, 255, 111, 174), Color.argb(0, 20, 10, 40)),
            floatArrayOf(0f, 0.3f, 0.7f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R * 1.9f, paint)
        paint.shader = null
        paint.color = Color.argb(140, 255, 255, 255)
        c.drawCircle(cx, cy, R * (0.5f + 0.06f * sin(t * 6f)), paint)

        // gyro rings
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 5f
        paint.color = accent; paint.alpha = 140
        for (i in 0 until 3) {
            c.save(); c.translate(cx, cy)
            c.rotate((t * 40f * (1 + stage * 0.3f) + i * 120f) % 360f)
            c.scale(1f, 0.42f)
            c.drawCircle(0f, 0f, R * (2.2f + i * 0.35f), paint)
            c.restore()
        }
        paint.style = Paint.Style.FILL; paint.alpha = 255

        // stage ring — 6 nodes
        val sr = R * 3.1f
        for (i in 0 until 6) {
            val a = -Math.PI / 2 + i * Math.PI / 3
            val nx = cx + cos(a).toFloat() * sr
            val ny = cy + sin(a).toFloat() * sr * 0.62f
            val on = i < stage
            paint.color = if (on) accent else Color.argb(46, 255, 255, 255)
            c.drawCircle(nx, ny, if (on) 12f else 9f, paint)
            if (on) {
                paint.color = Color.argb(64, 255, 181, 71)
                c.drawCircle(nx, ny, 22f, paint)
            }
        }

        // glass slabs — ek per stage
        val sw = w * 0.62f; val sh = h * 0.05f; val sy0 = h * 0.68f
        for (i in 0 until min(6, stage)) {
            val sy = sy0 - i * (sh + 10)
            paint.color = Color.argb(217, 40, 34, 90)
            c.drawRoundRect((w - sw) / 2, sy, (w + sw) / 2, sy + sh, 14f, 14f, paint)
            paint.color = lagoon; paint.alpha = 130
            for (b in 0 until 3) c.drawRect((w - sw) / 2 + 24 + b * 80, sy + sh / 2 - 5, (w - sw) / 2 + 24 + b * 80 + 58, sy + sh / 2 + 5, paint)
            paint.alpha = 255
        }

        // shockwave
        if (shock > 0) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 7f
            paint.color = Color.WHITE; paint.alpha = (shock * 200).toInt()
            c.drawCircle(cx, cy, R * (2 + (1 - shock) * 6), paint)
            paint.style = Paint.Style.FILL; paint.alpha = 255
        }
        if (failed) {
            paint.color = Color.argb(90, 255, 60, 60)
            c.drawRect(0f, 0f, w, h, paint)
        }
    }
}
