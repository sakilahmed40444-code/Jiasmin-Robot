import React, { useState } from "react";
import { Settings, SlidersHorizontal } from "lucide-react";
import { VoiceOrb } from "./components/VoiceOrb";
import { VoiceModelSelector } from "./components/VoiceModelSelector";
import { SettingsPanel } from "./components/SettingsPanel";
import { useVoiceSession } from "./hooks/useVoiceSession";
import { VOICE_MODELS } from "./config";

function labelForState(state: string) {
  switch (state) {
    case "connecting": return "Connecting";
    case "listening": return "Listening";
    case "speaking": return "Speaking";
    case "error": return "Error";
    default: return "Ready";
  }
}

export default function App() {
  const voice = useVoiceSession();
  const [modelOpen, setModelOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const selected = VOICE_MODELS.find((m) => m.id === voice.model);

  return (
    <main className="app-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />

      <header className="topbar">
        <div>
          <div className="brand">MYRAA</div>
          <div className="brand-subtitle">Voice AI Assistant</div>
        </div>
        <button className="icon-button" onClick={() => setSettingsOpen(true)} aria-label="Settings">
          <Settings size={20} />
        </button>
      </header>

      <section className="hero">
        <div className="status-pill">
          <span className={`status-dot ${voice.state}`} />
          {labelForState(voice.state)}
        </div>

        <div className="orb-wrap">
          <VoiceOrb
            state={voice.state}
            level={Math.max(voice.inputLevel, voice.outputLevel)}
            onClick={voice.toggle}
          />
        </div>

        <div className="wave-row" aria-hidden="true">
          {Array.from({ length: 28 }).map((_, i) => {
            const level = Math.max(voice.inputLevel, voice.outputLevel);
            const h = 5 + Math.min(38, level * (10 + (i % 5) * 5));
            return <span key={i} style={{ height: `${h}px` }} />;
          })}
        </div>

        <h1>{voice.state === "speaking" ? "Myraa is speaking" : "Talk to Myraa"}</h1>
        <p className="hint">
          {voice.error || (voice.state === "listening" ? "I'm listening..." : "Tap the orb to start")}
        </p>

        {(voice.inputTranscript || voice.outputTranscript) && (
          <div className="debug-transcript">
            {voice.inputTranscript && <div><b>You:</b> {voice.inputTranscript}</div>}
            {voice.outputTranscript && <div><b>Myraa:</b> {voice.outputTranscript}</div>}
          </div>
        )}
      </section>

      <footer className="bottom-controls">
        <button className="control-card" onClick={() => setModelOpen(true)}>
          <SlidersHorizontal size={18} />
          <span>
            <small>Voice model</small>
            <strong>{selected?.label ?? "Gemini 3.8 Live"}</strong>
          </span>
        </button>
        <button className="control-card" onClick={() => setSettingsOpen(true)}>
          <Settings size={18} />
          <span>
            <small>Settings</small>
            <strong>API & access</strong>
          </span>
        </button>
      </footer>

      <VoiceModelSelector
        value={voice.model}
        onChange={voice.changeModel}
        open={modelOpen}
        onClose={() => setModelOpen(false)}
      />

      <SettingsPanel
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
      />
    </main>
  );
}