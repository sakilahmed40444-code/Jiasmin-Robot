package com.lia.assistant.ui

import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.fragment.app.Fragment
import com.lia.assistant.brain.LiaResponder

class ChatFragment : Fragment() {
    private fun act() = activity as MainActivity
    private lateinit var logBox: LinearLayout
    private lateinit var logScroll: ScrollView
    private lateinit var input: EditText
    private var greeted = false

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.col(Ui.BG))
            setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 16), Ui.dp(ctx, 16), Ui.dp(ctx, 90))
        }
        col.addView(Ui.title(ctx, "Chat"))
        col.addView(Ui.sub(ctx, "Type karo — wahi personality, wahi Lia."))

        logScroll = ScrollView(ctx)
        logBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        logScroll.addView(logBox)
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        logScroll.layoutParams = lp
        col.addView(logScroll)

        val bar = Ui.row(ctx)
        input = Ui.input(ctx, "Lia se kuch kaho…")
        val ip = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        input.layoutParams = ip
        val send = Ui.btn(ctx, "➤") { send() }
        bar.addView(input); bar.addView(send)
        col.addView(bar)

        if (!greeted) {
            greeted = true
            addMsg("a", "Namaste! Main LIA hoon 🔥 — type karo ya Voice tab me bolo. \"Ek cafe ki website banao\" bhi try karo!")
        }
        input.setOnEditorActionListener { _, _, _ -> send(); true }
        return col
    }

    fun receiveText(t: String) { input.setText(t); send() }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        addMsg("u", t)
        val typing = addMsg("a", "…")
        Thread {
            act().responder.respond(t, object : LiaResponder.Cb {
                override fun onReply(reply: String, lang: String) {
                    activity?.runOnUiThread {
                        logBox.removeView(typing)
                        addMsg("a", reply)
                    }
                }
            })
        }.start()
    }

    private fun addMsg(who: String, text: String): View {
        val ctx = requireContext()
        val t = Ui.tv(ctx, text, 15, if (who == "u") Ui.TEXT else Ui.LAGOON)
        t.setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 10), Ui.dp(ctx, 14), Ui.dp(ctx, 10))
        t.setBackgroundColor(Ui.col(if (who == "u") Ui.RAISED else Ui.SURFACE))
        val p = LinearLayout.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.85).toInt(),
            LinearLayout.LayoutParams.WRAP_CONTENT)
        p.bottomMargin = Ui.dp(ctx, 8)
        p.gravity = if (who == "u") Gravity.END else Gravity.START
        t.layoutParams = p
        logBox.addView(t)
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
        return t
    }
}
