package com.myra.assistant.ui

import android.app.AlertDialog
import android.content.Context
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.myra.assistant.data.Prefs
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream

/** My Memory: Notes pad + OLD History. Save, edit, delete, PDF export. */
class MemoryActivity : AppCompatActivity() {

    private lateinit var list: LinearLayout
    private var tab = "notes"  // notes | history

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF0D0D0D.toInt()); setPadding(dp(14), dp(40), dp(14), dp(10)) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(tv("💾 My Memory", 22f, 0xFFFF1744.toInt(), true))
        root.addView(top)

        // tabs
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val bNotes = tabBtn("📝 Notes", "notes")
        val bHist = tabBtn("🕰️ OLD History", "history")
        tabs.addView(bNotes); tabs.addView(bHist)
        root.addView(tabs)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(list) }
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        // action bar
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        bar.addView(actionBtn("➕ Add") { addDialog() })
        bar.addView(actionBtn("📄 PDF") { exportPdf() })
        bar.addView(actionBtn("🗑️ Delete All") { deleteAll() })
        root.addView(bar)

        setContentView(root)
        draw()
    }

    private fun tabBtn(label: String, id: String): Button {
        return Button(this).apply {
            text = label
            setOnClickListener { tab = id; draw() }
        }
    }

    private fun actionBtn(label: String, act: () -> Unit): Button {
        return Button(this).apply { text = label; setOnClickListener { act() } }
    }

    private fun draw() {
        list.removeAllViews()
        val items = getItems()
        if (items.isEmpty()) list.addView(tv("খালি — কিছু save করো", 14f, 0xFF888888.toInt()).apply { gravity = Gravity.CENTER })
        items.forEachIndexed { i, txt ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
            row.addView(tv(txt.take(100), 14f).apply { setPadding(0, 0, dp(8), 0) }, LinearLayout.LayoutParams(0, -2, 1f))
            val eb = Button(this).apply { text = "✏️"; setOnClickListener { editDialog(i) } }
            val db = Button(this).apply { text = "🗑️"; setOnClickListener { deleteOne(i) } }
            row.addView(eb); row.addView(db)
            list.addView(row)
        }
    }

    private fun getItems(): List<String> {
        return if (tab == "notes") Prefs.notes() else Prefs.history()
    }

    private fun addDialog() {
        val e = EditText(this).apply { hint = "লিখো..."; setTextColor(0xFFFFFFFF.toInt()) }
        AlertDialog.Builder(this).setTitle(if (tab == "notes") "New Note" else "Add History")
            .setView(e.apply { setPadding(dp(20), dp(10), dp(20), dp(10)) })
            .setPositiveButton("Save") { _, _ ->
                val t = e.text.toString().trim()
                if (t.isNotEmpty()) {
                    if (tab == "notes") Prefs.addNote(t) else Prefs.addHistory(t)
                    draw(); Toast.makeText(this, "Saved ✅", Toast.LENGTH_SHORT).show()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun editDialog(i: Int) {
        val items = getItems().toMutableList()
        val e = EditText(this).apply { setText(items[i]); setTextColor(0xFFFFFFFF.toInt()) }
        AlertDialog.Builder(this).setTitle("Edit")
            .setView(e.apply { setPadding(dp(20), dp(10), dp(20), dp(10)) })
            .setPositiveButton("Save") { _, _ ->
                val t = e.text.toString().trim()
                if (tab == "notes") Prefs.setNotes(items.apply { set(i, t) }) else Prefs.setHistory(items.apply { set(i, t) })
                draw()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun deleteOne(i: Int) {
        val items = getItems().toMutableList().apply { removeAt(i) }
        if (tab == "notes") Prefs.setNotes(items) else Prefs.setHistory(items)
        draw()
    }

    private fun deleteAll() {
        AlertDialog.Builder(this).setTitle("সব মুছে ফেলবো?")
            .setPositiveButton("হ্যাঁ") { _, _ ->
                if (tab == "notes") Prefs.setNotes(emptyList()) else Prefs.setHistory(emptyList())
                draw()
            }.setNegativeButton("না", null).show()
    }

    private fun exportPdf() {
        try {
            val items = getItems()
            if (items.isEmpty()) { Toast.makeText(this, "খালি", Toast.LENGTH_SHORT).show(); return }
            val doc = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            var page = doc.startPage(pageInfo)
            var y = 40f
            val paint = android.graphics.Paint().apply { textSize = 12f; color = 0xFF000000.toInt() }
            page.canvas.drawText(if (tab == "notes") "MYRA Notes" else "MYRA History", 40f, y, paint.apply { textSize = 18f; isFakeBoldText = true })
            y += 30; paint.textSize = 12f; paint.isFakeBoldText = false
            for (txt in items) {
                for (line in txt.chunked(80)) {
                    if (y > 800) { doc.finishPage(page); page = doc.startPage(pageInfo); y = 40f }
                    page.canvas.drawText(line, 40f, y, paint); y += 18
                }
                y += 10
            }
            doc.finishPage(page)
            val file = File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "myra_${tab}_${System.currentTimeMillis()}.pdf")
            doc.writeTo(FileOutputStream(file)); doc.close()
            Toast.makeText(this, "PDF saved: ${file.name} ✅", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "PDF fail: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun tv(t: String, s: Float, c: Int = 0xFFFFFFFF.toInt(), b: Boolean = false): TextView {
        return TextView(this).apply { text = t; textSize = s; setTextColor(c); if (b) typeface = Typeface.DEFAULT_BOLD }
    }
    private fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
