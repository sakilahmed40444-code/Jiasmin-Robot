import { useCallback, useEffect, useRef, useState } from "react";
import { AudioPlayer } from "../audio/AudioPlayer";
import { AudioStreamer } from "../audio/AudioStreamer";
import { LiveSession } from "../live/LiveSession";
import { getApiKey, getSelectedModel, VoiceModelId } from "../config";

export type VoiceState = "disconnected" | "connecting" | "listening" | "speaking" | "error";

export function useVoiceSession() {
  const [state, setState] = useState<VoiceState>("disconnected");
  const [inputLevel, setInputLevel] = useState(0);
  const [outputLevel, setOutputLevel] = useState(0);
  const [error, setError] = useState("");
  const [model, setModel] = useState<VoiceModelId>(getSelectedModel());
  const [inputTranscript, setInputTranscript] = useState("");
  const [outputTranscript, setOutputTranscript] = useState("");

  const liveRef = useRef<LiveSession | null>(null);
  const streamerRef = useRef<AudioStreamer | null>(null);
  const playerRef = useRef<AudioPlayer | null>(null);

  const stop = useCallback(() => {
    streamerRef.current?.stop();
    streamerRef.current = null;
    liveRef.current?.close();
    liveRef.current = null;
    playerRef.current?.stop();
    setState("disconnected");
    setInputLevel(0);
    setOutputLevel(0);
  }, []);

  const start = useCallback(async () => {
    if (state === "connecting" || state === "listening" || state === "speaking") return;

    const apiKey = getApiKey();
    if (!apiKey) {
      setError("Gemini API key দিন Settings থেকে");
      setState("error");
      return;
    }

    setError("");
    setState("connecting");

    try {
      const player = new AudioPlayer(setOutputLevel);
      await player.init();
      playerRef.current = player;

      const live = new LiveSession(apiKey, model, {
        onOpen: () => setState("listening"),
        onAudio: async (audio) => {
          setState("speaking");
          await player.playBase64Pcm24(audio);
        },
        onInterrupted: () => {
          player.stop();
          setState("listening");
        },
        onTurnComplete: () => {
          if (streamerRef.current) setState("listening");
        },
        onInputTranscript: setInputTranscript,
        onOutputTranscript: setOutputTranscript,
        onError: (message) => {
          setError(message);
          setState("error");
        },
        onClose: () => {
          if (state !== "error") setState("disconnected");
        }
      });

      liveRef.current = live;
      await live.connect();

      const streamer = new AudioStreamer(
        (pcm) => live.sendPcm16k(pcm),
        setInputLevel
      );
      streamerRef.current = streamer;
      await streamer.start();
      setState("listening");
    } catch (e) {
      stop();
      setError(e instanceof Error ? e.message : "Could not start Myraa");
      setState("error");
    }
  }, [model, state, stop]);

  const toggle = useCallback(() => {
    if (state === "listening" || state === "speaking" || state === "connecting") {
      stop();
    } else {
      void start();
    }
  }, [start, state, stop]);

  const changeModel = useCallback((next: VoiceModelId) => {
    setModel(next);
    if (liveRef.current) {
      stop();
    }
  }, [stop]);

  useEffect(() => {
    return () => {
      streamerRef.current?.stop();
      liveRef.current?.close();
      playerRef.current?.destroy();
    };
  }, []);

  return {
    state,
    inputLevel,
    outputLevel,
    error,
    model,
    inputTranscript,
    outputTranscript,
    start,
    stop,
    toggle,
    changeModel
  };
}