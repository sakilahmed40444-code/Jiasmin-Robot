package com.myra.assistant.ai

import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.myra.assistant.data.Prefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.sqrt

enum class State { IDLE, LISTENING, RECORDING, THINKING, SPEAKING }

class AudioEngine {
    @Volatile private var track: AudioTrack? = null
    @Volatile private var stopped = false
    @Volatile private var framesWritten = 0L
    private var curRate = 0
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    @Volatile var onAmp: ((Float) -> Unit)? = null

    fun aecAvailable() = AcousticEchoCanceler.isAvailable()

    fun startMic(useAec: Boolean): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val src = if (useAec) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.VOICE_RECOGNITION
        val r = try { AudioRecord(src, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 640 * 8)) }
        catch (e: Exception) { return null }
        if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return null }
        if (useAec) {
            if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(r.audioSessionId)?.also { it.enabled = true }
            if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(r.audioSessionId)?.also { it.enabled = true }
        }
        r.startRecording(); return r
    }
    fun stopMic(r: AudioRecord?) {
        try { r?.stop() } catch (_: Exception) {}
        try { r?.release() } catch (_: Exception) {}
        aec?.release(); ns?.release(); aec = null; ns = null
    }

    fun begin() { stopped = false; framesWritten = 0 }

    private fun ensureTrack(rate: Int): AudioTrack {
        track?.let { if (curRate == rate) return it; it.release() }
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, rate)).setTransferMode(AudioTrack.MODE_STREAM).build()
        t.play(); track = t; curRate = rate; return t
    }

    /** Blocking write of raw PCM16 mono. Applies Prefs.speechRate (resample) + Prefs.pitch (playback rate). */
    fun write(pcm: ByteArray) {
        try {
            var data = pcm
            val rate = Prefs.speechRate.coerceIn(0.5f, 2.0f)
            if (rate != 1.0f) data = resamplePcm(pcm, rate)
            val t = ensureTrack(Prefs.ttsRate)
            val pitch = Prefs.pitch.coerceIn(0.5f, 2.0f)
            try { t.playbackRate = (Prefs.ttsRate * pitch).toInt().coerceIn(Prefs.ttsRate / 2, Prefs.ttsRate * 2) } catch (_: Exception) {}
            var off = 0
            while (off < pcm.size && !stopped) {
                val n = t.write(pcm, off, minOf(4096, pcm.size - off))
                if (n <= 0) break
                off += n; framesWritten += n / 2
                var s = 0.0; var i = 0
                while (i + 1 < n && i < 4096) { val v = ((pcm[off - n + i + 1].toInt() shl 8) or (pcm[off - n + i].toInt() and 0xFF)).toShort().toDouble(); s += v * v; i += 2 }
                onAmp?.invoke((sqrt(s / maxOf(1, n / 2)) / 9000.0).toFloat().coerceIn(0f, 1f))
            }
        } catch (_: IllegalStateException) { }
    }

    /** Simple linear-interpolation resample for speech rate. rate>1 = faster. */
    private fun resamplePcm(pcm: ByteArray, rate: Float): ByteArray {
        val n = pcm.size / 2
        if (n < 2) return pcm
        val outN = (n / rate).toInt().coerceAtLeast(1)
        val out = ByteArray(outN * 2)
        for (i in 0 until outN) {
            val src = i * rate
            val i0 = src.toInt().coerceIn(0, n - 2)
            val frac = src - i0
            val s0 = (pcm[i0 * 2].toInt() and 0xFF) or (pcm[i0 * 2 + 1].toInt() shl 8)
            val s1 = (pcm[(i0 + 1) * 2].toInt() and 0xFF) or (pcm[(i0 + 1) * 2 + 1].toInt() shl 8)
            val v = (s0 + (s1 - s0) * frac).toInt().coerceIn(-32768, 32767)
            out[i * 2] = (v and 0xFF).toByte(); out[i * 2 + 1] = (v shr 8).toByte()
        }
        return out
    }

    suspend fun drain() {
        val t = track ?: return
        val target = framesWritten; var guard = 0
        try { while (!stopped && t.playbackHeadPosition < target && guard++ < 2000) delay(20) } catch (_: IllegalStateException) {}
        onAmp?.invoke(0f)
    }

    fun stop() {
        stopped = true
        try { track?.pause(); track?.flush(); track?.release() } catch (_: Exception) {}
        track = null; onAmp?.invoke(0f)
    }
}

/** Convert raw PCM16 mono to WAV bytes (44-byte header). */
fun pcmToWav(pcm: ByteArray, rate: Int = 16000): ByteArray {
    val h = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
    h.put("RIFF".toByteArray()); h.putInt(36 + pcm.size); h.put("WAVE".toByteArray()); h.put("fmt ".toByteArray())
    h.putInt(16); h.putShort(1); h.putShort(1); h.putInt(rate); h.putInt(rate * 2); h.putShort(2); h.putShort(16)
    h.put("data".toByteArray()); h.putInt(pcm.size)
    return h.array() + pcm
}

/** Voice activity detection: adaptive noise floor, 3-frame start, 300 ms pre-roll, silence endpoint. */
class Vad(private val silenceMs: Int, private val onStart: () -> Unit, private val onUtterance: (ByteArray) -> Unit) {
    private val win = java.util.ArrayDeque<Double>()
    private val pre = java.util.ArrayDeque<ShortArray>()
    private val buf = ByteArrayOutputStream()
    private var speech = 0; private var rec = false; private var silent = 0; private var total = 0

    fun reset() { rec = false; speech = 0; silent = 0; total = 0; buf.reset(); pre.clear() }

    private fun write(f: ShortArray) { for (x in f) { buf.write(x.toInt() and 0xFF); buf.write((x.toInt() shr 8) and 0xFF) } }

    /** Feed 16kHz mono PCM frames. Detects speech start/end via adaptive noise floor. */
    fun feed(frame: ShortArray) {
        var sum = 0.0
        for (x in frame) sum += (x * x).toDouble()
        val rms = kotlin.math.sqrt(sum / frame.size)
        win.addLast(rms); if (win.size > 50) win.removeFirst()
        val noise = win.average() + 200.0
        val isSpeech = rms > noise * 1.8
        if (isSpeech) {
            if (!rec) {
                speech++
                if (speech >= 3) { rec = true; onStart(); for (f in pre) write(f); pre.clear() }
            } else { silent = 0; write(frame) }
            total++
        } else {
            if (rec) {
                write(frame); silent++
                val silenceFrames = silenceMs / 20  // 20ms per frame approx
                if (silent >= silenceFrames) {
                    rec = false; speech = 0; silent = 0
                    val pcm = buf.toByteArray(); buf.reset()
                    if (pcm.size > 1000) onUtterance(pcm)
                }
            } else {
                speech = 0
                pre.addLast(frame); if (pre.size > 15) pre.removeFirst()  // 300ms pre-roll
            }
        }
    }
}

/** Android TextToSpeech: used when the neural TTS fails, is unset, or the text is Hindi/Bengali script. */
class FallbackTts(ctx: Context) {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private val waiters = ConcurrentHashMap<String, CompletableDeferred<Unit>>()

    init {
        tts = TextToSpeech(ctx.applicationContext) { st ->
            ready = st == TextToSpeech.SUCCESS
            if (ready) tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { id?.let { waiters.remove(it)?.complete(Unit) } }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { id?.let { waiters.remove(it)?.complete(Unit) } }
            })
        }
    }

    suspend fun speak(text: String) {
        if (!ready || text.isBlank()) return
        tts?.language = when {
            text.any { it in '\u0980'..'\u09FF' } -> Locale("bn", "IN")
            text.any { it in '\u0900'..'\u097F' } -> Locale("hi", "IN")
            else -> Locale("en", "IN")
        }
        val id = UUID.randomUUID().toString(); val d = CompletableDeferred<Unit>(); waiters[id] = d
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, id)
        try { d.await() } catch (e: CancellationException) { tts?.stop(); throw e }
    }
    fun stop() { tts?.stop(); waiters.values.forEach { it.complete(Unit) }; waiters.clear() }
}
