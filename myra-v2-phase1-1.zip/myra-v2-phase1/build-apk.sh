#!/usr/bin/env bash
set -euo pipefail
chmod +x ./gradlew
./gradlew --no-daemon assembleDebug
printf '\nAPK: %s\n' "app/build/outputs/apk/debug/app-debug.apk"
